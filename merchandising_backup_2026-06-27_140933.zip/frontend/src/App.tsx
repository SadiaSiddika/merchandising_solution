import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Target,
  HelpCircle,
  DollarSign,
  ShoppingBag,
  TrendingUp,
  Layers,
  Settings,
  Plus,
  Save,
  XCircle,
  AlertCircle,
  Eye,
  BookOpen,
  ClipboardCheck,
  Lock,
  ArrowLeft,
  Download,
  FileText,
  Trash,
  Trash2,
  Edit,
  Shield
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

import { BudgetView } from './BudgetView';
import { FabricBookingView } from './FabricBookingView';

const API_BASE = 'http://localhost:5000/api';

// ==========================================================================
// Main App Component
// ==========================================================================
export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'crm' | 'crm_mis' | 'inquiry' | 'costing' | 'order' | 'budget' | 'fabric' | 'trims' | 'ta_progress'>('dashboard');
  
  // Master lists
  const [buyers, setBuyers] = useState<any[]>([]);
  const [itemsMaster, setItemsMaster] = useState<any[]>([]);
  const [dbStatus, setDbStatus] = useState<string>('sqlite');

  useEffect(() => {
    fetch(`${API_BASE}/db-status`).then(r => r.json()).then(data => setDbStatus(data.dbType)).catch(() => {});
    fetchBuyers();
    fetchItemsMaster();
  }, []);

  const fetchBuyers = async () => {
    try {
      const res = await fetch(`${API_BASE}/buyers`);
      const data = await res.json();
      setBuyers(data);
    } catch (e) { console.error("Error fetching buyers", e); }
  };

  const fetchItemsMaster = async () => {
    try {
      const res = await fetch(`${API_BASE}/items`);
      const data = await res.json();
      setItemsMaster(data);
    } catch (e) { console.error("Error fetching items", e); }
  };

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <nav className="sidebar">
        <div className="sidebar-header">
          <div className="user-avatar" style={{ background: 'var(--primary-gradient)' }}>M</div>
          <span className="sidebar-logo">METAMORPHOSIS</span>
        </div>
        <ul className="sidebar-menu">
          <li className={`menu-item ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}>
            <LayoutDashboard className="menu-item-icon" /> Dashboard
          </li>
          <li className={`menu-item ${activeTab === 'crm' ? 'active' : ''}`} onClick={() => setActiveTab('crm')}>
            <Target className="menu-item-icon" /> Sales Target (CRM)
          </li>
          <li className={`menu-item ${activeTab === 'crm_mis' ? 'active' : ''}`} onClick={() => setActiveTab('crm_mis')}>
            <TrendingUp className="menu-item-icon" /> CRM MIS Report
          </li>
          <li className={`menu-item ${activeTab === 'inquiry' ? 'active' : ''}`} onClick={() => setActiveTab('inquiry')}>
            <HelpCircle className="menu-item-icon" /> Quotation Inquiry
          </li>
          <li className={`menu-item ${activeTab === 'costing' ? 'active' : ''}`} onClick={() => setActiveTab('costing')}>
            <DollarSign className="menu-item-icon" /> Price Costing
          </li>
          <li className={`menu-item ${activeTab === 'order' ? 'active' : ''}`} onClick={() => setActiveTab('order')}>
            <ShoppingBag className="menu-item-icon" /> Order Entry
          </li>
          <li className={`menu-item ${activeTab === 'ta_progress' ? 'active' : ''}`} onClick={() => setActiveTab('ta_progress')}>
            <BookOpen className="menu-item-icon" /> T&A Progress
          </li>
          <li className={`menu-item ${activeTab === 'budget' ? 'active' : ''}`} onClick={() => setActiveTab('budget')}>
            <ClipboardCheck className="menu-item-icon" /> Cost Budget
          </li>
          <li className={`menu-item ${activeTab === 'fabric' ? 'active' : ''}`} onClick={() => setActiveTab('fabric')}>
            <Layers className="menu-item-icon" /> Fabric Booking
          </li>
          <li className={`menu-item ${activeTab === 'trims' ? 'active' : ''}`} onClick={() => setActiveTab('trims')}>
            <Settings className="menu-item-icon" /> Trims Booking
          </li>
        </ul>
        <div style={{ padding: '16px', fontSize: '0.75rem', color: 'var(--text-muted)', borderTop: '1px solid var(--border-muted)' }}>
          DB: <span style={{ color: 'var(--secondary)', fontWeight: 600 }}>{dbStatus.toUpperCase()}</span>
        </div>
      </nav>

      {/* Main Panel */}
      <main className="main-content">
        <header className="top-bar">
          <h1 className="page-title">
            {activeTab === 'dashboard' && 'Dashboard Overview'}
            {activeTab === 'crm' && 'CRM - Monthly Sales Target'}
            {activeTab === 'crm_mis' && 'CRM Sales Target vs Achievement (MIS Report)'}
            {activeTab === 'inquiry' && 'Buyer Inquiries'}
            {activeTab === 'costing' && 'Garments Costing Engine & Price Quotations'}
            {activeTab === 'order' && 'Order Entry & PO Breakdowns'}
            {activeTab === 'ta_progress' && 'Time & Action (T&A) Progress Report'}
            {activeTab === 'budget' && 'Financial Control & Production Budget'}
            {activeTab === 'fabric' && 'Fabric Booking Manager'}
            {activeTab === 'trims' && 'Trims & Accessories Booking'}
          </h1>
          <div className="user-profile">
            <div className="user-info">
              <span className="user-name">Supervisor</span>
              <span className="user-role">Merchandising Manager</span>
            </div>
            <div className="user-avatar" style={{ background: 'var(--secondary-gradient)' }}>S</div>
          </div>
        </header>

        <div className="content-body">
          {activeTab === 'dashboard' && <DashboardView setActiveTab={setActiveTab} />}
          {activeTab === 'crm' && <SalesTargetView buyers={buyers} />}
          {activeTab === 'crm_mis' && <SalesTargetMISView buyers={buyers} />}
          {activeTab === 'inquiry' && <InquiryView buyers={buyers} />}
          {activeTab === 'costing' && <CostingView buyers={buyers} items={itemsMaster} />}
          {activeTab === 'order' && <OrderView buyers={buyers} />}
          {activeTab === 'ta_progress' && <TAProgressView />}
          {activeTab === 'budget' && <BudgetView buyers={buyers} />}
          {activeTab === 'fabric' && <FabricBookingView />}
          {activeTab === 'trims' && <TrimsBookingView />}
        </div>
      </main>
    </div>
  );
}

// ==========================================================================
// SUB-VIEW: Dashboard Overview
// ==========================================================================
function DashboardView({ setActiveTab: _setActiveTab }: { setActiveTab: any }) {
  const [salesData, setSalesData] = useState<any[]>([]);
  const [budgetData, setBudgetData] = useState<any[]>([]);
  const [stats, setStats] = useState({
    totalInquiries: 0,
    approvedQuotes: 0,
    activeOrders: 0,
    budgetUtilization: 0
  });

  useEffect(() => {
    fetchStats();
    fetchSalesData();
    fetchBudgetData();
  }, []);

  const fetchStats = async () => {
    try {
      const inqRes = await fetch(`${API_BASE}/inquiries`);
      const inq = await inqRes.json();
      const quoteRes = await fetch(`${API_BASE}/quotations`);
      const quotes = await quoteRes.json();
      const orderRes = await fetch(`${API_BASE}/orders`);
      const orders = await orderRes.json();
      const budgetRes = await fetch(`${API_BASE}/budgets`);
      const budgets = await budgetRes.json();

      let totalLimit = 0;
      let totalSpent = 0;
      budgets.forEach((b: any) => {
        totalLimit += parseFloat(b.total_budget_amount || 0);
        totalSpent += parseFloat(b.actual_spend || 0);
      });

      setStats({
        totalInquiries: inq.length,
        approvedQuotes: quotes.filter((q: any) => q.status === 'Approved').length,
        activeOrders: orders.length,
        budgetUtilization: totalLimit > 0 ? (totalSpent / totalLimit) * 100 : 0
      });
    } catch (e) { console.error("Error fetching stats", e); }
  };

  const fetchSalesData = async () => {
    try {
      const res = await fetch(`${API_BASE}/analytics/sales-target-vs-achieved`);
      const data = await res.json();
      setSalesData(data);
    } catch (e) { console.error(e); }
  };

  const fetchBudgetData = async () => {
    try {
      const res = await fetch(`${API_BASE}/analytics/budget-spend`);
      const data = await res.json();
      setBudgetData(data);
    } catch (e) { console.error(e); }
  };

  return (
    <div>
      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-details">
            <h3>Total Inquiries</h3>
            <div className="metric-value">{stats.totalInquiries}</div>
            <div className="metric-sub">Pending buyer review</div>
          </div>
          <div className="metric-icon-wrapper primary"><HelpCircle /></div>
        </div>
        <div className="metric-card">
          <div className="metric-details">
            <h3>Approved Costings</h3>
            <div className="metric-value">{stats.approvedQuotes}</div>
            <div className="metric-sub">FOB prices validated</div>
          </div>
          <div className="metric-icon-wrapper secondary"><DollarSign /></div>
        </div>
        <div className="metric-card">
          <div className="metric-details">
            <h3>Confirmed Orders</h3>
            <div className="metric-value">{stats.activeOrders}</div>
            <div className="metric-sub">Live production jobs</div>
          </div>
          <div className="metric-icon-wrapper warning"><ShoppingBag /></div>
        </div>
        <div className="metric-card">
          <div className="metric-details">
            <h3>Budget Utilization</h3>
            <div className="metric-value">{stats.budgetUtilization.toFixed(1)}%</div>
            <div className="metric-sub">Total actual spent vs budget</div>
          </div>
          <div className="metric-icon-wrapper danger"><TrendingUp /></div>
        </div>
      </div>

      <div className="grid-2 mt-20">
        <div className="dashboard-card">
          <div className="card-header">
            <h2 className="card-title"><Target size={18} /> Sales Target vs Confirmed Achievement ({new Date().getFullYear()})</h2>
          </div>
          <div style={{ width: '100%', height: 300 }}>
            {salesData.length === 0 ? (
              <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', color:'var(--text-muted)' }}>
                No approved targets / confirmed orders found to graph.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={salesData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-muted)" />
                  <XAxis dataKey="month" stroke="var(--text-secondary)" />
                  <YAxis stroke="var(--text-secondary)" />
                  <Tooltip contentStyle={{ backgroundColor: 'var(--bg-dark)', borderColor: 'var(--border-muted)' }} />
                  <Legend />
                  <Bar dataKey="total_target_val" name="Target Value ($)" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="total_confirm_val" name="Confirmed Value ($)" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="dashboard-card">
          <div className="card-header">
            <h2 className="card-title"><ClipboardCheck size={18} /> Production Budget vs Actual Spend by Style</h2>
          </div>
          <div style={{ width: '100%', height: 300 }}>
            {budgetData.length === 0 ? (
              <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', color:'var(--text-muted)' }}>
                No budget entries found to graph.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={budgetData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-muted)" />
                  <XAxis dataKey="style_no" stroke="var(--text-secondary)" />
                  <YAxis stroke="var(--text-secondary)" />
                  <Tooltip contentStyle={{ backgroundColor: 'var(--bg-dark)', borderColor: 'var(--border-muted)' }} />
                  <Legend />
                  <Bar dataKey="total_budget_amount" name="Budget Limit ($)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="actual_spend" name="Actual Spend ($)" fill="#ef4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ==========================================================================
// SUB-VIEW: CRM & Sales Target (Includes ALL spreadsheet fields)
// ==========================================================================
function SalesTargetView({ buyers }: { buyers: any[] }) {
  const [targets, setTargets] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({
    buyer_id: '',
    brand: '',
    buying_agent: '',
    buying_agent_merchant: '',
    team_leader: '',
    season: '',
    year: new Date().getFullYear(),
    month: 'January',
    target_basic_qty: 0,
    target_basic_val: 0,
    target_casual_qty: 0,
    target_casual_val: 0,
    target_fashion_qty: 0,
    target_fashion_val: 0,
    status: 'Draft'
  });

  useEffect(() => {
    fetchTargets();
  }, []);

  const fetchTargets = async () => {
    try {
      const res = await fetch(`${API_BASE}/sales-targets`);
      const data = await res.json();
      setTargets(data);
    } catch (e) { console.error(e); }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.buyer_id || !form.team_leader || !form.season) {
      alert("Please fill up all required fields.");
      return;
    }

    // Popup confirmation check (Excel constraint)
    const proceed = window.confirm("You are creating sales Target & Month\nDo you want to proceed?");
    if (!proceed) return;

    // Totals calculate
    const totalQty = parseFloat(form.target_basic_qty as any || 0) + parseFloat(form.target_casual_qty as any || 0) + parseFloat(form.target_fashion_qty as any || 0);
    const totalVal = parseFloat(form.target_basic_val as any || 0) + parseFloat(form.target_casual_val as any || 0) + parseFloat(form.target_fashion_val as any || 0);

    const payload = {
      ...form,
      target_qty: totalQty,
      target_value: totalVal
    };

    try {
      const res = await fetch(`${API_BASE}/sales-targets`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        setShowModal(false);
        fetchTargets();
      }
    } catch (e) { console.error(e); }
  };

  const handleApprove = async (id: number) => {
    try {
      const target = targets.find(t => t.id === id);
      await fetch(`${API_BASE}/sales-targets/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...target, status: 'Approved' })
      });
      fetchTargets();
    } catch (e) { console.error(e); }
  };

  return (
    <div className="dashboard-card">
      <div className="card-header">
        <h2 className="card-title"><Target /> Sales Target Tracking (CRM)</h2>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={16} /> New CRM Target
        </button>
      </div>

      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Buyer</th>
              <th>Brand</th>
              <th>Season</th>
              <th>Year</th>
              <th>Month</th>
              <th>Leader</th>
              <th>Target basic Qty</th>
              <th>Target casual Qty</th>
              <th>Target fashion Qty</th>
              <th>Total Qty</th>
              <th>Total Value</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {targets.map((t, idx) => {
              const isLocked = t.status === 'Approved';
              return (
                <tr key={idx}>
                  <td><strong>{t.buyer_name}</strong></td>
                  <td>{t.brand}</td>
                  <td>{t.season}</td>
                  <td>{t.year}</td>
                  <td>{t.month}</td>
                  <td>{t.team_leader}</td>
                  <td>{parseFloat(t.target_basic_qty || 0).toLocaleString()}</td>
                  <td>{parseFloat(t.target_casual_qty || 0).toLocaleString()}</td>
                  <td>{parseFloat(t.target_fashion_qty || 0).toLocaleString()}</td>
                  <td><strong>{parseFloat(t.target_qty).toLocaleString()} pcs</strong></td>
                  <td><strong>${parseFloat(t.target_value).toLocaleString()}</strong></td>
                  <td>
                    <span className={`badge badge-${t.status.toLowerCase()}`}>
                      {t.status} {isLocked && <Lock size={12} style={{ marginLeft: '4px', verticalAlign: 'middle' }} />}
                    </span>
                  </td>
                  <td>
                    {t.status === 'Draft' ? (
                      <button className="btn btn-success btn-sm" onClick={() => handleApprove(t.id)}>
                        Approve
                      </button>
                    ) : (
                      <span className="text-muted"><Lock size={14} /> Locked</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '800px' }}>
            <div className="modal-header">
              <h3>New Sales Target (CRM Module)</h3>
              <XCircle className="modal-close" onClick={() => setShowModal(false)} />
            </div>
            <form onSubmit={handleCreate}>
              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Buyer *</label>
                  <select className="form-control" value={form.buyer_id} onChange={e => setForm({ ...form, buyer_id: e.target.value })} required>
                    <option value="">Select Buyer</option>
                    {buyers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Brand Name</label>
                  <input type="text" className="form-control" value={form.brand} onChange={e => setForm({ ...form, brand: e.target.value })} placeholder="Brand" />
                </div>
                <div className="form-group">
                  <label className="form-label">Buying Agent</label>
                  <input type="text" className="form-control" value={form.buying_agent} onChange={e => setForm({ ...form, buying_agent: e.target.value })} placeholder="Buying Agent" />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Buying Agent Merchant</label>
                  <input type="text" className="form-control" value={form.buying_agent_merchant} onChange={e => setForm({ ...form, buying_agent_merchant: e.target.value })} placeholder="Merchant" />
                </div>
                <div className="form-group">
                  <label className="form-label">Team Leader *</label>
                  <input type="text" className="form-control" value={form.team_leader} onChange={e => setForm({ ...form, team_leader: e.target.value })} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Season *</label>
                  <input type="text" className="form-control" value={form.season} onChange={e => setForm({ ...form, season: e.target.value })} required placeholder="e.g. Summer 2026" />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Year *</label>
                  <select className="form-control" value={form.year} onChange={e => setForm({ ...form, year: parseInt(e.target.value) })}>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Month *</label>
                  <select className="form-control" value={form.month} onChange={e => setForm({ ...form, month: e.target.value })}>
                    {['January','February','March','April','May','June','July','August','September','October','November','December'].map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Status</label>
                  <select className="form-control" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                    <option value="Draft">Draft</option>
                    <option value="Approved">Approved</option>
                  </select>
                </div>
              </div>

              <h4 style={{ margin: '20px 0 10px 0', borderBottom: '1px solid var(--border-muted)', paddingBottom: '8px' }}>Month Wise Target Details</h4>
              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Basic Target Qty (Pcs)</label>
                  <input type="number" className="form-control" value={form.target_basic_qty} onChange={e => setForm({ ...form, target_basic_qty: parseFloat(e.target.value) || 0 })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Casual Basic Target Qty</label>
                  <input type="number" className="form-control" value={form.target_casual_qty} onChange={e => setForm({ ...form, target_casual_qty: parseFloat(e.target.value) || 0 })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Fashion Target Qty</label>
                  <input type="number" className="form-control" value={form.target_fashion_qty} onChange={e => setForm({ ...form, target_fashion_qty: parseFloat(e.target.value) || 0 })} />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Basic Target Value ($)</label>
                  <input type="number" className="form-control" value={form.target_basic_val} onChange={e => setForm({ ...form, target_basic_val: parseFloat(e.target.value) || 0 })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Casual Basic Target Value</label>
                  <input type="number" className="form-control" value={form.target_casual_val} onChange={e => setForm({ ...form, target_casual_val: parseFloat(e.target.value) || 0 })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Fashion Target Value</label>
                  <input type="number" className="form-control" value={form.target_fashion_val} onChange={e => setForm({ ...form, target_fashion_val: parseFloat(e.target.value) || 0 })} />
                </div>
              </div>

              <div className="mt-20 text-right">
                <button type="button" className="btn btn-secondary mr-10" style={{ marginRight: '10px' }} onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary"><Save size={16} /> Save Target</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================================================
// SUB-VIEW: CRM Sales Target vs Achievement MIS Report
// ==========================================================================
function SalesTargetMISView({ buyers: _buyers }: { buyers: any[] }) {
  const [reportRows, setReportRows] = useState<any[]>([]);
  const [yearFilter, setYearFilter] = useState('2026');
  const [brandFilter, setBrandFilter] = useState('');

  useEffect(() => {
    fetchReport();
  }, [yearFilter, brandFilter]);

  const fetchReport = async () => {
    try {
      let url = `${API_BASE}/reports/sales-target-mis`;
      const res = await fetch(url);
      const data = await res.json();
      
      // Apply filters in frontend for convenience
      let filtered = data;
      if (yearFilter) {
        filtered = filtered.filter((r: any) => String(r.year) === yearFilter);
      }
      if (brandFilter) {
        filtered = filtered.filter((r: any) => r.brand && r.brand.toLowerCase().includes(brandFilter.toLowerCase()));
      }
      setReportRows(filtered);
    } catch (e) { console.error("Error fetching MIS report", e); }
  };

  return (
    <div className="dashboard-card">
      <div className="card-header">
        <h2 className="card-title"><TrendingUp /> Target vs Achievement (MIS Analysis)</h2>
        <div className="d-flex gap-10">
          <select className="form-control" style={{ width: '120px' }} value={yearFilter} onChange={e => setYearFilter(e.target.value)}>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
          </select>
          <input
            type="text"
            className="form-control"
            style={{ width: '180px' }}
            placeholder="Search Brand..."
            value={brandFilter}
            onChange={e => setBrandFilter(e.target.value)}
          />
        </div>
      </div>

      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Brand</th>
              <th>Buyer</th>
              <th>Season</th>
              <th>Month</th>
              <th>Year</th>
              <th>Basic (Tgt Qty / Ach Qty / Ach %)</th>
              <th>Casual Basic (Tgt Qty / Ach Qty / Ach %)</th>
              <th>Fashion (Tgt Qty / Ach Qty / Ach %)</th>
              <th>Total Qty Target</th>
              <th>Confirm Ach Qty</th>
              <th>Target Value</th>
              <th>Confirm Ach Value</th>
              <th>Ach Value %</th>
            </tr>
          </thead>
          <tbody>
            {reportRows.map((r, idx) => {
              const basicAchPct = r.target_basic_qty > 0 ? (r.confirm_qty / r.target_qty) * 100 : 0; // estimate
              const casualAchPct = r.target_casual_qty > 0 ? (r.confirm_qty / r.target_qty) * 100 : 0;
              const fashionAchPct = r.target_fashion_qty > 0 ? (r.confirm_qty / r.target_qty) * 100 : 0;
              const totalValPct = r.target_value > 0 ? (r.confirm_value / r.target_value) * 100 : 0;

              return (
                <tr key={idx}>
                  <td><strong>{r.brand || 'N/A'}</strong></td>
                  <td>{r.buyer_name}</td>
                  <td>{r.season}</td>
                  <td>{r.month}</td>
                  <td>{r.year}</td>
                  <td>
                    {r.target_basic_qty} / {r.confirm_qty} / {basicAchPct.toFixed(0)}%
                  </td>
                  <td>
                    {r.target_casual_qty} / {r.confirm_qty} / {casualAchPct.toFixed(0)}%
                  </td>
                  <td>
                    {r.target_fashion_qty} / {r.confirm_qty} / {fashionAchPct.toFixed(0)}%
                  </td>
                  <td><strong>{parseFloat(r.target_qty).toLocaleString()}</strong></td>
                  <td style={{ color: 'var(--secondary)' }}>{parseFloat(r.confirm_qty || 0).toLocaleString()}</td>
                  <td><strong>${parseFloat(r.target_value).toLocaleString()}</strong></td>
                  <td style={{ color: 'var(--secondary)', fontWeight: 600 }}>${parseFloat(r.confirm_value || 0).toLocaleString()}</td>
                  <td style={{ fontWeight: 600, color: totalValPct >= 100 ? 'var(--secondary)' : 'var(--warning)' }}>
                    {totalValPct.toFixed(1)}%
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ==========================================================================
// SUB-VIEW: Quotation Inquiry (Includes ALL spreadsheet fields)
// ==========================================================================
function InquiryView({ buyers }: { buyers: any[] }) {
  const [inquiries, setInquiries] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedInquiry, setSelectedInquiry] = useState<any>(null);
  
  // Fabric List & Yarn List
  const [fabricsList, setFabricsList] = useState<any[]>([]);
  const [yarnsList, setYarnsList] = useState<any[]>([]);
  const [itemsMaster, setItemsMaster] = useState<any[]>([]);

  const stylesByCompany: Record<string, Array<{style_no: string, buyer_id: string, item_group: string, brand: string}>> = {
    'Demo Factory Ltd.': [
      { style_no: 'test', buyer_id: '', item_group: 'Fashion', brand: 'NewYorker' },
      { style_no: 'Style-1001', buyer_id: '', item_group: 'Basic', brand: 'Zara' }
    ],
    'Metamorphosis Apparels': [
      { style_no: 'Style-2002', buyer_id: '', item_group: 'Casual Basic', brand: 'H&M' },
      { style_no: 'Style-3003', buyer_id: '', item_group: 'Basic', brand: 'Zara' }
    ]
  };

  const teamLeaders = ["Demo User", "John Doe", "Jane Smith", "Ken Tanaka"];
  const merchantsByLeader: Record<string, string[]> = {
    "Demo User": ["Mahade Hasan", "Tariqul Islam"],
    "John Doe": ["Alice Johnson", "Bob Brown"],
    "Jane Smith": ["Charlie Green", "David White"],
    "Ken Tanaka": ["Taro Yamada", "Yuki Sato"]
  };

  const [form, setForm] = useState({
    buyer_id: '',
    style_no: '',
    style_desc: '',
    item_group: 'Basic',
    garments_item: '',
    brand: '',
    year: new Date().getFullYear(),
    season: '',
    team_leader: '',
    dealing_merchant: '',
    inquiry_date: new Date().toISOString().split('T')[0],
    sub_date: '',
    ship_date: '',
    offer_qty: 0,
    uom: 'Pcs',
    costing_per: '1 Dzn',
    department: 'Kids',
    sample_req: 'No',
    remarks: '',
    image_url: '',
    company: 'Demo Factory Ltd.',
    quoted_by: 'Super admin',
    status: 'Draft'
  });

  // Subform inputs
  const [composition, setComposition] = useState('');
  const [fabricType, setFabricType] = useState('');
  const [gsm, setGsm] = useState(160);
  const [dia, setDia] = useState(60);
  const [diaType, setDiaType] = useState('Open');
  const [fabricUom, _setFabricUom] = useState('Kg');
  const [fabricRate, setFabricRate] = useState(5.5);
  const [requiredQty, setRequiredQty] = useState(0);

  const [yarnComposition, setYarnComposition] = useState('');
  const [yarnCount, setYarnCount] = useState('30s');
  const [yarnType, setYarnType] = useState('Combed');
  const [yarnCert, setYarnCert] = useState('GOTS');

  useEffect(() => {
    fetchInquiries();
    fetchItemsMaster();
  }, []);

  const fetchItemsMaster = async () => {
    try {
      const res = await fetch(`${API_BASE}/items`);
      const data = await res.json();
      setItemsMaster(data);
    } catch (e) { console.error(e); }
  };

  const handleStyleChange = (selectedStyleNo: string) => {
    if (selectedStyleNo === 'custom_style') {
      setForm(f => ({ ...f, style_no: 'custom_style' }));
      return;
    }
    const companyStyles = stylesByCompany[form.company] || [];
    const styleObj = companyStyles.find(s => s.style_no === selectedStyleNo);
    if (styleObj) {
      const foundBuyer = buyers.find(b => b.name.toLowerCase() === styleObj.brand.toLowerCase());
      const buyerIdVal = foundBuyer ? foundBuyer.id.toString() : '';
      const seasonVal = foundBuyer ? foundBuyer.season : '';
      
      setForm(f => ({
        ...f,
        style_no: selectedStyleNo,
        buyer_id: buyerIdVal,
        item_group: styleObj.item_group,
        brand: styleObj.brand,
        season: seasonVal
      }));
    } else {
      setForm(f => ({ ...f, style_no: selectedStyleNo }));
    }
  };

  const fetchInquiries = async () => {
    try {
      const res = await fetch(`${API_BASE}/inquiries`);
      const data = await res.json();
      setInquiries(data);
    } catch (e) { console.error(e); }
  };

  const handleAddFabricLine = () => {
    if (!composition || !fabricType) return alert("Fill up Fabric details composition and type.");
    setFabricsList([...fabricsList, {
      composition, fabric_type: fabricType, gsm, dia, dia_type: diaType, uom: fabricUom, rate: fabricRate, required_qty: requiredQty
    }]);
    setComposition('');
    setFabricType('');
  };

  const handleAddYarnLine = () => {
    if (!yarnComposition) return alert("Fill up Yarn composition.");
    setYarnsList([...yarnsList, {
      composition: form.style_no, yarn_composition: yarnComposition, yarn_count: yarnCount, yarn_type: yarnType, certification: yarnCert
    }]);
    setYarnComposition('');
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.buyer_id || !form.style_no) {
      alert("Buyer and Style No are required fields.");
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/inquiries`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, fabrics: fabricsList, yarns: yarnsList })
      });
      if (res.ok) {
        setShowModal(false);
        fetchInquiries();
        setFabricsList([]);
        setYarnsList([]);
        setForm({
          buyer_id: '',
          style_no: '',
          style_desc: '',
          item_group: 'Basic',
          garments_item: '',
          brand: '',
          year: new Date().getFullYear(),
          season: '',
          team_leader: '',
          dealing_merchant: '',
          inquiry_date: new Date().toISOString().split('T')[0],
          sub_date: '',
          ship_date: '',
          offer_qty: 0,
          uom: 'Pcs',
          costing_per: '1 Dzn',
          department: 'Kids',
          sample_req: 'No',
          remarks: '',
          image_url: '',
          company: 'Demo Factory Ltd.',
          quoted_by: 'Super admin',
          status: 'Draft'
        });
      }
    } catch (e) { console.error(e); }
  };

  const handleApproveInquiry = async (id: string) => {
    try {
      const res = await fetch(`${API_BASE}/inquiries/${id}/approve`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approved_by: 'Supervisor' })
      });
      if (res.ok) fetchInquiries();
    } catch (e) { console.error(e); }
  };

  const handleViewDetails = async (id: string) => {
    try {
      const res = await fetch(`${API_BASE}/inquiries/${id}`);
      const data = await res.json();
      setSelectedInquiry(data);
    } catch (e) { console.error(e); }
  };

  if (selectedInquiry) {
    const buyerObj = buyers.find(b => b.id.toString() === selectedInquiry.buyer_id?.toString());
    const buyerName = selectedInquiry.buyer_name || buyerObj?.name || 'NewYorker';
    const inqYear = selectedInquiry.year || (selectedInquiry.inquiry_date ? new Date(selectedInquiry.inquiry_date).getFullYear() : '2026');
    const fabricsRate = selectedInquiry.fabrics && selectedInquiry.fabrics[0] ? selectedInquiry.fabrics[0].rate : 0.30;
    const tentativeVal = selectedInquiry.offer_qty * fabricsRate;

    return (
      <div className="dashboard-card" style={{ padding: '25px', background: '#fff', borderRadius: '8px' }}>
        {/* Header Toolbar */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', borderBottom: '1px solid #cbd5e1', paddingBottom: '15px' }}>
          <h2 style={{ margin: 0, fontSize: '24px', fontWeight: 'bold', color: '#1e293b' }}>Quotation Inquiry</h2>
          <button className="btn btn-secondary" onClick={() => setSelectedInquiry(null)} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: '#f1f5f9', border: '1px solid #cbd5e1', color: '#334155', fontWeight: '600' }}>
            <ArrowLeft size={16} /> Back
          </button>
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
          <button className="btn btn-success" onClick={() => window.print()} style={{ display: 'flex', alignItems: 'center', gap: '8px', background: '#22c55e', borderColor: '#22c55e', color: '#fff', fontWeight: '600' }}>
            <Download size={16} /> Download
          </button>
          <button className="btn btn-danger" onClick={() => alert("Generating PDF Report...")} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#ef4444', borderColor: '#ef4444', color: '#fff', padding: '10px 14px' }}>
            <FileText size={16} />
          </button>
        </div>

        {/* 3-column Grid Information Table */}
        <div className="table-wrapper" style={{ marginBottom: '30px', overflowX: 'auto' }}>
          <table className="data-table" style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #cbd5e1', fontSize: '13px' }}>
            <tbody>
              {/* Row 1 */}
              <tr>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', width: '15%', color: '#334155' }}>Inquiry ID</td>
                <td style={{ background: '#e0f2fe', border: '1px solid #cbd5e1', padding: '10px', width: '18%', fontWeight: '600', color: '#0369a1' }}>{selectedInquiry.id}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', width: '15%', color: '#334155' }}>Company Name</td>
                <td style={{ background: '#e0f2fe', border: '1px solid #cbd5e1', padding: '10px', width: '18%', fontWeight: '600', color: '#0369a1' }}>{selectedInquiry.company || 'Demo Factory Ltd.'}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', width: '15%', color: '#334155' }}>Buyer Name</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', width: '19%', color: '#334155' }}>{buyerName}</td>
              </tr>
              {/* Row 2 */}
              <tr>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Style ID</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.style_no}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Style Description</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.style_desc || ''}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Garment Item</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.garments_item}</td>
              </tr>
              {/* Row 3 */}
              <tr>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Season</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.season}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Inquiry Date</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.inquiry_date}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Quantity</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.offer_qty}</td>
              </tr>
              {/* Row 4 */}
              <tr>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Year</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{inqYear}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Tentative Unit Price</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.tentative_price || fabricsRate}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Tentative Value</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{tentativeVal.toLocaleString()}</td>
              </tr>
              {/* Row 5 */}
              <tr>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Team Lead</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.team_leader}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Dealing Merchant</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.dealing_merchant}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Quotation Submission Date</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.sub_date}</td>
              </tr>
              {/* Row 6 */}
              <tr>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Required Sample</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.sample_req}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Tentative Shipment Date</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.ship_date}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Costing Per</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.costing_per}</td>
              </tr>
              {/* Row 7 */}
              <tr>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Remarks</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.remarks}</td>
                <td style={{ background: '#f8fafc', fontWeight: 'bold', border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>Prepared By</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px', color: '#334155' }}>{selectedInquiry.quoted_by || 'Super admin'}</td>
                <td style={{ background: '#f8fafc', border: '1px solid #cbd5e1', padding: '10px' }}></td>
                <td style={{ border: '1px solid #cbd5e1', padding: '10px' }}></td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Side-by-Side Specifications Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
          {/* Fabric Specifications */}
          <div>
            <h3 style={{ marginBottom: '10px', fontSize: '15px', fontWeight: 'bold', color: '#1e293b' }}>Fabric Details</h3>
            <div className="table-wrapper">
              <table className="data-table" style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #cbd5e1', fontSize: '12px' }}>
                <thead>
                  <tr style={{ background: '#f8fafc' }}>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Fabric Composition</th>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Fabric Type</th>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Fabric GSM/OZ</th>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Dia</th>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>UOM</th>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedInquiry.fabrics && selectedInquiry.fabrics.length > 0 ? (
                    selectedInquiry.fabrics.map((f: any, i: number) => (
                      <tr key={i}>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{f.composition}</td>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{f.fabric_type}</td>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{f.gsm}</td>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{f.dia}</td>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{f.uom}</td>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{f.rate}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'center', color: '#64748b' }}>No fabric details available</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Yarn Specifications */}
          <div>
            <h3 style={{ marginBottom: '10px', fontSize: '15px', fontWeight: 'bold', color: '#1e293b' }}>Yarn Details</h3>
            <div className="table-wrapper">
              <table className="data-table" style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #cbd5e1', fontSize: '12px' }}>
                <thead>
                  <tr style={{ background: '#f8fafc' }}>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Fabric Composition</th>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Yarn Composition</th>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Yarn Count</th>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Yarn Type</th>
                    <th style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'left', color: '#334155' }}>Certification</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedInquiry.yarns && selectedInquiry.yarns.length > 0 ? (
                    selectedInquiry.yarns.map((y: any, i: number) => (
                      <tr key={i}>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{y.composition}</td>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{y.yarn_composition}</td>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{y.yarn_count}</td>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{y.yarn_type}</td>
                        <td style={{ border: '1px solid #cbd5e1', padding: '8px', color: '#334155' }}>{y.certification}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} style={{ border: '1px solid #cbd5e1', padding: '8px', textAlign: 'center', color: '#64748b' }}>No yarn details available</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-card">
      <div className="card-header">
        <h2 className="card-title"><HelpCircle /> Quotation Inquiries</h2>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={16} /> Add Inquiry Log
        </button>
      </div>

      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Inquiry ID</th>
              <th>Buyer</th>
              <th>Style No</th>
              <th>Garments Item</th>
              <th>Department</th>
              <th>Offer Qty</th>
              <th>Inquiry Date</th>
              <th>Tentative Ship Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {inquiries.map((inq, idx) => (
              <tr key={idx}>
                <td><strong>{inq.id}</strong></td>
                <td>{inq.buyer_name}</td>
                <td>{inq.style_no}</td>
                <td>{inq.garments_item}</td>
                <td>{inq.department}</td>
                <td>{inq.offer_qty} {inq.uom}</td>
                <td>{inq.inquiry_date}</td>
                <td>{inq.ship_date}</td>
                <td>
                  <span className={`badge badge-${inq.status.toLowerCase()}`}>{inq.status}</span>
                </td>
                <td>
                  <div className="d-flex gap-10">
                    <button className="btn btn-secondary btn-sm" onClick={() => handleViewDetails(inq.id)}>
                      <Eye size={12} /> View
                    </button>
                    {inq.status === 'Draft' && (
                      <button className="btn btn-success btn-sm" onClick={() => handleApproveInquiry(inq.id)}>
                        Approve
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>


      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '850px' }}>
            <div className="modal-header">
              <h3>Create CRM Quotation Inquiry Log</h3>
              <XCircle className="modal-close" onClick={() => setShowModal(false)} />
            </div>
            
            <form onSubmit={handleCreate}>
              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Company Name *</label>
                  <select 
                    className="form-control" 
                    value={form.company} 
                    onChange={e => {
                      const comp = e.target.value;
                      setForm({ ...form, company: comp, style_no: '', buyer_id: '', brand: '', season: '', item_group: 'Basic' });
                    }} 
                    required
                  >
                    <option value="Demo Factory Ltd.">Demo Factory Ltd.</option>
                    <option value="Metamorphosis Apparels">Metamorphosis Apparels</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Style ID * (From Master)</label>
                  <select 
                    className="form-control" 
                    value={form.style_no} 
                    onChange={e => handleStyleChange(e.target.value)} 
                    required
                  >
                    <option value="">Select Style ID</option>
                    {(stylesByCompany[form.company] || []).map(s => (
                      <option key={s.style_no} value={s.style_no}>{s.style_no}</option>
                    ))}
                    <option value="custom_style">+ Custom Style ID</option>
                  </select>
                </div>
                {form.style_no === 'custom_style' || (!(stylesByCompany[form.company] || []).map(s => s.style_no).includes(form.style_no) && form.style_no) ? (
                  <div className="form-group">
                    <label className="form-label">Custom Style ID Name *</label>
                    <input 
                      type="text" 
                      className="form-control" 
                      placeholder="Type custom style ID..."
                      value={form.style_no === 'custom_style' ? '' : form.style_no}
                      onChange={e => setForm({ ...form, style_no: e.target.value })}
                      required
                    />
                  </div>
                ) : (
                  <div className="form-group">
                    <label className="form-label">Style Description</label>
                    <input type="text" className="form-control" value={form.style_desc} onChange={e => setForm({ ...form, style_desc: e.target.value })} placeholder="Style description..." />
                  </div>
                )}
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Buyer * (User Assigned)</label>
                  <select 
                    className="form-control" 
                    value={form.buyer_id} 
                    onChange={e => {
                      const bid = e.target.value;
                      const b = buyers.find(buyer => buyer.id.toString() === bid);
                      setForm({ ...form, buyer_id: bid, season: b ? b.season : form.season });
                    }} 
                    required
                  >
                    <option value="">Select Buyer</option>
                    {/* User wise validation: Currently logged-in user can access all buyers */}
                    {buyers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Garment Item Group *</label>
                  <select className="form-control" value={form.item_group} onChange={e => setForm({ ...form, item_group: e.target.value })}>
                    <option value="Basic">Basic</option>
                    <option value="Casual Basic">Casual Basic</option>
                    <option value="Fashion">Fashion</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Brand</label>
                  <input type="text" className="form-control" value={form.brand} onChange={e => setForm({ ...form, brand: e.target.value })} placeholder="e.g. Zara Kids" />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Year *</label>
                  <select className="form-control" value={form.year} onChange={e => setForm({ ...form, year: parseInt(e.target.value) })}>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                    <option value="2028">2028</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Season * (Auto from Buyer)</label>
                  <input type="text" className="form-control" value={form.season} onChange={e => setForm({ ...form, season: e.target.value })} placeholder="Auto-populated or type season..." required />
                </div>
                <div className="form-group">
                  <label className="form-label">Team Leader *</label>
                  <select 
                    className="form-control" 
                    value={form.team_leader} 
                    onChange={e => {
                      const leader = e.target.value;
                      const merchants = merchantsByLeader[leader] || [];
                      setForm({ ...form, team_leader: leader, dealing_merchant: merchants[0] || '' });
                    }}
                    required
                  >
                    <option value="">Select Team Leader</option>
                    {teamLeaders.map(leader => (
                      <option key={leader} value={leader}>{leader}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Dealing Merchant *</label>
                  <select 
                    className="form-control" 
                    value={form.dealing_merchant} 
                    onChange={e => setForm({ ...form, dealing_merchant: e.target.value })}
                    required
                  >
                    <option value="">Select Dealing Merchant</option>
                    {(merchantsByLeader[form.team_leader] || []).map(merchant => (
                      <option key={merchant} value={merchant}>{merchant}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Inquiry Date *</label>
                  <input type="date" className="form-control" value={form.inquiry_date} onChange={e => setForm({ ...form, inquiry_date: e.target.value })} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Quotation Submission Date *</label>
                  <input type="date" className="form-control" value={form.sub_date} onChange={e => setForm({ ...form, sub_date: e.target.value })} required />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Tentative Shipment Date</label>
                  <input type="date" className="form-control" value={form.ship_date} onChange={e => setForm({ ...form, ship_date: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Offer Qty *</label>
                  <input type="number" className="form-control" value={form.offer_qty} onChange={e => setForm({ ...form, offer_qty: parseInt(e.target.value) || 0 })} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Order UOM *</label>
                  <select className="form-control" value={form.uom} onChange={e => setForm({ ...form, uom: e.target.value })}>
                    <option value="Pcs">Pcs</option>
                    <option value="Set">Set</option>
                    <option value="Pack">Pack</option>
                  </select>
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Costing Per</label>
                  <select className="form-control" value={form.costing_per} onChange={e => setForm({ ...form, costing_per: e.target.value })}>
                    <option value="1 Pcs">1 Pcs</option>
                    <option value="1 Dzn">1 Dzn</option>
                    <option value="2 Dzn">2 Dzn</option>
                    <option value="3 Dzn">3 Dzn</option>
                    <option value="4 Dzn">4 Dzn</option>
                    <option value="1 Pack">1 Pack</option>
                    <option value="1 Set">1 Set</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Item Department</label>
                  <select className="form-control" value={form.department} onChange={e => setForm({ ...form, department: e.target.value })}>
                    <option value="Kids">Kids</option>
                    <option value="Ladies">Ladies</option>
                    <option value="Mens">Mens</option>
                    <option value="Boys">Boys</option>
                    <option value="Girls">Girls</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Required Sample</label>
                  <select className="form-control" value={form.sample_req} onChange={e => setForm({ ...form, sample_req: e.target.value })}>
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                  </select>
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group" style={{ gridColumn: 'span 2' }}>
                  <label className="form-label">Garments Item * (Multiple Selection from Master)</label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', border: '1px solid #cbd5e1', padding: '10px', borderRadius: '4px', maxHeight: '110px', overflowY: 'auto' }}>
                    {itemsMaster.map(item => {
                      const isChecked = form.garments_item.split(', ').includes(item.item_name);
                      return (
                        <label key={item.id} style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer', fontSize: '12px', userSelect: 'none' }}>
                          <input 
                            type="checkbox" 
                            checked={isChecked} 
                            onChange={(e) => {
                              let currentItems = form.garments_item ? form.garments_item.split(', ') : [];
                              if (e.target.checked) {
                                if (!currentItems.includes(item.item_name)) {
                                  currentItems.push(item.item_name);
                                }
                              } else {
                                currentItems = currentItems.filter(x => x !== item.item_name);
                              }
                              setForm({ ...form, garments_item: currentItems.join(', ') });
                            }}
                          />
                          {item.item_name}
                        </label>
                      );
                    })}
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Upload Image / File</label>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', background: '#f8fafc', padding: '10px', borderRadius: '4px', border: '1px dashed #cbd5e1' }}>
                    <input 
                      type="file" 
                      accept="image/*" 
                      style={{ display: 'none' }} 
                      id="inquiry-image-upload" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setForm({ ...form, image_url: file.name });
                          alert(`File "${file.name}" uploaded successfully!`);
                        }
                      }}
                    />
                    <label htmlFor="inquiry-image-upload" className="btn btn-secondary btn-sm" style={{ cursor: 'pointer', margin: 0, textAlign: 'center' }}>
                      Browse File
                    </label>
                    {form.image_url ? (
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#e6fffa', padding: '4px 8px', borderRadius: '4px' }}>
                        <span style={{ fontSize: '11px', color: '#00695c', fontWeight: 'bold', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap', maxWidth: '130px' }}>
                          ✓ {form.image_url}
                        </span>
                        <button 
                          type="button" 
                          onClick={() => setForm({ ...form, image_url: '' })}
                          style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer', display: 'flex', alignItems: 'center', padding: '2px' }}
                          title="Delete File"
                        >
                          <Trash size={12} />
                        </button>
                      </div>
                    ) : (
                      <span style={{ fontSize: '11px', color: '#64748b', textAlign: 'center' }}>No file uploaded</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Quoted By (Automatic)</label>
                  <input type="text" className="form-control" value={form.quoted_by} disabled style={{ background: '#f1f5f9', cursor: 'not-allowed' }} />
                </div>
                <div className="form-group" style={{ gridColumn: 'span 2' }}>
                  <label className="form-label">Remarks</label>
                  <input type="text" className="form-control" value={form.remarks} onChange={e => setForm({ ...form, remarks: e.target.value })} placeholder="General remarks..." />
                </div>
              </div>

              {/* Grid sections */}
              <div className="grid-2 mt-20" style={{ borderTop: '1px solid var(--border-muted)', paddingTop: '20px' }}>
                <div>
                  <h4 style={{ marginBottom: '10px' }}>Fabric Details Table</h4>
                  <div className="form-row">
                    <div className="form-group">
                      <label className="form-label">Fabric Composition *</label>
                      <input type="text" className="form-control" value={composition} onChange={e => setComposition(e.target.value)} placeholder="e.g. 100% Cotton" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Fabric Type *</label>
                      <input type="text" className="form-control" value={fabricType} onChange={e => setFabricType(e.target.value)} placeholder="e.g. Single Jersey" />
                    </div>
                  </div>
                  <div className="grid-3">
                    <div className="form-group">
                      <label className="form-label">GSM/OZ</label>
                      <input type="number" className="form-control" value={gsm} onChange={e => setGsm(parseInt(e.target.value) || 0)} />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Dia</label>
                      <input type="number" className="form-control" value={dia} onChange={e => setDia(parseInt(e.target.value) || 0)} />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Dia Type</label>
                      <input type="text" className="form-control" value={diaType} onChange={e => setDiaType(e.target.value)} placeholder="Open/Tubular" />
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label className="form-label">Rate</label>
                      <input type="number" className="form-control" value={fabricRate} onChange={e => setFabricRate(parseFloat(e.target.value) || 0)} />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Required Qty</label>
                      <input type="number" className="form-control" value={requiredQty} onChange={e => setRequiredQty(parseFloat(e.target.value) || 0)} />
                    </div>
                  </div>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={handleAddFabricLine}>Add Fabric Line</button>

                  <div className="table-wrapper mt-20" style={{ maxHeight: '120px' }}>
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>Comp</th>
                          <th>Type</th>
                          <th>Qty</th>
                        </tr>
                      </thead>
                      <tbody>
                        {fabricsList.map((f, i) => (
                          <tr key={i}>
                            <td>{f.composition}</td>
                            <td>{f.fabric_type}</td>
                            <td>{f.required_qty} kg</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div>
                  <h4 style={{ marginBottom: '10px' }}>Yarn Details Table</h4>
                  <div className="form-row">
                    <div className="form-group">
                      <label className="form-label">Yarn Composition *</label>
                      <input type="text" className="form-control" value={yarnComposition} onChange={e => setYarnComposition(e.target.value)} placeholder="e.g. 100% Cotton Organic" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Yarn Count *</label>
                      <input type="text" className="form-control" value={yarnCount} onChange={e => setYarnCount(e.target.value)} placeholder="30s" />
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label className="form-label">Yarn Type *</label>
                      <input type="text" className="form-control" value={yarnType} onChange={e => setYarnType(e.target.value)} placeholder="Combed" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Certification</label>
                      <input type="text" className="form-control" value={yarnCert} onChange={e => setYarnCert(e.target.value)} placeholder="GOTS" />
                    </div>
                  </div>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={handleAddYarnLine}>Add Yarn Line</button>

                  <div className="table-wrapper mt-20" style={{ maxHeight: '120px' }}>
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>Composition</th>
                          <th>Count</th>
                          <th>Type</th>
                        </tr>
                      </thead>
                      <tbody>
                        {yarnsList.map((y, i) => (
                          <tr key={i}>
                            <td>{y.yarn_composition}</td>
                            <td>{y.yarn_count}</td>
                            <td>{y.yarn_type}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div className="mt-20 text-right">
                <button type="button" className="btn btn-secondary mr-10" style={{ marginRight: '10px' }} onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary"><Save size={16} /> Save Inquiry Log</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================================================
// SUB-VIEW: Costing & Price Quotations (Includes ALL spreadsheet fields)
// ==========================================================================
function CostingView({ buyers: _buyers, items: _items }: { buyers: any[], items: any[] }) {
  const [quotations, setQuotations] = useState<any[]>([]);
  const [inquiries, setInquiries] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedInquiryId, setSelectedInquiryId] = useState('');
  const [costingTab, setCostingTab] = useState<'required' | 'others' | 'costing_grid'>('required');
  const [yarnCert, _setYarnCert] = useState('GOTS');

  // Direct Cost States
  const [fabrics, setFabrics] = useState<any[]>([]);
  const [trims, setTrims] = useState<any[]>([]);
  const [embs, setEmbs] = useState<any[]>([]);
  const [washes, setWashes] = useState<any[]>([]);

  // Other Cost Inputs
  const [desiredMargin, setDesiredMargin] = useState(5.0);
  const [commercialPct, setCommercialPct] = useState(5.0);
  const [commissionPct, setCommissionPct] = useState(0.0);
  const [totalCost, setTotalCost] = useState(0);
  const [fobDoz, setFobDoz] = useState(0);
  const [fobPc, setFobPc] = useState(0);
  const [cmDoz, setCmDoz] = useState(0);

  // Spreadsheet required costing fields
  const [sizeGroup, setSizeGroup] = useState('4-8 Years');
  const [mcLine, setMcLine] = useState(12);
  const [prodLineHour, setProdLineHour] = useState(150);
  const [sewingEfficiency, setSewingEfficiency] = useState(65);
  const [cuttingEfficiency, setCuttingEfficiency] = useState(80);
  const [finishingEfficiency, setFinishingEfficiency] = useState(85);
  const [qcEfficiency, _setQcEfficiency] = useState(90);
  const [prepEfficiency, _setPrepEfficiency] = useState(90);
  const [sizeGrading, setSizeGrading] = useState(2);
  
  // SMV Bulletins Grid
  const [smvRows, setSmvRows] = useState<any[]>([
    { item_name: 'Girls Swimming Costume', set_ratio: 1, cutting_smv: 1.5, sewing_smv: 12.0, finishing_smv: 3.0 }
  ]);
  const [bulletinGmtItem, setBulletinGmtItem] = useState('');
  const [bulletinSetRatio, setBulletinSetRatio] = useState(1);
  const [bulletinCut, setBulletinCut] = useState(0.0);
  const [bulletinSew, setBulletinSew] = useState(0.0);
  const [bulletinFin, setBulletinFin] = useState(0.0);

  // Production Yarn Costing sub-form
  const [yarnCostsList, setYarnCostsList] = useState<any[]>([]);
  const [ycComp, setYcComp] = useState('');
  const [ycCount, setYcCount] = useState('30s');
  const [ycType, setYcType] = useState('Combed');
  const [ycPct, setYcPct] = useState(100);
  const [ycColor, setYcColor] = useState('Red');
  const [ycQty, setYcQty] = useState(100);
  const [ycLoss, _setYcLoss] = useState(5);
  const [ycSupplier, _setYcSupplier] = useState('');
  const [ycRate, setYcRate] = useState(3.5);

  // Others Info Tab
  const [country, setCountry] = useState('Bangladesh');
  const [buyingAgent, setBuyingAgent] = useState('Zara Agent');
  const [buyingHouseMerchant, setBuyingHouseMerchant] = useState('Inditex Merchandiser');
  const [currency, setCurrency] = useState('USD');
  const [colorRange, setColorRange] = useState('Solid Multi');
  const [sustainableMaterial, setSustainableMaterial] = useState('BCI');
  const [garmentsCert, _setGarmentsCert] = useState('OEKOTEX');
  const [_embType, _setEmbType] = useState('Print');
  const [embName, _setEmbName] = useState('Placement Print');
  const [confirmDate, _setConfirmDate] = useState('');
  const [exchangeRate, setExchangeRate] = useState(1.0);
  const [pcsPerCarton, setPcsPerCarton] = useState(24);
  const [cbmPerCarton, setCbmPerCarton] = useState(0.08);

  // Dynamic calculations
  const [cmPctOnFob, setCmPctOnFob] = useState(0);
  const [cmcPctOnFob, setCmcPctOnFob] = useState(0);

  useEffect(() => {
    fetchQuotations();
    fetchInquiries();
  }, []);

  const getCalculatedTotalSMV = () => {
    if (smvRows.length === 0) return 1.0; // Default to 1 as per Excel spec
    return smvRows.reduce((sum, r) => sum + (parseFloat(r.cutting_smv || 0) + parseFloat(r.sewing_smv || 0) + parseFloat(r.finishing_smv || 0)), 0);
  };

  useEffect(() => {
    calculateTotalCost();
  }, [fabrics, trims, embs, washes, smvRows, desiredMargin, commercialPct, commissionPct, sewingEfficiency]);

  const fetchQuotations = async () => {
    try {
      const res = await fetch(`${API_BASE}/quotations`);
      const data = await res.json();
      setQuotations(data);
    } catch (e) { console.error(e); }
  };

  const fetchInquiries = async () => {
    try {
      const res = await fetch(`${API_BASE}/inquiries`);
      const data = await res.json();
      setInquiries(data.filter((i: any) => i.status === 'Approved' || i.status === 'Draft'));
    } catch (e) { console.error(e); }
  };

  const handleInquiryChange = async (inqId: string) => {
    setSelectedInquiryId(inqId);
    if (!inqId) return;

    try {
      const res = await fetch(`${API_BASE}/inquiries/${inqId}`);
      const data = await res.json();

      setBuyingAgent(data.brand || 'Zara Agent');
      
      // Auto-set SMV row from items Master or inquiry
      setSmvRows([
        { item_name: data.garments_item || 'Girls Swimming Costume', set_ratio: 1, cutting_smv: 1.5, sewing_smv: 12.0, finishing_smv: 3.0 }
      ]);

      if (data.fabrics) {
        const mappedFabrics = data.fabrics.map((f: any) => ({
          item_name: data.garments_item || 'Swimming Costume',
          body_part: 'Body',
          part_type: 'Shell Fabric',
          color_range: 'Solid',
          color_nature: 'Conventional',
          composition: f.composition,
          fabric_type: f.fabric_type,
          source: 'Purchase',
          supplier: 'Default Supplier',
          gsm: f.gsm,
          dia_type: f.dia_type,
          cons_basis: 'Marker',
          uom: 'Kg',
          grey_cons: 3.8, 
          rate: f.rate || 5.5,
          amount: 3.8 * (f.rate || 5.5),
          total_qty: 3.8,
          total_amount: 3.8 * (f.rate || 5.5),
          process_loss_pct: 10
        }));
        setFabrics(mappedFabrics);
      }

      setTrims([
        { item_name: 'Sewing Thread', item_desc: 'Spun Polyester', cons_uom: 'Cones', cons_unit: 1.5, extra_pct: 15, total_cons: 1.72, rate: 1.2, amount: 2.06, supplier: 'Coats' },
        { item_name: 'Buttons', item_desc: 'Plastic Button', cons_uom: 'Pcs', cons_unit: 12, extra_pct: 5, total_cons: 12.6, rate: 0.1, amount: 1.26, supplier: 'Local supplier' }
      ]);
      setEmbs([
        { emb_type: 'Print', emb_name: 'Rubber Print', item_name: 'Garment', description: 'Front print', body_part: 'Body Front', cons_unit: 12, process_loss_pct: 5, total_qty: 12.6, rate: 0.15, amount: 1.89, supplier: 'Emb Print Ltd' }
      ]);
      setWashes([
        { wash_type: 'Wash', wash_name: 'Softener Wash', item_name: 'Garment', description: 'Soft rinse', body_part: 'Full', cons_unit: 12, process_loss_pct: 2, total_qty: 12.24, rate: 0.08, amount: 0.98, supplier: 'Local Wash Co' }
      ]);
    } catch (e) { console.error(e); }
  };

  const handleAddSmvRow = () => {
    if (!bulletinGmtItem) return alert("Enter item name first.");
    setSmvRows([...smvRows, {
      item_name: bulletinGmtItem,
      set_ratio: bulletinSetRatio,
      cutting_smv: bulletinCut,
      sewing_smv: bulletinSew,
      finishing_smv: bulletinFin
    }]);
    setBulletinGmtItem('');
    setBulletinCut(0);
    setBulletinSew(0);
    setBulletinFin(0);
  };

  const handleAddYarnCostLine = () => {
    if (!ycComp) return alert("Fill composition first.");
    const totalAmount = ycQty * ycRate;
    setYarnCostsList([...yarnCostsList, {
      yarn_composition: ycComp,
      yarn_count: ycCount,
      yarn_type: ycType,
      percentage: ycPct,
      color: ycColor,
      cons_qty: ycQty,
      process_loss_pct: ycLoss,
      supplier: ycSupplier,
      rate: ycRate,
      amount: totalAmount
    }]);
    setYcComp('');
  };

  const calculateTotalCost = () => {
    const totalFabric = fabrics.reduce((sum, f) => sum + parseFloat(f.amount || 0), 0);
    const totalTrims = trims.reduce((sum, t) => sum + parseFloat(t.amount || 0), 0);
    const totalEmb = embs.reduce((sum, e) => sum + parseFloat(e.amount || 0), 0);
    const totalWash = washes.reduce((sum, w) => sum + parseFloat(w.amount || 0), 0);

    const activeSMV = getCalculatedTotalSMV();
    const laborRateMin = 150 / (26 * 8 * 60); // approx $0.012/min
    const cmValue = (activeSMV * laborRateMin * 12) / (sewingEfficiency / 100);
    setCmDoz(cmValue);

    const directCost = totalFabric + totalTrims + totalEmb + totalWash + cmValue;
    setTotalCost(directCost);

    const divisor = 1 - (commercialPct / 100) - (commissionPct / 100);
    const fobPriceDoz = divisor > 0 ? (directCost + desiredMargin) / divisor : 0;
    setFobDoz(fobPriceDoz);
    
    const singleFob = fobPriceDoz / 12;
    setFobPc(singleFob);

    // Standardized CM% and CMC% calculation equations from Excel
    const computedCmPct = singleFob > 0 ? (((12 / 12) * cmValue + desiredMargin) / fobPriceDoz) * 100 : 0;
    setCmPctOnFob(computedCmPct);
    setCmcPctOnFob(commercialPct + commissionPct + computedCmPct);
  };

  const handleSaveQuotation = async () => {
    if (!selectedInquiryId) return alert("Select an Inquiry first.");
    const inquiry = inquiries.find(i => i.id === selectedInquiryId);

    const payload = {
      inquiry_id: selectedInquiryId,
      style_no: inquiry?.style_no,
      status: 'Pending',
      desired_margin: desiredMargin,
      commercial_pct: commercialPct,
      commission_pct: commissionPct,
      total_cost: totalCost,
      fob_price_doz: fobDoz,
      fob_price_pc: fobPc,
      cm_value: cmDoz,
      cmc_pct: cmcPctOnFob,
      comments: `Calculated from bulletin SMV: ${getCalculatedTotalSMV()}`,
      
      // Cost specs
      size_group: sizeGroup,
      mc_line: mcLine,
      prod_line_hour: prodLineHour,
      sewing_efficiency: sewingEfficiency,
      cutting_efficiency: cuttingEfficiency,
      finishing_efficiency: finishingEfficiency,
      qc_efficiency: qcEfficiency,
      prep_efficiency: prepEfficiency,
      yarn_cert: yarnCert,
      size_grading: sizeGrading,
      exchange_rate: exchangeRate,
      pcs_per_carton: pcsPerCarton,
      cbm_per_carton: cbmPerCarton,
      country: country,
      buying_agent: buyingAgent,
      buying_house_merchant: buyingHouseMerchant,
      currency: currency,
      color_range: colorRange,
      sustainable_material: sustainableMaterial,
      garments_cert: garmentsCert,
      confirm_date: confirmDate,
      quotation_date: new Date().toISOString().split('T')[0],
      order_placement_date: order_placement_date_state,
      embellishment_note: embName,
      incoterm_place: country,

      fabrics,
      trims,
      embs,
      washes,
      smvs: smvRows,
      yarns: yarnCostsList
    };

    try {
      const res = await fetch(`${API_BASE}/quotations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        setShowModal(false);
        fetchQuotations();
      }
    } catch (e) { console.error(e); }
  };

  const handleApprove = async (id: string) => {
    try {
      const q = quotations.find(item => item.id === id);
      await fetch(`${API_BASE}/quotations/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...q, status: 'Approved', approved_by: 'Supervisor', approve_date: new Date().toISOString().split('T')[0] })
      });
      fetchQuotations();
    } catch (e) { console.error(e); }
  };

  const [order_placement_date_state, setOrderPlacementDateState] = useState('');

  return (
    <div className="dashboard-card">
      <div className="card-header">
        <h2 className="card-title"><DollarSign /> Price Quotations Costing</h2>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={16} /> Costing Engine
        </button>
      </div>

      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Quotation ID</th>
              <th>Style No</th>
              <th>Buyer</th>
              <th>Total Cost /Dzn</th>
              <th>FOB /Dzn</th>
              <th>FOB /Pc</th>
              <th>CM /Dzn</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {quotations.map((q, idx) => (
              <tr key={idx}>
                <td><strong>{q.id}</strong></td>
                <td>{q.style_no}</td>
                <td>{q.buyer_name}</td>
                <td>${parseFloat(q.total_cost || 0).toFixed(2)}</td>
                <td>${parseFloat(q.fob_price_doz || 0).toFixed(2)}</td>
                <td style={{ color: 'var(--secondary)', fontWeight: 600 }}>${parseFloat(q.fob_price_pc || 0).toFixed(2)}</td>
                <td>${parseFloat(q.cm_value || 0).toFixed(2)}</td>
                <td>
                  <span className={`badge badge-${q.status.toLowerCase()}`}>{q.status}</span>
                </td>
                <td>
                  {q.status === 'Pending' && (
                    <button className="btn btn-success btn-sm" onClick={() => handleApprove(q.id)}>
                      Approve Costing
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '950px' }}>
            <div className="modal-header">
              <h3>Direct Material & Labor Costing Engine</h3>
              <XCircle className="modal-close" onClick={() => setShowModal(false)} />
            </div>

            <div className="tab-container">
              <div className={`tab ${costingTab === 'required' ? 'active' : ''}`} onClick={() => setCostingTab('required')}>Required Info (Tab 1)</div>
              <div className={`tab ${costingTab === 'others' ? 'active' : ''}`} onClick={() => setCostingTab('others')}>Others Info (Tab 2)</div>
              <div className={`tab ${costingTab === 'costing_grid' ? 'active' : ''}`} onClick={() => setCostingTab('costing_grid')}>Detailed Cost Grids</div>
            </div>

            {costingTab === 'required' && (
              <div>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Link Quotation Inquiry ID *</label>
                    <select className="form-control" value={selectedInquiryId} onChange={e => handleInquiryChange(e.target.value)}>
                      <option value="">Select Inquiry</option>
                      {inquiries.map(inq => <option key={inq.id} value={inq.id}>{inq.id} ({inq.style_no})</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Size Group *</label>
                    <input type="text" className="form-control" value={sizeGroup} onChange={e => setSizeGroup(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Desired Margin ($/Dzn) *</label>
                    <input type="number" className="form-control" value={desiredMargin} onChange={e => setDesiredMargin(parseFloat(e.target.value) || 0)} />
                  </div>
                </div>

                <div className="grid-3 mt-10">
                  <div className="form-group">
                    <label className="form-label">MC/Line *</label>
                    <input type="number" className="form-control" value={mcLine} onChange={e => setMcLine(parseInt(e.target.value) || 0)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Production/Line/Hour *</label>
                    <input type="number" className="form-control" value={prodLineHour} onChange={e => setProdLineHour(parseInt(e.target.value) || 0)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Size Grading (%)</label>
                    <input type="number" className="form-control" value={sizeGrading} onChange={e => setSizeGrading(parseFloat(e.target.value) || 0)} />
                  </div>
                </div>

                <div className="grid-3">
                  <div className="form-group">
                    <label className="form-label">Sewing Efficiency %</label>
                    <input type="number" className="form-control" value={sewingEfficiency} onChange={e => setSewingEfficiency(parseFloat(e.target.value) || 0)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Cutting Efficiency %</label>
                    <input type="number" className="form-control" value={cuttingEfficiency} onChange={e => setCuttingEfficiency(parseFloat(e.target.value) || 0)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Finishing Efficiency %</label>
                    <input type="number" className="form-control" value={finishingEfficiency} onChange={e => setFinishingEfficiency(parseFloat(e.target.value) || 0)} />
                  </div>
                </div>

                <h4 style={{ margin: '20px 0 10px 0', borderBottom: '1px solid var(--border-muted)', paddingBottom: '8px' }}>SMV Bulletin Calculation</h4>
                <div className="grid-2">
                  <div>
                    <div className="form-row">
                      <div className="form-group">
                        <label className="form-label">Gmt Item Name</label>
                        <input type="text" className="form-control" value={bulletinGmtItem} onChange={e => setBulletinGmtItem(e.target.value)} placeholder="Basic T-Shirt" />
                      </div>
                      <div className="form-group">
                        <label className="form-label">Set Ratio</label>
                        <input type="number" className="form-control" value={bulletinSetRatio} onChange={e => setBulletinSetRatio(parseInt(e.target.value) || 1)} />
                      </div>
                    </div>
                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Cutting SMV</label>
                        <input type="number" className="form-control" value={bulletinCut} onChange={e => setBulletinCut(parseFloat(e.target.value) || 0)} />
                      </div>
                      <div className="form-group">
                        <label className="form-label">Sewing SMV</label>
                        <input type="number" className="form-control" value={bulletinSew} onChange={e => setBulletinSew(parseFloat(e.target.value) || 0)} />
                      </div>
                      <div className="form-group">
                        <label className="form-label">Finishing SMV</label>
                        <input type="number" className="form-control" value={bulletinFin} onChange={e => setBulletinFin(parseFloat(e.target.value) || 0)} />
                      </div>
                    </div>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={handleAddSmvRow}>Add Item to SMV Bulletin</button>
                  </div>
                  <div>
                    <div className="table-wrapper" style={{ maxHeight: '180px' }}>
                      <table className="data-table">
                        <thead>
                          <tr>
                            <th>Item Name</th>
                            <th>Ratio</th>
                            <th>SMV Sum</th>
                          </tr>
                        </thead>
                        <tbody>
                          {smvRows.map((r, i) => (
                            <tr key={i}>
                              <td>{r.item_name}</td>
                              <td>{r.set_ratio}</td>
                              <td>{(parseFloat(r.cutting_smv)+parseFloat(r.sewing_smv)+parseFloat(r.finishing_smv)).toFixed(2)} min</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {costingTab === 'others' && (
              <div>
                <div className="grid-3">
                  <div className="form-group">
                    <label className="form-label">Country</label>
                    <input type="text" className="form-control" value={country} onChange={e => setCountry(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Buying Agent</label>
                    <input type="text" className="form-control" value={buyingAgent} onChange={e => setBuyingAgent(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Buying House Merchant</label>
                    <input type="text" className="form-control" value={buyingHouseMerchant} onChange={e => setBuyingHouseMerchant(e.target.value)} />
                  </div>
                </div>

                <div className="grid-3">
                  <div className="form-group">
                    <label className="form-label">Currency</label>
                    <select className="form-control" value={currency} onChange={e => setCurrency(e.target.value)}>
                      <option value="USD">USD</option>
                      <option value="EUR">EUR</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Color Range</label>
                    <input type="text" className="form-control" value={colorRange} onChange={e => setColorRange(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Sustainable Material *</label>
                    <select className="form-control" value={sustainableMaterial} onChange={e => setSustainableMaterial(e.target.value)}>
                      <option value="BCI">BCI</option>
                      <option value="GOTS">GOTS</option>
                      <option value="OCS">OCS</option>
                      <option value="RCS/GRS">RCS/GRS</option>
                      <option value="OEKOTEX">OEKOTEX</option>
                      <option value="CONVENTIONAL">CONVENTIONAL</option>
                    </select>
                  </div>
                </div>

                <div className="grid-3">
                  <div className="form-group">
                    <label className="form-label">Exchange Rate</label>
                    <input type="number" className="form-control" value={exchangeRate} onChange={e => setExchangeRate(parseFloat(e.target.value) || 1.0)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Pcs / Carton</label>
                    <input type="number" className="form-control" value={pcsPerCarton} onChange={e => setPcsPerCarton(parseInt(e.target.value) || 24)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">CBM / Carton</label>
                    <input type="number" className="form-control" value={cbmPerCarton} onChange={e => setCbmPerCarton(parseFloat(e.target.value) || 0.08)} />
                  </div>
                </div>

                <div className="grid-3">
                  <div className="form-group">
                    <label className="form-label">Commercial Cost Rate (%)</label>
                    <input type="number" className="form-control" value={commercialPct} onChange={e => setCommercialPct(parseFloat(e.target.value) || 0)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Buying House Commission (%)</label>
                    <input type="number" className="form-control" value={commissionPct} onChange={e => setCommissionPct(parseFloat(e.target.value) || 0)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Order Placement Date</label>
                    <input type="date" className="form-control" value={order_placement_date_state} onChange={e => setOrderPlacementDateState(e.target.value)} />
                  </div>
                </div>
              </div>
            )}

            {costingTab === 'costing_grid' && (
              <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                <h4 style={{ marginBottom: '8px' }}>Fabric Consumption & Cost Detailed Grid</h4>
                <div className="table-wrapper">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Gmt Item</th>
                        <th>Body Part *</th>
                        <th>Composition *</th>
                        <th>Fabric Type *</th>
                        <th>Source *</th>
                        <th>Supplier</th>
                        <th>Grey Cons *</th>
                        <th>Rate ($/Kg)</th>
                        <th>Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {fabrics.map((f, idx) => (
                        <tr key={idx}>
                          <td>{f.item_name}</td>
                          <td>{f.body_part}</td>
                          <td>{f.composition}</td>
                          <td>{f.fabric_type}</td>
                          <td>{f.source}</td>
                          <td>{f.supplier}</td>
                          <td>
                            <input
                              type="number"
                              className="detail-table-input"
                              value={f.grey_cons}
                              onChange={e => {
                                const newGrey = parseFloat(e.target.value) || 0;
                                const updated = [...fabrics];
                                updated[idx].grey_cons = newGrey;
                                updated[idx].amount = newGrey * f.rate;
                                setFabrics(updated);
                              }}
                            />
                          </td>
                          <td>{f.rate}</td>
                          <td>${parseFloat(f.amount || 0).toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Yarn Costing sub-form if source is Production */}
                {fabrics.some(f => f.source === 'Production') && (
                  <div style={{ border: '1px solid var(--primary-glow)', borderRadius: 'var(--radius-md)', padding: '16px', marginTop: '20px' }}>
                    <h4 style={{ color: 'var(--primary)', marginBottom: '10px' }}>Yarn Costing (For Production Source Fabrics)</h4>
                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Yarn Composition *</label>
                        <input type="text" className="form-control" value={ycComp} onChange={e => setYcComp(e.target.value)} placeholder="100% Cotton" />
                      </div>
                      <div className="form-group">
                        <label className="form-label">Yarn Count *</label>
                        <input type="text" className="form-control" value={ycCount} onChange={e => setYcCount(e.target.value)} />
                      </div>
                      <div className="form-group">
                        <label className="form-label">Yarn Type *</label>
                        <input type="text" className="form-control" value={ycType} onChange={e => setYcType(e.target.value)} />
                      </div>
                    </div>
                    <div className="grid-4">
                      <div className="form-group">
                        <label className="form-label">Percentage %</label>
                        <input type="number" className="form-control" value={ycPct} onChange={e => setYcPct(parseInt(e.target.value) || 100)} />
                      </div>
                      <div className="form-group">
                        <label className="form-label">Color</label>
                        <input type="text" className="form-control" value={ycColor} onChange={e => setYcColor(e.target.value)} />
                      </div>
                      <div className="form-group">
                        <label className="form-label">Cons Qty (Kg)</label>
                        <input type="number" className="form-control" value={ycQty} onChange={e => setYcQty(parseFloat(e.target.value) || 0)} />
                      </div>
                      <div className="form-group">
                        <label className="form-label">Rate ($/Kg)</label>
                        <input type="number" className="form-control" value={ycRate} onChange={e => setYcRate(parseFloat(e.target.value) || 0)} />
                      </div>
                    </div>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={handleAddYarnCostLine}>Add Yarn Cost Line</button>
                    
                    <div className="table-wrapper mt-20" style={{ maxHeight: '120px' }}>
                      <table className="data-table">
                        <thead>
                          <tr>
                            <th>Yarn Comp</th>
                            <th>Count</th>
                            <th>Color</th>
                            <th>Qty</th>
                            <th>Rate</th>
                            <th>Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                          {yarnCostsList.map((yc, idx) => (
                            <tr key={idx}>
                              <td>{yc.yarn_composition}</td>
                              <td>{yc.yarn_count}</td>
                              <td>{yc.color}</td>
                              <td>{yc.cons_qty} kg</td>
                              <td>${yc.rate}</td>
                              <td>${parseFloat(yc.amount || 0).toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                <h4 style={{ margin: '20px 0 8px 0' }}>Trims / Accessories Cost Detailed Grid</h4>
                <div className="table-wrapper">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Item Name *</th>
                        <th>UOM</th>
                        <th>Cons/Unit Gmt *</th>
                        <th>Extra %</th>
                        <th>Total Cons</th>
                        <th>Rate *</th>
                        <th>Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {trims.map((t, idx) => (
                        <tr key={idx}>
                          <td>{t.item_name}</td>
                          <td>{t.cons_uom}</td>
                          <td>{t.cons_unit}</td>
                          <td>{t.extra_pct}%</td>
                          <td>{t.total_cons}</td>
                          <td>
                            <input
                              type="number"
                              className="detail-table-input"
                              value={t.rate}
                              onChange={e => {
                                const newRate = parseFloat(e.target.value) || 0;
                                const updated = [...trims];
                                updated[idx].rate = newRate;
                                updated[idx].amount = t.total_cons * newRate;
                                setTrims(updated);
                              }}
                            />
                          </td>
                          <td>${parseFloat(t.amount || 0).toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <h4 style={{ margin: '20px 0 8px 0' }}>Embellishments Cost Detailed Grid</h4>
                <div className="table-wrapper">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Emb Type *</th>
                        <th>Emb Name *</th>
                        <th>Cons/Unit *</th>
                        <th>Rate *</th>
                        <th>Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {embs.map((e, idx) => (
                        <tr key={idx}>
                          <td>{e.emb_type}</td>
                          <td>{e.emb_name}</td>
                          <td>{e.cons_unit}</td>
                          <td>{e.rate}</td>
                          <td>${parseFloat(e.amount || 0).toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Overall Costs Dashboard Preview */}
            <div className="metrics-grid mt-20" style={{ marginBottom: '20px' }}>
              <div className="metric-card" style={{ padding: '16px' }}>
                <div className="metric-details">
                  <h3>Direct Costs (Dzn)</h3>
                  <div className="metric-value" style={{ fontSize: '1.1rem' }}>${(totalCost - cmDoz).toFixed(2)}</div>
                </div>
              </div>
              <div className="metric-card" style={{ padding: '16px' }}>
                <div className="metric-details">
                  <h3>CM Labor (Dzn)</h3>
                  <div className="metric-value" style={{ fontSize: '1.1rem', color: 'var(--info)' }}>${cmDoz.toFixed(2)}</div>
                </div>
              </div>
              <div className="metric-card" style={{ padding: '16px' }}>
                <div className="metric-details">
                  <h3>CM% on FOB</h3>
                  <div className="metric-value" style={{ fontSize: '1.1rem', color: 'var(--warning)' }}>{cmPctOnFob.toFixed(1)}%</div>
                </div>
              </div>
              <div className="metric-card" style={{ padding: '16px', background: 'var(--secondary-glow)' }}>
                <div className="metric-details">
                  <h3 style={{ color: 'var(--secondary)' }}>Est. FOB /Pc</h3>
                  <div className="metric-value" style={{ fontSize: '1.3rem', color: 'var(--secondary)' }}>${fobPc.toFixed(2)}</div>
                </div>
              </div>
            </div>

            <div className="mt-20 text-right">
              <button className="btn btn-secondary mr-10" style={{ marginRight: '10px' }} onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSaveQuotation}><Save size={16} /> Save Costing</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================================================
// SUB-VIEW: Order Entry & PO Breakdown (Includes ALL spreadsheet fields)
// ==========================================================================
function OrderView({ buyers: _buyers }: { buyers: any[] }) {
  const [orders, setOrders] = useState<any[]>([]);
  const [quotations, setQuotations] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedQuotationId, setSelectedQuotationId] = useState('');

  const [form, setForm] = useState({
    style_no: '',
    inquiry_id: '',
    buyer: '',
    style_desc: '',
    order_status: 'Confirm',
    category: 'Jersey',
    item_group: 'Basic',
    season: '',
    team_leader: '',
    dealing_merchant: '',
    factory_merchant: '',
    currency: 'USD',
    uom: 'Pcs',
    smv: 12.0,
    repeat_no: '1',
    model_code: 101,
    garment_dept: 'Kids',
    embellishment_type: 'Print',
    embellishment_name: 'Placement Print',
    embellishment_notes: 'Eco friendly ink',
    yarn_type: 'Combed Yarn',
    yarn_cert: 'GOTS Certified',
    yarn_comp: '100% Cotton Organic',
    ship_mode: 'Sea',
    quality_label: 'A-Grade',
    style_owner: 'Fast Retailing Owner',
    garment_weight: 150,
    avg_weight: 150,
    special_instruction: 'Handle carefully',
    terms: 'L/C 60 days payment',
    status: 'Draft'
  });

  // PO booking breakdown entry state
  const [poNo, setPoNo] = useState('');
  const [poQty, setPoQty] = useState(5000);
  const [poFob, setPoFob] = useState(4.5);
  const [shipDate, setShipDate] = useState('');
  const [packingRatio, setPackingRatio] = useState('Solid Color Solid Size');
  const [delayFor, setDelayFor] = useState('None');
  const [poList, setPoList] = useState<any[]>([]);

  // Detailed fields
  const [internalRefNo, setInternalRefNo] = useState('');
  const [commFileNo, setCommFileNo] = useState('');
  const [_printQty, _setPrintQty] = useState(0);
  const [_embroideryQty, _setEmbroideryQty] = useState(0);
  const [deliveryCountry, setDeliveryCountry] = useState('USA');
  const [areaCode, setAreaCode] = useState('US-NY');
  const [cutoffDate, setCutoffDate] = useState('');
  const [cutoffVal, _setCutoffVal] = useState('Full');
  const [division, setDivision] = useState('Jersey');
  const [productType, setProductType] = useState('Regular');
  const [pcsPerPack, setPcsPerPack] = useState(1);
  const [matrixType, setMatrixType] = useState('Product with Full Quantity');

  useEffect(() => {
    fetchOrders();
    fetchQuotations();
  }, []);

  const fetchOrders = async () => {
    try {
      const res = await fetch(`${API_BASE}/orders`);
      const data = await res.json();
      setOrders(data);
    } catch (e) { console.error(e); }
  };

  const fetchQuotations = async () => {
    try {
      const res = await fetch(`${API_BASE}/quotations`);
      const data = await res.json();
      setQuotations(data.filter((q: any) => q.status === 'Approved'));
    } catch (e) { console.error(e); }
  };

  const handleQuotationChange = async (qId: string) => {
    setSelectedQuotationId(qId);
    if (!qId) return;

    try {
      const res = await fetch(`${API_BASE}/quotations/${qId}`);
      const data = await res.json();

      const inqRes = await fetch(`${API_BASE}/inquiries/${data.inquiry_id}`);
      const inq = await inqRes.json();

      setForm({
        ...form,
        style_no: data.style_no,
        inquiry_id: data.inquiry_id,
        buyer: inq.buyer_name,
        season: inq.season,
        uom: inq.uom,
        smv: data.total_smv || 16.5,
        style_desc: inq.style_desc,
        yarn_type: data.yarn_cert || 'Combed Cotton',
        yarn_comp: inq.fabrics?.[0]?.composition || '100% Cotton',
        yarn_cert: data.yarn_cert || 'OEKOTEX'
      });
      setPoFob(data.fob_price_pc);
      setShipDate(inq.ship_date);
    } catch (e) { console.error(e); }
  };

  const handleAddPO = () => {
    if (!poNo || !shipDate) return alert("Fill up PO No and Shipment Date.");
    
    const today = new Date();
    const target = new Date(shipDate);
    const leadTime = Math.ceil((target.getTime() - today.getTime()) / (1000 * 3600 * 24));
    const weekNo = Math.ceil(target.getDate() / 7); // estimate

    const breakdown = [
      { color: 'Red', size: 'M', set_qty: 1, pcs_qty: Math.floor(poQty/2), rate: poFob, ex_cut_pct: 4, plan_cut_qty: Math.floor(poQty/2 * 1.04), article_no: 'A-101', amount: Math.floor(poQty/2) * poFob, garments_item: form.style_no },
      { color: 'Blue', size: 'L', set_qty: 1, pcs_qty: Math.ceil(poQty/2), rate: poFob, ex_cut_pct: 4, plan_cut_qty: Math.ceil(poQty/2 * 1.04), article_no: 'A-102', amount: Math.ceil(poQty/2) * poFob, garments_item: form.style_no }
    ];

    setPoList([...poList, {
      po_no: poNo,
      status: 'Confirm',
      received_date: today.toISOString().split('T')[0],
      ex_factory_date: shipDate,
      ship_date: shipDate,
      week_no: weekNo,
      lead_time: leadTime > 0 ? leadTime : 60,
      po_qty: poQty,
      fob_price: poFob,
      fob_in_dzn: poFob * 12,
      carton_info: `${pcsPerPack} pcs/carton`,
      comm_file_no: commFileNo,
      packing_ratio: packingRatio,
      delay_for: delayFor,
      po_status: 'Active',
      remarks: 'Seeded breakdown',
      delivery_country: deliveryCountry,
      code: deliveryCountry.substring(0, 2),
      area: 'NY',
      area_code: areaCode,
      cutoff_date: cutoffDate,
      cutoff_val: cutoffVal,
      division: division,
      country_ship_date: shipDate,
      pack_type: 'Solid Pack',
      port_of_discharge: 'Chittagong',
      product_type: productType,
      pcs_per_pack: pcsPerPack,
      req_hanger: 'No',
      matrix_type: matrixType,
      breakdown
    }]);

    setPoNo('');
  };

  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.style_no || poList.length === 0) {
      alert("Missing style number or PO breakdown list.");
      return;
    }

    const payload = {
      ...form,
      status: 'Approved',
      pos: poList
    };

    try {
      const res = await fetch(`${API_BASE}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        setShowModal(false);
        fetchOrders();
        setPoList([]);
      }
    } catch (e) { console.error(e); }
  };

  return (
    <div className="dashboard-card">
      <div className="card-header">
        <h2 className="card-title"><ShoppingBag /> Confirmed Orders (Order Entry)</h2>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={16} /> New Order Entry
        </button>
      </div>

      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Style No</th>
              <th>Buyer</th>
              <th>Season</th>
              <th>Total Order Qty</th>
              <th>Order Value ($)</th>
              <th>Embellishment Spec</th>
              <th>Yarn Type</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o, idx) => (
              <tr key={idx}>
                <td><strong>ORD-{o.id}</strong></td>
                <td>{o.style_no}</td>
                <td>{o.buyer}</td>
                <td>{o.season}</td>
                <td>{parseFloat(o.total_qty || 0).toLocaleString()} pcs</td>
                <td>${parseFloat(o.total_value || 0).toLocaleString()}</td>
                <td>{o.embellishment_type} ({o.embellishment_name})</td>
                <td>{o.yarn_type}</td>
                <td>
                  <span className={`badge badge-${o.status.toLowerCase()}`}>{o.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '920px' }}>
            <div className="modal-header">
              <h3>Create New Order & PO Breakdowns</h3>
              <XCircle className="modal-close" onClick={() => setShowModal(false)} />
            </div>

            <form onSubmit={handleCreateOrder}>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Link Approved Costing *</label>
                  <select className="form-control" value={selectedQuotationId} onChange={e => handleQuotationChange(e.target.value)}>
                    <option value="">Select Approved Quotation</option>
                    {quotations.map(q => <option key={q.id} value={q.id}>{q.id} ({q.style_no})</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Style No</label>
                  <input type="text" className="form-control" value={form.style_no} disabled />
                </div>
                <div className="form-group">
                  <label className="form-label">Buyer</label>
                  <input type="text" className="form-control" value={form.buyer} disabled />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Season</label>
                  <input type="text" className="form-control" value={form.season} disabled />
                </div>
                <div className="form-group">
                  <label className="form-label">Order UOM</label>
                  <input type="text" className="form-control" value={form.uom} disabled />
                </div>
                <div className="form-group">
                  <label className="form-label">SMV (Min)</label>
                  <input type="number" className="form-control" value={form.smv} disabled />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Repeat No</label>
                  <input type="text" className="form-control" value={form.repeat_no} onChange={e => setForm({ ...form, repeat_no: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Model Code</label>
                  <input type="number" className="form-control" value={form.model_code} onChange={e => setForm({ ...form, model_code: parseInt(e.target.value) || 0 })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Garment Department</label>
                  <input type="text" className="form-control" value={form.garment_dept} onChange={e => setForm({ ...form, garment_dept: e.target.value })} />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Embellishment Type</label>
                  <select className="form-control" value={form.embellishment_type} onChange={e => setForm({ ...form, embellishment_type: e.target.value })}>
                    <option value="Print">Print</option>
                    <option value="AOP">AOP</option>
                    <option value="Embroidery">Embroidery</option>
                    <option value="Others">Others</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Embellishment Name</label>
                  <input type="text" className="form-control" value={form.embellishment_name} onChange={e => setForm({ ...form, embellishment_name: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Embellishment Notes</label>
                  <input type="text" className="form-control" value={form.embellishment_notes} onChange={e => setForm({ ...form, embellishment_notes: e.target.value })} />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Yarn Type</label>
                  <input type="text" className="form-control" value={form.yarn_type} onChange={e => setForm({ ...form, yarn_type: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Yarn Certification</label>
                  <input type="text" className="form-control" value={form.yarn_cert} onChange={e => setForm({ ...form, yarn_cert: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Yarn Composition</label>
                  <input type="text" className="form-control" value={form.yarn_comp} onChange={e => setForm({ ...form, yarn_comp: e.target.value })} />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Ship Mode</label>
                  <select className="form-control" value={form.ship_mode} onChange={e => setForm({ ...form, ship_mode: e.target.value })}>
                    <option value="Sea">Sea</option>
                    <option value="Air">Air</option>
                    <option value="Road">Road</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Quality Label</label>
                  <input type="text" className="form-control" value={form.quality_label} onChange={e => setForm({ ...form, quality_label: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Style Owner</label>
                  <input type="text" className="form-control" value={form.style_owner} onChange={e => setForm({ ...form, style_owner: e.target.value })} />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Special Instruction</label>
                  <textarea className="form-control" value={form.special_instruction} onChange={e => setForm({ ...form, special_instruction: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Terms</label>
                  <textarea className="form-control" value={form.terms} onChange={e => setForm({ ...form, terms: e.target.value })} />
                </div>
              </div>

              {/* PO Section */}
              <h4 style={{ margin: '20px 0 10px 0', borderBottom: '1px dashed var(--border-muted)', paddingBottom: '8px' }}>Purchase Order (PO) Details</h4>
              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">PO Number *</label>
                  <input type="text" className="form-control" value={poNo} onChange={e => setPoNo(e.target.value)} placeholder="e.g. PO-8871" />
                </div>
                <div className="form-group">
                  <label className="form-label">PO Quantity (Pcs) *</label>
                  <input type="number" className="form-control" value={poQty} onChange={e => setPoQty(parseInt(e.target.value) || 0)} />
                </div>
                <div className="form-group">
                  <label className="form-label">FOB Price ($/Pc)</label>
                  <input type="number" className="form-control" value={poFob} disabled />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Shipment Date *</label>
                  <input type="date" className="form-control" value={shipDate} onChange={e => setShipDate(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Packing Ratio</label>
                  <select className="form-control" value={packingRatio} onChange={e => setPackingRatio(e.target.value)}>
                    <option value="Solid Color Solid Size">Solid Color Solid Size</option>
                    <option value="Solid Color Asort Size">Solid Color Asort Size</option>
                    <option value="Asort Color Solid Size">Asort Color Solid Size</option>
                    <option value="Asort Color Asort Size">Asort Color Asort Size</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Delay For</label>
                  <select className="form-control" value={delayFor} onChange={e => setDelayFor(e.target.value)}>
                    <option value="None">None</option>
                    <option value="Knitting">Knitting</option>
                    <option value="Dyeing">Dyeing</option>
                    <option value="Garments Production">Garments Production</option>
                  </select>
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Internal Ref No</label>
                  <input type="text" className="form-control" value={internalRefNo} onChange={e => setInternalRefNo(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Comm File No</label>
                  <input type="text" className="form-control" value={commFileNo} onChange={e => setCommFileNo(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Pcs Per Pack</label>
                  <input type="number" className="form-control" value={pcsPerPack} onChange={e => setPcsPerPack(parseInt(e.target.value) || 1)} />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Delivery Country</label>
                  <input type="text" className="form-control" value={deliveryCountry} onChange={e => setDeliveryCountry(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Area Code</label>
                  <input type="text" className="form-control" value={areaCode} onChange={e => setAreaCode(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Cut-off Date</label>
                  <input type="date" className="form-control" value={cutoffDate} onChange={e => setCutoffDate(e.target.value)} />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Division</label>
                  <select className="form-control" value={division} onChange={e => setDivision(e.target.value)}>
                    <option value="Jersey">Jersey</option>
                    <option value="Lingerie">Lingerie</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Matrix Type</label>
                  <select className="form-control" value={matrixType} onChange={e => setMatrixType(e.target.value)}>
                    <option value="Product with Full Quantity">Product with Full Quantity</option>
                    <option value="Packing Ratio with Product Qty">Packing Ratio with Product Qty</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Product Type</label>
                  <select className="form-control" value={productType} onChange={e => setProductType(e.target.value)}>
                    <option value="Regular">Regular</option>
                    <option value="Licensor">Licensor</option>
                  </select>
                </div>
              </div>

              <button type="button" className="btn btn-secondary mt-10" onClick={handleAddPO}>Add PO Breakdown Link</button>

              <div className="table-wrapper mt-20">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>PO No</th>
                      <th>Qty (Pcs)</th>
                      <th>FOB</th>
                      <th>Ship Date</th>
                      <th>Lead Time</th>
                      <th>Packing Ratio</th>
                      <th>Color-Size Breakdowns</th>
                    </tr>
                  </thead>
                  <tbody>
                    {poList.map((po, idx) => (
                      <tr key={idx}>
                        <td>{po.po_no}</td>
                        <td>{po.po_qty} pcs</td>
                        <td>${po.fob_price}</td>
                        <td>{po.ship_date}</td>
                        <td>{po.lead_time} days</td>
                        <td>{po.packing_ratio}</td>
                        <td>
                          {po.breakdown.map((b: any, i: number) => (
                            <span key={i} className="badge badge-draft" style={{ marginRight: '4px' }}>
                              {b.color}-{b.size} ({b.pcs_qty} pcs, Ex: {b.ex_cut_pct}%)
                            </span>
                          ))}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-20 text-right">
                <button type="button" className="btn btn-secondary mr-10" style={{ marginRight: '10px' }} onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary"><Save size={16} /> Save Confirmed Order</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// Legacy inline FabricBookingView removed. Replaced by import from ./FabricBookingView.tsx

// ==========================================================================
// SUB-VIEW: Trims Booking (Includes Thread/Carton Formulas + VALIDATIONS)
// ==========================================================================
function TrimsBookingView() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [budgets, setBudgets] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const [form, setForm] = useState({
    booking_reference: '',
    budget_id: '',
    basis: 'Main',
    main_booking_id: '',
    booking_date: new Date().toISOString().split('T')[0],
    source: 'Non-Epz/Local',
    supplier_name: 'Coats Thread',
    delivery_date: '',
    inhouse_date: '',
    pay_mode: 'Credit',
    currency: 'USD',
    attention: 'Attention trims manager',
    remarks: 'Approved trims booking',
    booking_label: 'Style Label',
    terms_conditions: 'Standard inspection check'
  });

  // Trims Booking item specs
  const [trimType, setTrimType] = useState<'Thread' | 'Carton'>('Thread');
  const [gmtQty, setGmtQty] = useState(10000);
  const [rate, setRate] = useState(1.2);
  const [calculatedQty, setCalculatedQty] = useState(0);

  useEffect(() => {
    fetchBookings();
    fetchBudgets();
  }, []);

  useEffect(() => {
    // Thread Formula: qty * 15m * 1.15 / 5000 -> ceil
    if (trimType === 'Thread') {
      const totalMeters = gmtQty * 15 * 1.15;
      const cones = Math.ceil(totalMeters / 5000);
      setCalculatedQty(cones);
      setRate(1.2);
    } else {
      // Carton Formula: ceil(qty / 24) * 1.02
      const cartons = Math.ceil(gmtQty / 24) * 1.02;
      setCalculatedQty(Math.ceil(cartons));
      setRate(2.5);
    }
  }, [trimType, gmtQty]);

  const fetchBookings = async () => {
    try {
      const res = await fetch(`${API_BASE}/trims-bookings`);
      const data = await res.json();
      setBookings(data);
    } catch (e) { console.error(e); }
  };

  const fetchBudgets = async () => {
    try {
      const res = await fetch(`${API_BASE}/budgets`);
      const data = await res.json();
      setBudgets(data.filter((b: any) => b.status === 'Approved'));
    } catch (e) { console.error(e); }
  };

  const handleCreateBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!form.budget_id) return alert("Select a Budget Reference.");

    const items = [{
      po_id: 1,
      garments_color: 'Red',
      item_color: 'Red',
      item_name: trimType === 'Thread' ? 'Sewing Thread' : 'Cartons',
      item_desc: trimType === 'Thread' ? 'Spun Poly Cone' : 'Master Carton 5-Ply',
      required_qty: calculatedQty,
      work_order_qty: calculatedQty,
      excess_pct: trimType === 'Thread' ? 15 : 2,
      final_wo_qty: calculatedQty,
      rate,
      amount: calculatedQty * rate
    }];

    const payload = {
      ...form,
      booking_reference: `TB-${String(Math.floor(Math.random() * 900) + 100)}-${new Date().toISOString().split('T')[0]}`,
      status: 'Approved',
      items
    };

    try {
      const res = await fetch(`${API_BASE}/trims-bookings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "Over-budget blocker triggered.");
      } else {
        setShowModal(false);
        fetchBookings();
      }
    } catch (e) {
      setErrorMsg("Failed to book trims. Please check budget limits.");
    }
  };

  return (
    <div className="dashboard-card">
      <div className="card-header">
        <h2 className="card-title"><Settings /> Trims & Accessories Bookings</h2>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={16} /> New Trims Booking
        </button>
      </div>

      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Booking ID</th>
              <th>Budget Ref</th>
              <th>Style No</th>
              <th>Basis</th>
              <th>Supplier</th>
              <th>Pay Mode</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b, idx) => (
              <tr key={idx}>
                <td><strong>{b.booking_reference}</strong></td>
                <td>{b.budget_reference}</td>
                <td>{b.style_no}</td>
                <td>{b.basis} Booking</td>
                <td>{b.supplier_name}</td>
                <td>{b.pay_mode}</td>
                <td>
                  <span className={`badge badge-${b.status.toLowerCase()}`}>{b.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '700px' }}>
            <div className="modal-header">
              <h3>Create Trims Booking</h3>
              <XCircle className="modal-close" onClick={() => setShowModal(false)} />
            </div>

            {errorMsg && (
              <div className="alert-message alert-danger">
                <AlertCircle size={16} /> {errorMsg}
              </div>
            )}

            <form onSubmit={handleCreateBooking}>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Link Production Budget *</label>
                  <select className="form-control" value={form.budget_id} onChange={e => setForm({ ...form, budget_id: e.target.value })} required>
                    <option value="">Select Budget</option>
                    {budgets.map(b => <option key={b.id} value={b.id}>{b.budget_reference} (Limit: ${parseFloat(b.total_trims_budget).toFixed(2)})</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Trim Item type</label>
                  <select className="form-control" value={trimType} onChange={e => setTrimType(e.target.value as any)}>
                    <option value="Thread">Sewing Thread (Cones)</option>
                    <option value="Carton">Cartons (Units)</option>
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Booking Scope Label</label>
                  <select className="form-control" value={form.booking_label} onChange={e => setForm({ ...form, booking_label: e.target.value })}>
                    <option value="Style Label">Style Label</option>
                    <option value="PO Label">PO Label</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Terms & Conditions</label>
                  <input type="text" className="form-control" value={form.terms_conditions} onChange={e => setForm({ ...form, terms_conditions: e.target.value })} />
                </div>
              </div>

              <div className="form-row mt-20" style={{ borderTop: '1px dashed var(--border-muted)', paddingTop: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Garment Quantity (Pcs)</label>
                  <input type="number" className="form-control" value={gmtQty} onChange={e => setGmtQty(parseInt(e.target.value) || 0)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Auto Calculated Booking Qty</label>
                  <input type="text" className="form-control" value={`${calculatedQty} ${trimType === 'Thread' ? 'Cones' : 'Cartons'}`} disabled />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Unit Rate ($)</label>
                  <input type="number" className="form-control" value={rate} onChange={e => setRate(parseFloat(e.target.value) || 0)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Estimated Supplier Cost</label>
                  <input type="text" className="form-control" value={`$${(calculatedQty * rate).toFixed(2)}`} disabled />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Supplier Name</label>
                  <input type="text" className="form-control" value={form.supplier_name} onChange={e => setForm({ ...form, supplier_name: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Payment Mode</label>
                  <select className="form-control" value={form.pay_mode} onChange={e => setForm({ ...form, pay_mode: e.target.value })}>
                    <option value="Credit">Credit</option>
                    <option value="Import">Import</option>
                    <option value="In House">In House</option>
                  </select>
                </div>
              </div>

              <div className="mt-20 text-right">
                <button type="button" className="btn btn-secondary mr-10" style={{ marginRight: '10px' }} onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary"><Save size={16} /> Place Booking</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================================================
// SUB-VIEW: Time & Action (T&A) Progress Report Tracker
// ==========================================================================
function TAProgressView() {
  const [milestones, setMilestones] = useState<any[]>([]);

  useEffect(() => {
    fetchMilestones();
  }, []);

  const fetchMilestones = async () => {
    try {
      const res = await fetch(`${API_BASE}/reports/ta-progress`);
      const data = await res.json();
      setMilestones(data);
    } catch (e) { console.error("Error fetching milestones", e); }
  };

  return (
    <div className="dashboard-card">
      <div className="card-header">
        <h2 className="card-title"><BookOpen /> Time & Action Progress Report (Style wise)</h2>
      </div>

      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Style No</th>
              <th>Buyer</th>
              <th>Season</th>
              <th>Merchant</th>
              <th>Inquiry Logged</th>
              <th>Quotation Sent</th>
              <th>Fabric Inhouse</th>
              <th>Trims Inhouse</th>
              <th>Target Shipment</th>
            </tr>
          </thead>
          <tbody>
            {milestones.map((m, idx) => {
              return (
                <tr key={idx}>
                  <td><strong>{m.style_no}</strong></td>
                  <td>{m.buyer}</td>
                  <td>{m.season}</td>
                  <td>{m.dealing_merchant || 'N/A'}</td>
                  <td>
                    <span className={`badge ${m.inquiry_date ? 'badge-approved' : 'badge-draft'}`}>
                      {m.inquiry_date ? `Done (${m.inquiry_date})` : 'Pending'}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${m.sub_date ? 'badge-approved' : 'badge-draft'}`}>
                      {m.sub_date ? `Sent (${m.sub_date})` : 'Pending'}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${m.fabric_booking_date ? 'badge-approved' : 'badge-draft'}`}>
                      {m.fabric_booking_date ? `Booked (${m.fabric_booking_date})` : 'Pending'}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${m.trims_booking_date ? 'badge-approved' : 'badge-draft'}`}>
                      {m.trims_booking_date ? `Booked (${m.trims_booking_date})` : 'Pending'}
                    </span>
                  </td>
                  <td>
                    <strong>{m.first_ship_date || 'N/A'}</strong>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
