import React, { useState, useEffect } from 'react';
import {
  Layers,
  Plus,
  Save,
  XCircle,
  AlertCircle,
  CheckCircle,
  Edit2,
  Trash2,
  Shield,
  Search,
  Printer
} from 'lucide-react';

const API_BASE = 'http://localhost:5000/api';

export function FabricBookingView() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [budgets, setBudgets] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingBooking, setEditingBooking] = useState<any>(null);
  const [viewingBooking, setViewingBooking] = useState<any>(null);
  const [errorMsg, setErrorMsg] = useState('');
  
  // Simulated access controls state
  const [simulatedRole, setSimulatedRole] = useState<'super_admin' | 'admin_user' | 'unit_user'>('super_admin');
  const userCompany = 'Demo Factory Ltd.';
  const userUnit = 'Demo Unit';

  // Search/Filter states
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');
  const [filterBuyers, setFilterBuyers] = useState<string[]>([]);
  const [filterStyles, setFilterStyles] = useState<string[]>([]);
  const [buyerInput, setBuyerInput] = useState('');
  const [styleInput, setStyleInput] = useState('');

  // Primary form fields (Phase 1)
  const [basis, setBasis] = useState<'Main' | 'Short'>('Main');
  const [selectedMainBookingIds, setSelectedMainBookingIds] = useState<string[]>([]);
  const [selectedStyle, setSelectedStyle] = useState('');
  const [selectedBudgetIds, setSelectedBudgetIds] = useState<string[]>([]);
  const [bookingDate, setBookingDate] = useState(new Date().toISOString().split('T')[0]);
  const [supplierName, setSupplierName] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [inhouseDate, setInhouseDate] = useState('');
  const [payMode, setPayMode] = useState('Credit');
  const [source, setSource] = useState('Non-Epz/Local');
  const [currency, setCurrency] = useState('USD');
  const [attention, setAttention] = useState('');
  const [remarks, setRemarks] = useState('');
  
  // Last attention suggestion
  const [attentionSuggestion, setAttentionSuggestion] = useState('');

  // Collar & Cuff Browse Popup specs
  const [showCcPopup, setShowCcPopup] = useState(false);
  const [ccList, setCcList] = useState<any[]>([]);
  const [ccPo, setCcPo] = useState('');
  const [ccColor, setCcColor] = useState('');
  const [ccGmtSize, setCcGmtSize] = useState('');
  const [ccItemSize, setCcItemSize] = useState('');
  const [ccGmtQty, setCcGmtQty] = useState(0);
  const [ccExcess, setCcExcess] = useState(0);
  // C&C Copy Checkboxes
  const [ccCopyAll, setCcCopyAll] = useState(false);
  const [ccColorWise, setCcColorWise] = useState(false);
  const [ccSizeWise, setCcSizeWise] = useState(false);
  const [ccPoWise, setCcPoWise] = useState(false);

  // Terms & Conditions Browse Popup specs
  const [showTermsPopup, setShowTermsPopup] = useState(false);
  const [selectedTerms, setSelectedTerms] = useState<string[]>([]);
  const [termsTemplates, setTermsTemplates] = useState<any[]>([
    { id: 1, text: 'Yarn Type-' },
    { id: 2, text: 'Yarn Certificate-' },
    { id: 3, text: 'GSM Tolerance -3 % & + 3. If GSM is more the +3, then extra fabrics must be arranged with FOC basis.' },
    { id: 4, text: 'Shrinkage: +-5%' },
    { id: 5, text: 'Dimensional Stability: +-3%' },
    { id: 6, text: 'CF To Rub (Wet)-' },
    { id: 7, text: 'CF To Rub (Dry)-' },
    { id: 8, text: 'Pilling Resistance-' }
  ]);
  const [newTermText, setNewTermText] = useState('');

  // Phase 2: Detailed Booking Items
  const [bookingItems, setBookingItems] = useState<any[]>([]);

  // Active sub-tab
  const [activeSubTab, setActiveSubTab] = useState<'directory' | 'approval'>('directory');

  // Approval tab filters
  const [appStartDate, setAppStartDate] = useState('');
  const [appEndDate, setAppEndDate] = useState('');
  const [appBuyers, setAppBuyers] = useState<string[]>([]);
  const [appStyles, setAppStyles] = useState<string[]>([]);
  const [appApprovalType, setAppApprovalType] = useState('All');

  useEffect(() => {
    fetchBookings();
    fetchBudgets();
    fetchLastAttention();
  }, [simulatedRole]);

  const fetchBookings = async () => {
    try {
      const res = await fetch(`${API_BASE}/fabric-bookings?role=${simulatedRole}&company=${encodeURIComponent(userCompany)}&unit=${encodeURIComponent(userUnit)}`);
      const data = await res.json();
      setBookings(data);
    } catch (e) { console.error(e); }
  };

  const fetchBudgets = async () => {
    try {
      const res = await fetch(`${API_BASE}/budgets`);
      const data = await res.json();
      // Only approved budgets can be booked
      setBudgets(data.filter((b: any) => b.status === 'Approved'));
    } catch (e) { console.error(e); }
  };



  const fetchLastAttention = async () => {
    try {
      const res = await fetch(`${API_BASE}/fabric-bookings/last-attention`);
      const data = await res.json();
      if (data.attention) {
        setAttentionSuggestion(data.attention);
      }
    } catch (e) { console.error(e); }
  };

  // Sync selectors logic
  // 1. If Select Style -> find all approved budgets matching style_no
  const handleStyleChange = (style: string) => {
    setSelectedStyle(style);
    if (!style) {
      setSelectedBudgetIds([]);
      return;
    }
    const matchingBudgets = budgets.filter(b => String(b.style_no).toLowerCase() === style.toLowerCase());
    if (matchingBudgets.length > 0) {
      setSelectedBudgetIds([matchingBudgets[0].id.toString()]);
      // Pre-fill Buyer
      setSupplierName('Apex Textiles'); // Default fallback
    }
  };

  // 2. If Select Budget Reference -> set style_no
  const handleBudgetChange = (budgetIdStr: string) => {
    if (!budgetIdStr) {
      setSelectedBudgetIds([]);
      setSelectedStyle('');
      return;
    }
    setSelectedBudgetIds([budgetIdStr]);
    const budget = budgets.find(b => b.id.toString() === budgetIdStr);
    if (budget) {
      setSelectedStyle(budget.style_no || '');
    }
  };

  // Get Data Button: fetches budget detail rows and builds booking details rows
  const handleGetData = async () => {
    if (selectedBudgetIds.length === 0) return alert("Please select at least one Budget Reference ID");
    setErrorMsg('');

    try {
      let itemsAggregated: any[] = [];

      for (let budgetId of selectedBudgetIds) {
        const res = await fetch(`${API_BASE}/budgets/${budgetId}`);
        if (!res.ok) continue;
        const budgetDetail = await res.json();

        // Loop over budget fabrics and build rows
        const fabrics = budgetDetail.fabrics || [];
        for (let fab of fabrics) {
          const consumptions = fab.consumption || [];
          for (let cons of consumptions) {
            // Check if yarn is production-based
            const isProd = String(fab.fabric_source).toLowerCase() === 'production';
            const yarnDetail = isProd && fab.yarns?.[0] ? `${fab.yarns[0].yarn_composition} ${fab.yarns[0].yarn_count}` : 'N/A';
            const embType = budgetDetail.embs?.[0]?.emb_type || 'N/A';
            const embName = budgetDetail.embs?.[0]?.emb_name || 'N/A';

            itemsAggregated.push({
              po_id: cons.po_id || 1,
              po_no: cons.po_no,
              buyer: budgetDetail.buyer,
              style_no: budgetDetail.style_no,
              garments_item: fab.gmt_item || 'Polo Shirt',
              body_parts: fab.body_part || 'Body Fabric',
              garments_color: cons.color,
              fabric_color: cons.color, // same as item color by default
              yarn_type: yarnDetail,
              embellishment_type: embType,
              embellishment_name: embName,
              fabric_type: fab.fabric_type || 'Jersey',
              fabric_composition: fab.composition || '100% Cotton',
              gsm: fab.gsm_oz || 180,
              fabric_dia: cons.dia_width || fab.dia_type || 'Open Width',
              lab_dip: '',
              garments_quantity: cons.po_qty || 0,
              total_fabric_quantity: cons.total_qty || 0,
              uom: fab.uom || 'Kg',
              budget_quantity: cons.total_qty || 0,
              work_order_quantity: cons.total_qty || 0,
              rate: cons.rate || 0.22,
              amount: (cons.total_qty || 0) * (cons.rate || 0.22),
              color: cons.color,
              size: cons.gmt_sizes || 'M',
              item_size: cons.gmt_sizes || 'M',
              excess_pct: cons.process_loss_pct || 0,
              total_qty: cons.total_qty || 0
            });
          }
        }
      }

      setBookingItems(itemsAggregated);
      if (itemsAggregated.length === 0) {
        alert("No fabric consumption records found in selected budgets.");
      }
    } catch (e) {
      console.error(e);
      setErrorMsg("Failed to retrieve budget breakdown data.");
    }
  };

  // Collar & Cuff list operations
  const handleAddCcLine = () => {
    if (!ccPo || !ccColor || !ccGmtSize || !ccItemSize) {
      return alert("Please specify PO, Color, and Sizes for the C&C row");
    }

    const newRow = {
      po_no: ccPo,
      color: ccColor,
      gmt_size: ccGmtSize,
      item_size: ccItemSize,
      gmt_qty: ccGmtQty,
      excess: ccExcess,
      total_qty: Math.ceil(ccGmtQty * (1 + ccExcess / 100))
    };

    setCcList([...ccList, newRow]);
    
    // Clear inputs
    setCcPo('');
    setCcColor('');
    setCcGmtSize('');
    setCcItemSize('');
    setCcGmtQty(0);
    setCcExcess(0);
  };

  const handleApplyCcRules = () => {
    if (bookingItems.length === 0) return alert("Please fetch booking details first!");
    
    // Apply rules based on selected options:
    // If Copy All is selected, we map the entire PO consumption to Collar & Cuff.
    let listCopy = [...ccList];
    if (ccCopyAll) {
      bookingItems.forEach(item => {
        listCopy.push({
          po_no: item.po_no,
          color: item.garments_color,
          gmt_size: item.size,
          item_size: item.item_size,
          gmt_qty: item.garments_quantity,
          excess: 10,
          total_qty: Math.ceil(item.garments_quantity * 1.1)
        });
      });
      setCcList(listCopy);
      alert("PO consumptions copied successfully to C&C grid!");
    } else {
      alert("Manual custom specifications configured.");
    }
    setShowCcPopup(false);
  };

  // Terms and conditions templates logic
  const handleToggleTerm = (text: string) => {
    if (selectedTerms.includes(text)) {
      setSelectedTerms(selectedTerms.filter(x => x !== text));
    } else {
      setSelectedTerms([...selectedTerms, text]);
    }
  };

  const handleAddTermTemplate = () => {
    if (!newTermText) return;
    const newId = termsTemplates.length + 1;
    setTermsTemplates([...termsTemplates, { id: newId, text: newTermText }]);
    setSelectedTerms([...selectedTerms, newTermText]);
    setNewTermText('');
  };

  // Search filters aggregation
  const handleAddSearchBuyer = () => {
    if (!buyerInput) return;
    if (!filterBuyers.includes(buyerInput)) {
      setFilterBuyers([...filterBuyers, buyerInput]);
    }
    setBuyerInput('');
  };

  const handleAddSearchStyle = () => {
    if (!styleInput) return;
    if (!filterStyles.includes(styleInput)) {
      setFilterStyles([...filterStyles, styleInput]);
    }
    setStyleInput('');
  };

  // Approval tab filters aggregation
  const [appBuyerInput, setAppBuyerInput] = useState('');
  const [appStyleInput, setAppStyleInput] = useState('');

  const handleAddAppBuyer = () => {
    if (!appBuyerInput) return;
    if (!appBuyers.includes(appBuyerInput)) {
      setAppBuyers([...appBuyers, appBuyerInput]);
    }
    setAppBuyerInput('');
  };

  const handleAddAppStyle = () => {
    if (!appStyleInput) return;
    if (!appStyles.includes(appStyleInput)) {
      setAppStyles([...appStyles, appStyleInput]);
    }
    setAppStyleInput('');
  };

  // Save Booking Submit
  const handleSaveBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (selectedBudgetIds.length === 0) return alert("Budget Reference is required!");
    if (bookingItems.length === 0) return alert("Please load booking items via the 'Get Data' button");

    const payload = {
      booking_reference: editingBooking 
        ? editingBooking.booking_reference 
        : `FB-${String(Math.floor(Math.random() * 900) + 100)}-${new Date().toISOString().split('T')[0]}`,
      budget_id: parseInt(selectedBudgetIds[0]),
      basis,
      main_booking_id: basis === 'Short' ? parseInt(selectedMainBookingIds[0]) : null,
      booking_date: bookingDate,
      supplier_name: supplierName || 'Apex Textiles',
      delivery_date: deliveryDate,
      inhouse_date: inhouseDate,
      pay_mode: payMode,
      source,
      currency,
      attention,
      remarks,
      collar_cuff_info: ccList,
      terms_conditions: selectedTerms.join('\n* '),
      company: userCompany,
      unit: userUnit,
      booking_by: 'Merchandiser Supervisor',
      status: editingBooking ? editingBooking.status : 'Pending',
      items: bookingItems
    };

    try {
      const url = editingBooking 
        ? `${API_BASE}/fabric-bookings/${editingBooking.id}`
        : `${API_BASE}/fabric-bookings`;

      const method = editingBooking ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "Failed to submit Fabric Booking due to budget limit blocks.");
      } else {
        alert(editingBooking ? "Booking updated successfully!" : "Fabric Booking placed successfully!");
        setShowModal(false);
        setEditingBooking(null);
        fetchBookings();
        fetchLastAttention();
      }
    } catch (e) {
      console.error(e);
      setErrorMsg("An error occurred during booking validation.");
    }
  };

  // Approve / Reject booking handler
  const handleApprovalAction = async (bookingId: number, approve: boolean) => {
    try {
      const res = await fetch(`${API_BASE}/fabric-bookings/${bookingId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: approve ? 'Approved' : 'Rejected' })
      });
      if (res.ok) {
        alert(approve ? "Booking Approved!" : "Booking Rejected!");
        fetchBookings();
      } else {
        const err = await res.json();
        alert(err.error || "Failed to update approval status.");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Initialize form for creation
  const handleOpenCreateModal = () => {
    setEditingBooking(null);
    setBasis('Main');
    setSelectedMainBookingIds([]);
    setSelectedStyle('');
    setSelectedBudgetIds([]);
    setBookingDate(new Date().toISOString().split('T')[0]);
    setSupplierName('Apex Textiles');
    setDeliveryDate('');
    setInhouseDate('');
    setPayMode('Credit');
    setSource('Non-Epz/Local');
    setCurrency('USD');
    setAttention(attentionSuggestion || '');
    setRemarks('');
    setCcList([]);
    setSelectedTerms(['Yarn Type-', 'Yarn Certificate-']);
    setBookingItems([]);
    setErrorMsg('');
    setShowModal(true);
  };

  // Initialize form for editing
  const handleOpenEditModal = async (b: any) => {
    try {
      const res = await fetch(`${API_BASE}/fabric-bookings/${b.id}`);
      if (!res.ok) return alert("Failed to fetch booking details");
      const data = await res.json();

      setEditingBooking(data);
      setBasis(data.basis || 'Main');
      setSelectedMainBookingIds(data.main_booking_id ? [data.main_booking_id.toString()] : []);
      setSelectedBudgetIds([data.budget_id.toString()]);
      
      const budget = budgets.find(x => x.id === data.budget_id);
      setSelectedStyle(budget ? budget.style_no : '');

      setBookingDate(data.booking_date || '');
      setSupplierName(data.supplier_name || '');
      setDeliveryDate(data.delivery_date || '');
      setInhouseDate(data.inhouse_date || '');
      setPayMode(data.pay_mode || 'Credit');
      setSource(data.source || 'Non-Epz/Local');
      setCurrency(data.currency || 'USD');
      setAttention(data.attention || '');
      setRemarks(data.remarks || '');
      
      try {
        setCcList(JSON.parse(data.collar_cuff_info) || []);
      } catch (e) {
        setCcList([]);
      }

      if (data.terms_conditions) {
        setSelectedTerms(data.terms_conditions.split('\n* '));
      } else {
        setSelectedTerms([]);
      }

      setBookingItems(data.items || []);
      setErrorMsg('');
      setShowModal(true);
    } catch (e) {
      console.error(e);
      alert("Error loading edit page.");
    }
  };

  // Filtered booking directory lists
  const filteredBookings = bookings.filter(b => {
    // 1. Time range check
    if (filterStartDate && b.booking_date < filterStartDate) return false;
    if (filterEndDate && b.booking_date > filterEndDate) return false;

    // 2. Buyer check
    if (filterBuyers.length > 0) {
      const matched = filterBuyers.some(x => String(b.buyer).toLowerCase().includes(x.toLowerCase()));
      if (!matched) return false;
    }

    // 3. Style/PO check
    if (filterStyles.length > 0) {
      const matched = filterStyles.some(x => 
        String(b.style_no).toLowerCase().includes(x.toLowerCase()) || 
        String(b.booking_reference).toLowerCase().includes(x.toLowerCase())
      );
      if (!matched) return false;
    }

    return true;
  });

  // Unique list of styles and POs in active directory
  const directoryApprovedStylesCount = budgets.map(b => b.style_no).filter((v, i, self) => self.indexOf(v) === i).length;
  const uniqueBookedStylesCount = bookings.filter(b => b.status === 'Approved').map(b => b.style_no).filter((v, i, self) => self.indexOf(v) === i).length;
  const pendingBookingStylesCount = Math.max(0, directoryApprovedStylesCount - uniqueBookedStylesCount);

  // Formatting helper for currency values
  const formatMoney = (val: number) => {
    return '$' + val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  // Words translation helper
  const translateToWords = (amount: number) => {
    if (amount === 0) return 'Zero USD';
    const num = Math.floor(amount);
    const wordsList = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
    const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
    
    const convertLessThanOneThousand = (n: number): string => {
      if (n < 20) return wordsList[n];
      const digit = n % 10;
      if (n < 100) return tens[Math.floor(n / 10)] + (digit ? " " + wordsList[digit] : "");
      return wordsList[Math.floor(n / 100)] + " Hundred" + (n % 100 ? " and " + convertLessThanOneThousand(n % 100) : "");
    };

    if (num < 1000) return convertLessThanOneThousand(num) + " USD";
    if (num < 1000000) {
      const thousands = Math.floor(num / 1000);
      const rem = num % 1000;
      return convertLessThanOneThousand(thousands) + " Thousand " + (rem ? convertLessThanOneThousand(rem) : "") + " USD";
    }
    return amount.toFixed(2) + " USD";
  };

  return (
    <div>
      {/* 1. Mock Access Switcher Bar */}
      <div className="dashboard-card" style={{ padding: '12px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'rgba(99, 102, 241, 0.1)', border: '1px solid rgba(99, 102, 241, 0.2)', marginBottom: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Shield size={16} className="text-secondary" style={{ color: 'var(--primary)' }} />
          <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Simulated Access Scope Control:</span>
        </div>
        <div className="d-flex gap-10">
          <button className={`btn btn-sm ${simulatedRole === 'super_admin' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setSimulatedRole('super_admin')}>
            Super Admin (All Lists)
          </button>
          <button className={`btn btn-sm ${simulatedRole === 'admin_user' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setSimulatedRole('admin_user')}>
            Admin User (Company: Demo Factory)
          </button>
          <button className={`btn btn-sm ${simulatedRole === 'unit_user' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setSimulatedRole('unit_user')}>
            Specific Unit User (Unit: Demo Unit)
          </button>
        </div>
      </div>

      {/* Main Tab Controls */}
      <div className="tab-container" style={{ marginBottom: '20px' }}>
        <div className={`tab ${activeSubTab === 'directory' ? 'active' : ''}`} onClick={() => setActiveSubTab('directory')}>
          Fabric Bookings Directory
        </div>
        <div className={`tab ${activeSubTab === 'approval' ? 'active' : ''}`} onClick={() => setActiveSubTab('approval')}>
          Fabric Booking Approval Portal
        </div>
      </div>

      {/* TAB 1: DIRECTORY TAB */}
      {activeSubTab === 'directory' && (
        <>
          {/* Summary dashboard boxes */}
          <div className="metrics-grid mb-20" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px', marginBottom: '20px' }}>
            <div className="metric-card" style={{ background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
              <div className="metric-details">
                <h3 style={{ color: '#166534' }}>Approved Budgeted Styles</h3>
                <div className="metric-value" style={{ color: '#14532d' }}>{directoryApprovedStylesCount}</div>
              </div>
            </div>
            <div className="metric-card" style={{ background: '#eff6ff', border: '1px solid #bfdbfe' }}>
              <div className="metric-details">
                <h3 style={{ color: '#1e40af' }}>Bookings Placed</h3>
                <div className="metric-value" style={{ color: '#1e3a8a' }}>{uniqueBookedStylesCount}</div>
              </div>
            </div>
            <div className="metric-card" style={{ background: '#fffbeb', border: '1px solid #fef3c7' }}>
              <div className="metric-details">
                <h3 style={{ color: '#92400e' }}>Bookings Pending</h3>
                <div className="metric-value" style={{ color: '#78350f' }}>{pendingBookingStylesCount}</div>
              </div>
            </div>
          </div>

          {/* Search Filters Card */}
          <div className="dashboard-card mb-20" style={{ padding: '20px', marginBottom: '20px' }}>
            <h4 style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px', fontWeight: 'bold' }}>
              <Search size={16} /> Advanced Fabric Booking Search
            </h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '15px', alignItems: 'end' }}>
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>From Date</label>
                <input type="date" className="form-control" value={filterStartDate} onChange={e => setFilterStartDate(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>To Date</label>
                <input type="date" className="form-control" value={filterEndDate} onChange={e => setFilterEndDate(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>Buyer (Add multiple)</label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <input type="text" className="form-control" placeholder="Buyer" value={buyerInput} onChange={e => setBuyerInput(e.target.value)} />
                  <button type="button" className="btn btn-secondary btn-sm" onClick={handleAddSearchBuyer}>Add</button>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>Style / PO (Add multiple)</label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <input type="text" className="form-control" placeholder="Style or PO" value={styleInput} onChange={e => setStyleInput(e.target.value)} />
                  <button type="button" className="btn btn-secondary btn-sm" onClick={handleAddSearchStyle}>Add</button>
                </div>
              </div>
            </div>

            {/* Render selected Search Badges */}
            <div style={{ display: 'flex', gap: '20px', marginTop: '12px', flexWrap: 'wrap' }}>
              {filterBuyers.length > 0 && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>Buyers:</span>
                  {filterBuyers.map(b => (
                    <span key={b} className="badge badge-pending" style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                      {b} <XCircle size={12} style={{ cursor: 'pointer' }} onClick={() => setFilterBuyers(filterBuyers.filter(x => x !== b))} />
                    </span>
                  ))}
                </div>
              )}
              {filterStyles.length > 0 && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>Styles / Ref:</span>
                  {filterStyles.map(s => (
                    <span key={s} className="badge badge-pending" style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                      {s} <XCircle size={12} style={{ cursor: 'pointer' }} onClick={() => setFilterStyles(filterStyles.filter(x => x !== s))} />
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Bookings Directory List Grid */}
          <div className="dashboard-card">
            <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Layers /> Fabric Booking Directory
              </h3>
              <button className="btn btn-primary" onClick={handleOpenCreateModal}>
                <Plus size={16} /> Create Fabric Booking
              </button>
            </div>

            <div className="table-wrapper">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Booking Ref</th>
                    <th>Created Date</th>
                    <th>Basis</th>
                    <th>Buyer</th>
                    <th>Style</th>
                    <th>Supplier</th>
                    <th>Currency</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredBookings.map((b, idx) => (
                    <tr key={idx}>
                      <td><strong>{b.booking_reference}</strong></td>
                      <td>{b.booking_date}</td>
                      <td>
                        <span className={`badge badge-${b.basis === 'Main' ? 'approved' : 'pending'}`}>{b.basis} Booking</span>
                      </td>
                      <td>{b.buyer || 'N/A'}</td>
                      <td>{b.style_no || 'N/A'}</td>
                      <td>{b.supplier_name}</td>
                      <td>{b.currency || 'USD'}</td>
                      <td>
                        <span className={`badge badge-${b.status?.toLowerCase() || 'pending'}`}>{b.status}</span>
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: '6px' }}>
                          <button className="btn btn-secondary btn-sm" title="View Print Format" onClick={() => setViewingBooking(b)}>
                            <Printer size={14} /> View
                          </button>
                          <button className="btn btn-secondary btn-sm" title="Edit Booking Specs" onClick={() => handleOpenEditModal(b)}>
                            <Edit2 size={14} /> Edit
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {filteredBookings.length === 0 && (
                    <tr>
                      <td colSpan={9} style={{ textAlign: 'center', color: '#94a3b8' }}>No fabric bookings matched search parameters.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* TAB 2: APPROVAL TAB */}
      {activeSubTab === 'approval' && (
        <div className="dashboard-card">
          <div className="card-header">
            <h3 className="card-title">Fabric Booking Approval Requests</h3>
          </div>

          {/* Search filters for approvals */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '15px', marginBottom: '20px', padding: '15px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #cbd5e1' }}>
            <div className="form-group">
              <label className="form-label" style={{ fontSize: '0.8rem' }}>From Date</label>
              <input type="date" className="form-control" value={appStartDate} onChange={e => setAppStartDate(e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label" style={{ fontSize: '0.8rem' }}>To Date</label>
              <input type="date" className="form-control" value={appEndDate} onChange={e => setAppEndDate(e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label" style={{ fontSize: '0.8rem' }}>Buyer (Add multiple)</label>
              <div style={{ display: 'flex', gap: '8px' }}>
                <input type="text" className="form-control" placeholder="Buyer" value={appBuyerInput} onChange={e => setAppBuyerInput(e.target.value)} />
                <button type="button" className="btn btn-secondary btn-sm" onClick={handleAddAppBuyer}>Add</button>
              </div>
            </div>
            <div className="form-group">
              <label className="form-label" style={{ fontSize: '0.8rem' }}>Style / PO (Add multiple)</label>
              <div style={{ display: 'flex', gap: '8px' }}>
                <input type="text" className="form-control" placeholder="Style or PO" value={appStyleInput} onChange={e => setAppStyleInput(e.target.value)} />
                <button type="button" className="btn btn-secondary btn-sm" onClick={handleAddAppStyle}>Add</button>
              </div>
            </div>
            <div className="form-group">
              <label className="form-label" style={{ fontSize: '0.8rem' }}>Approval Type</label>
              <select className="form-control" value={appApprovalType} onChange={e => setAppApprovalType(e.target.value)}>
                <option value="All">All Requests</option>
                <option value="Approved">Approved</option>
                <option value="Unapproved">Unapproved</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '20px', marginBottom: '15px', flexWrap: 'wrap' }}>
            {appBuyers.length > 0 && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ fontSize: '0.8rem', color: '#64748b' }}>Buyers:</span>
                {appBuyers.map(b => (
                  <span key={b} className="badge badge-pending" style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                    {b} <XCircle size={12} style={{ cursor: 'pointer' }} onClick={() => setAppBuyers(appBuyers.filter(x => x !== b))} />
                  </span>
                ))}
              </div>
            )}
            {appStyles.length > 0 && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ fontSize: '0.8rem', color: '#64748b' }}>Styles / Ref:</span>
                {appStyles.map(s => (
                  <span key={s} className="badge badge-pending" style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                    {s} <XCircle size={12} style={{ cursor: 'pointer' }} onClick={() => setAppStyles(appStyles.filter(x => x !== s))} />
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="table-wrapper">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Booking Ref</th>
                  <th>Created Date</th>
                  <th>Basis</th>
                  <th>Buyer</th>
                  <th>Style</th>
                  <th>Supplier</th>
                  <th>Status</th>
                  <th>Approval Action</th>
                </tr>
              </thead>
              <tbody>
                {bookings.filter(b => {
                  if (appStartDate && b.booking_date < appStartDate) return false;
                  if (appEndDate && b.booking_date > appEndDate) return false;
                  if (appBuyers.length > 0 && !appBuyers.some(x => String(b.buyer).toLowerCase().includes(x.toLowerCase()))) return false;
                  if (appStyles.length > 0 && !appStyles.some(x => String(b.style_no).toLowerCase().includes(x.toLowerCase()) || String(b.booking_reference).toLowerCase().includes(x.toLowerCase()))) return false;
                  if (appApprovalType === 'Approved' && b.status !== 'Approved') return false;
                  if (appApprovalType === 'Unapproved' && b.status === 'Approved') return false;
                  return true;
                }).map((b, idx) => (
                  <tr key={idx}>
                    <td><strong>{b.booking_reference}</strong></td>
                    <td>{b.booking_date}</td>
                    <td>{b.basis}</td>
                    <td>{b.buyer || 'N/A'}</td>
                    <td>{b.style_no || 'N/A'}</td>
                    <td>{b.supplier_name}</td>
                    <td>
                      <span className={`badge badge-${b.status?.toLowerCase() || 'pending'}`}>{b.status}</span>
                    </td>
                    <td>
                      {b.status === 'Pending' ? (
                        <div style={{ display: 'flex', gap: '6px' }}>
                          <button className="btn btn-success btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '4px' }} onClick={() => handleApprovalAction(b.id, true)}>
                            <CheckCircle size={14} /> Approve
                          </button>
                          <button className="btn btn-danger btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '4px' }} onClick={() => handleApprovalAction(b.id, false)}>
                            <XCircle size={14} /> Reject
                          </button>
                        </div>
                      ) : (
                        <span style={{ fontSize: '0.8rem', color: '#94a3b8', fontStyle: 'italic' }}>Decision Submitted</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. VIEW PRINT/INVOICE MODAL (PDF Sheet replica) */}
      {viewingBooking && (() => {
        // Find budget metadata for booking
        const totalWoAmt = (viewingBooking.items || []).reduce((sum: number, it: any) => sum + (it.amount || 0), 0);
        const garmentsQtySum = (viewingBooking.items || []).reduce((sum: number, it: any) => sum + (it.garments_qty || 0), 0);
        const excessCutVal = garmentsQtySum + 20; // extra cut simulator
        
        return (
          <div className="modal-overlay" style={{ zIndex: 1100 }}>
            <div className="modal-content" style={{ maxWidth: '1000px', width: '95%' }}>
              <div className="modal-header" style={{ borderBottom: '2px solid #0f172a' }}>
                <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Printer /> Booking Sheet View Format
                </h3>
                <div style={{ display: 'flex', gap: '10px' }}>
                  <button onClick={() => window.print()} className="btn btn-secondary btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Print Sheet / Save PDF
                  </button>
                  <XCircle className="modal-close" onClick={() => setViewingBooking(null)} />
                </div>
              </div>

              <div id="booking-sheet-print" style={{ padding: '20px', background: '#fff', color: '#0f172a', fontFamily: 'Calibri, Arial, sans-serif', fontSize: '0.75rem' }}>
                {/* Printable Header */}
                <div style={{ textAlign: 'center', marginBottom: '20px', borderBottom: '1px solid #cbd5e1', paddingBottom: '10px' }}>
                  <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: '2px 0' }}>{userCompany}</h2>
                  <h3 style={{ fontSize: '1.1rem', margin: '2px 0', color: '#475569' }}>{userUnit}</h3>
                  <p style={{ margin: '2px 0', color: '#64748b' }}>Ashulia, Dhaka</p>
                  <div style={{ border: '1px solid #0f172a', padding: '6px', fontWeight: 'bold', display: 'inline-block', marginTop: '10px', textTransform: 'uppercase', letterSpacing: '1px' }}>
                    Fabric Booking Sheet
                  </div>
                </div>

                {/* Primary Info Sheet */}
                <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #cbd5e1', marginBottom: '20px' }}>
                  <tbody>
                    <tr style={{ borderBottom: '1px solid #cbd5e1' }}>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1', width: '15%' }}>Buyer:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1', width: '18%' }}>{viewingBooking.buyer || 'N/A'}</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1', width: '15%' }}>Booking No:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1', width: '18%' }}>{viewingBooking.booking_reference}</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1', width: '15%' }}>Booking Date:</td>
                      <td style={{ padding: '4px 8px', width: '19%' }}>{viewingBooking.booking_date}</td>
                    </tr>
                    <tr style={{ borderBottom: '1px solid #cbd5e1' }}>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Supplier Name:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1' }}>{viewingBooking.supplier_name}</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Season:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1' }}>Summer 2026</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Delivery Date:</td>
                      <td style={{ padding: '4px 8px' }}>{viewingBooking.delivery_date || 'N/A'}</td>
                    </tr>
                    <tr style={{ borderBottom: '1px solid #cbd5e1' }}>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Address:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1' }}>Dhaka, Bangladesh</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Order Status:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1' }}>Confirm</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Approval Status:</td>
                      <td style={{ padding: '4px 8px' }}>{viewingBooking.status}</td>
                    </tr>
                    <tr style={{ borderBottom: '1px solid #cbd5e1' }}>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Attention:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1' }}>{viewingBooking.attention || 'N/A'}</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Dept:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1' }}>Mens Department</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Dealing Merchant:</td>
                      <td style={{ padding: '4px 8px' }}>Supervisor Merchant</td>
                    </tr>
                    <tr style={{ borderBottom: '1px solid #cbd5e1' }}>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Currency:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1' }}>{viewingBooking.currency || 'USD'}</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Garments Qty:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1' }}>{garmentsQtySum} Pcs</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Extra Cut Quantity:</td>
                      <td style={{ padding: '4px 8px' }}>{excessCutVal} Pcs</td>
                    </tr>
                    <tr>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Remarks:</td>
                      <td style={{ padding: '4px 8px', borderRight: '1px solid #cbd5e1' }} colSpan={3}>{viewingBooking.remarks || 'N/A'}</td>
                      <td style={{ padding: '4px 8px', background: '#f8fafc', fontWeight: 'bold', borderRight: '1px solid #cbd5e1' }}>Budget Reference:</td>
                      <td style={{ padding: '4px 8px' }}>{viewingBooking.budget_reference || 'N/A'}</td>
                    </tr>
                  </tbody>
                </table>

                {/* Fabric Details Grid */}
                <h4 style={{ fontWeight: 'bold', fontSize: '0.85rem', margin: '15px 0 6px 0', borderBottom: '2px solid #0f172a', paddingBottom: '4px' }}>Fabric Booking Specifications</h4>
                <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #cbd5e1', marginBottom: '20px' }}>
                  <thead>
                    <tr style={{ background: '#f1f5f9', borderBottom: '2px solid #cbd5e1', textAlign: 'left' }}>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '5%' }}>SL</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>Style</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>Gmts Item</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>Body Parts</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>Fabric Composition</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '6%', textAlign: 'right' }}>GSM</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '6%', textAlign: 'right' }}>Dia</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>Gmts Color</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>Fab Color</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '5%', textAlign: 'right' }}>LD</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '8%', textAlign: 'right' }}>Act. Fab. Qty</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '6%', textAlign: 'right' }}>P. Loss %</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '6%', textAlign: 'right' }}>Grey Cons</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '5%' }}>UOM</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '8%', textAlign: 'right' }}>T. Fab. Qty</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '6%', textAlign: 'right' }}>Avg Rate</th>
                      <th style={{ padding: '4px 6px', textAlign: 'right' }}>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(viewingBooking.items || []).map((it: any, i: number) => (
                      <tr key={i} style={{ borderBottom: '1px solid #cbd5e1' }}>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{i + 1}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.style_no || viewingBooking.style_no}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.garments_item}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.body_parts}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.fabric_composition}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>{it.gsm || 180}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>{it.fabric_dia || 'N/A'}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.color}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.fabric_color}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>{it.lab_dip || 'N/A'}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>{it.garments_qty}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>{it.excess_pct}%</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>{(it.total_qty / (it.garments_qty || 1)).toFixed(4)}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.uom || 'Kg'}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right', fontWeight: 'bold' }}>{it.work_order_quantity?.toFixed(2)}</td>
                        <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>${parseFloat(it.rate).toFixed(4)}</td>
                        <td style={{ padding: '4px 6px', textAlign: 'right', fontWeight: 'bold' }}>${parseFloat(it.amount || (it.work_order_quantity * it.rate)).toFixed(2)}</td>
                      </tr>
                    ))}
                    <tr style={{ background: '#f8fafc', fontWeight: 'bold' }}>
                      <td colSpan={10} style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>Total</td>
                      <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>{garmentsQtySum}</td>
                      <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}></td>
                      <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}></td>
                      <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}></td>
                      <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>{(viewingBooking.items || []).reduce((sum: number, it: any) => sum + (it.work_order_quantity || 0), 0).toFixed(2)}</td>
                      <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}></td>
                      <td style={{ padding: '4px 6px', textAlign: 'right' }}>{formatMoney(totalWoAmt)}</td>
                    </tr>
                  </tbody>
                </table>

                {/* Yarn Cost Grid */}
                <h4 style={{ fontWeight: 'bold', fontSize: '0.85rem', margin: '15px 0 6px 0', borderBottom: '2px solid #0f172a', paddingBottom: '4px' }}>Yarn Specifications</h4>
                <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #cbd5e1', marginBottom: '20px' }}>
                  <thead>
                    <tr style={{ background: '#f1f5f9', borderBottom: '2px solid #cbd5e1', textAlign: 'left' }}>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '20%' }}>Unique Id</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '10%' }}>Style</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>Fabric Description</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>Yarn Description</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '6%' }}>UOM</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '8%', textAlign: 'right' }}>Yarn Cons</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '8%', textAlign: 'right' }}>Rate</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '8%', textAlign: 'right' }}>Amount</th>
                      <th style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', width: '10%', textAlign: 'right' }}>Total Yarn Cons</th>
                      <th style={{ padding: '4px 6px', textAlign: 'right' }}>Total Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(viewingBooking.items || []).filter((it: any) => it.yarn_type && it.yarn_type !== 'N/A').map((it: any, i: number) => {
                      const totalCons = it.work_order_quantity;
                      const totalAmt = totalCons * it.rate;
                      return (
                        <tr key={i} style={{ borderBottom: '1px solid #cbd5e1' }}>
                          <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{viewingBooking.booking_reference}-{i + 1}</td>
                          <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.style_no}</td>
                          <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.fabric_type} {it.fabric_composition}</td>
                          <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.yarn_type}</td>
                          <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1' }}>{it.uom}</td>
                          <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>{(totalCons / it.garments_qty).toFixed(4)}</td>
                          <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>${parseFloat(it.rate).toFixed(4)}</td>
                          <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right' }}>${(totalCons / it.garments_qty * it.rate).toFixed(4)}</td>
                          <td style={{ padding: '4px 6px', borderRight: '1px solid #cbd5e1', textAlign: 'right', fontWeight: 'bold' }}>{totalCons.toFixed(2)}</td>
                          <td style={{ padding: '4px 6px', textAlign: 'right', fontWeight: 'bold' }}>${totalAmt.toFixed(2)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Total in words */}
                <div style={{ borderTop: '2px solid #cbd5e1', paddingTop: '10px', marginBottom: '20px' }}>
                  <p style={{ margin: '3px 0', fontSize: '0.85rem' }}>
                    <strong>Total Fabric Amount:</strong> <span style={{ color: '#1d4ed8' }}>{formatMoney(totalWoAmt)} USD</span>
                  </p>
                  <p style={{ margin: '3px 0', fontSize: '0.8rem', textTransform: 'capitalize', fontStyle: 'italic', color: '#475569' }}>
                    <strong>In Words:</strong> {translateToWords(totalWoAmt)} Only.
                  </p>
                </div>

                {/* Terms and Conditions */}
                <div style={{ marginTop: '20px', background: '#f8fafc', padding: '12px', border: '1px solid #cbd5e1', borderRadius: '4px' }}>
                  <h5 style={{ fontWeight: 'bold', fontSize: '0.8rem', borderBottom: '1px solid #cbd5e1', paddingBottom: '4px', marginBottom: '6px' }}>Terms & Conditions:</h5>
                  <ul style={{ margin: 0, paddingLeft: '15px', listStyleType: 'square' }}>
                    {viewingBooking.terms_conditions?.split('\n* ').map((term: string, idx: number) => (
                      <li key={idx} style={{ marginBottom: '4px' }}>{term}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-20 text-right" style={{ marginTop: '20px' }}>
                <button className="btn btn-secondary" onClick={() => setViewingBooking(null)}>Close Print Window</button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 4. MAIN FABRIC BOOKING ENTRY MODAL (Phase 1 & 2) */}
      {showModal && (
        <div className="modal-overlay" style={{ zIndex: 1050 }}>
          <div className="modal-content" style={{ maxWidth: '950px', width: '95%' }}>
            <div className="modal-header">
              <h3>{editingBooking ? `Edit Fabric Booking: ${editingBooking.booking_reference}` : 'Create New Fabric Booking'}</h3>
              <XCircle className="modal-close" onClick={() => setShowModal(false)} />
            </div>

            {errorMsg && (
              <div className="alert-message alert-danger" style={{ marginBottom: '15px' }}>
                <AlertCircle size={16} /> {errorMsg}
              </div>
            )}

            <form onSubmit={handleSaveBooking}>
              <div className="grid-3" style={{ background: '#f8fafc', padding: '15px', borderRadius: '6px', border: '1px solid #cbd5e1', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Basis *</label>
                  <select className="form-control" value={basis} onChange={e => setBasis(e.target.value as any)}>
                    <option value="Main">Main Booking</option>
                    <option value="Short">Short Booking</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Style Reference *</label>
                  <select className="form-control" value={selectedStyle} onChange={e => handleStyleChange(e.target.value)} required>
                    <option value="">Select Style</option>
                    {Array.from(new Set(budgets.map(b => b.style_no))).map(st => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Budget Reference ID *</label>
                  <select className="form-control" value={selectedBudgetIds[0] || ''} onChange={e => handleBudgetChange(e.target.value)} required>
                    <option value="">Select Budget ID</option>
                    {budgets.filter(b => !selectedStyle || String(b.style_no).toLowerCase() === selectedStyle.toLowerCase()).map(b => (
                      <option key={b.id} value={b.id}>{b.budget_reference} (Style: {b.style_no})</option>
                    ))}
                  </select>
                </div>

                {basis === 'Short' && (
                  <div className="form-group" style={{ gridColumn: 'span 3' }}>
                    <label className="form-label">Link Approved Main Bookings * (Select reference main booking ID)</label>
                    <select className="form-control" value={selectedMainBookingIds[0] || ''} onChange={e => setSelectedMainBookingIds([e.target.value])} required>
                      <option value="">Select Main Booking ID</option>
                      {bookings.filter(b => b.basis === 'Main' && b.status === 'Approved').map(b => (
                        <option key={b.id} value={b.id}>{b.booking_reference}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* Form Metadata Fields */}
              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Booking Date *</label>
                  <input type="date" className="form-control" value={bookingDate} onChange={e => setBookingDate(e.target.value)} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Supplier Name *</label>
                  <input type="text" className="form-control" placeholder="Apex, Aman..." value={supplierName} onChange={e => setSupplierName(e.target.value)} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Delivery Date *</label>
                  <input type="date" className="form-control" value={deliveryDate} onChange={e => setDeliveryDate(e.target.value)} required />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Inhouse Date</label>
                  <input type="date" className="form-control" value={inhouseDate} onChange={e => setInhouseDate(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Pay Mode *</label>
                  <select className="form-control" value={payMode} onChange={e => setPayMode(e.target.value)} required>
                    <option value="Credit">Credit</option>
                    <option value="Import">Import</option>
                    <option value="In House">In House</option>
                    <option value="Within Group">Within Group</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Source *</label>
                  <select className="form-control" value={source} onChange={e => setSource(e.target.value)} required>
                    <option value="Abroad/Import">Abroad/Import</option>
                    <option value="Epz">Epz</option>
                    <option value="Non-Epz/Local">Non-Epz/Local</option>
                    <option value="In House/Inventory">In House/Inventory</option>
                  </select>
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Currency</label>
                  <select className="form-control" value={currency} onChange={e => setCurrency(e.target.value)}>
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="BDT">BDT (৳)</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Attention</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    placeholder="e.g. Sales Manager" 
                    value={attention} 
                    onChange={e => setAttention(e.target.value)} 
                    list="attention-suggestions"
                  />
                  <datalist id="attention-suggestions">
                    {attentionSuggestion && <option value={attentionSuggestion} />}
                  </datalist>
                </div>
                <div className="form-group">
                  <label className="form-label">Remarks</label>
                  <input type="text" className="form-control" placeholder="Booking notes..." value={remarks} onChange={e => setRemarks(e.target.value)} />
                </div>
              </div>

              {/* Sub-form popups triggers */}
              <div style={{ display: 'flex', gap: '15px', margin: '15px 0' }}>
                <button type="button" className="btn btn-secondary btn-sm" onClick={() => setShowCcPopup(true)}>
                  Collar & Cuff info (Browse Option) [{ccList.length} rows configured]
                </button>
                <button type="button" className="btn btn-secondary btn-sm" onClick={() => setShowTermsPopup(true)}>
                  Terms & Conditions (Browse Option) [{selectedTerms.length} active]
                </button>
                <button type="button" className="btn btn-success btn-sm" style={{ background: '#10b981', borderColor: '#10b981', marginLeft: 'auto' }} onClick={handleGetData}>
                  Get Data (Fetch Cost Spec)
                </button>
              </div>

              {/* Phase 2: Booking Details Table */}
              {bookingItems.length > 0 && (
                <div>
                  <h4 style={{ fontWeight: 'bold', borderBottom: '1px solid #cbd5e1', paddingBottom: '6px', margin: '20px 0 10px 0' }}>Fabric Booking Specifications (2nd Phase)</h4>
                  <div className="table-wrapper" style={{ maxHeight: '250px', overflowY: 'auto' }}>
                    <table className="data-table" style={{ fontSize: '0.75rem' }}>
                      <thead>
                        <tr>
                          <th>Buyer</th>
                          <th>Style</th>
                          <th>PO</th>
                          <th>Item</th>
                          <th>Body Part</th>
                          <th>Color</th>
                          <th>Yarn Type</th>
                          <th>GSM</th>
                          <th>Dia</th>
                          <th>Lab Dip</th>
                          <th>Budget Qty</th>
                          <th>WO Qty</th>
                          <th>Rate</th>
                          <th>Amount</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {bookingItems.map((it, idx) => (
                          <tr key={idx}>
                            <td>{it.buyer}</td>
                            <td>{it.style_no}</td>
                            <td>{it.po_no}</td>
                            <td>{it.garments_item}</td>
                            <td>{it.body_parts}</td>
                            <td>{it.color}</td>
                            <td>{it.yarn_type}</td>
                            <td>{it.gsm}</td>
                            <td>{it.fabric_dia}</td>
                            <td>
                              <input 
                                type="text" 
                                className="form-control" 
                                style={{ width: '80px', height: '24px', fontSize: '0.7rem' }} 
                                value={it.lab_dip} 
                                onChange={e => {
                                  const c = [...bookingItems];
                                  c[idx].lab_dip = e.target.value;
                                  setBookingItems(c);
                                }}
                              />
                            </td>
                            <td>{it.budget_quantity?.toFixed(2)}</td>
                            <td>
                              <input 
                                type="number" 
                                className="form-control" 
                                style={{ width: '70px', height: '24px', fontSize: '0.7rem', textAlign: 'right' }} 
                                value={it.work_order_quantity} 
                                onChange={e => {
                                  const val = parseFloat(e.target.value) || 0;
                                  const c = [...bookingItems];
                                  c[idx].work_order_quantity = val;
                                  c[idx].amount = val * c[idx].rate;
                                  setBookingItems(c);
                                }}
                              />
                            </td>
                            <td>
                              <input 
                                type="number" 
                                className="form-control" 
                                style={{ width: '60px', height: '24px', fontSize: '0.7rem', textAlign: 'right' }} 
                                value={it.rate} 
                                onChange={e => {
                                  const val = parseFloat(e.target.value) || 0;
                                  const c = [...bookingItems];
                                  c[idx].rate = val;
                                  c[idx].amount = c[idx].work_order_quantity * val;
                                  setBookingItems(c);
                                }}
                              />
                            </td>
                            <td style={{ fontWeight: 'bold' }}>${it.amount?.toFixed(2)}</td>
                            <td>
                              <button type="button" className="btn btn-danger btn-sm" style={{ padding: '2px 6px' }} onClick={() => setBookingItems(bookingItems.filter((_, i) => i !== idx))}>
                                <Trash2 size={12} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  
                  {/* Button to add custom rows */}
                  <div style={{ marginTop: '10px' }}>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => {
                      setBookingItems([...bookingItems, {
                        po_no: 'PO-custom',
                        buyer: selectedStyle ? budgets.find(x => x.style_no === selectedStyle)?.buyer || 'Zara' : 'Zara',
                        style_no: selectedStyle || 'Custom',
                        garments_item: 'Polo Shirt',
                        body_parts: 'Body Fabric',
                        color: 'Red',
                        fabric_color: 'Red',
                        yarn_type: 'N/A',
                        embellishment_type: 'N/A',
                        embellishment_name: 'N/A',
                        fabric_type: 'Jersey',
                        fabric_composition: '100% Cotton',
                        gsm: 180,
                        fabric_dia: 'Open Width',
                        lab_dip: '',
                        garments_quantity: 12000,
                        total_fabric_quantity: 1000,
                        uom: 'Kg',
                        budget_quantity: 1000,
                        work_order_quantity: 1000,
                        rate: 5.50,
                        amount: 5500,
                        size: 'M',
                        item_size: 'M',
                        excess_pct: 0,
                        total_qty: 1000
                      }]);
                    }}>
                      + Add Custom Spec Row
                    </button>
                  </div>
                </div>
              )}

              <div className="mt-20 text-right" style={{ marginTop: '20px', borderTop: '1px solid #cbd5e1', paddingTop: '15px' }}>
                <button type="button" className="btn btn-secondary mr-10" style={{ marginRight: '10px' }} onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">
                  <Save size={16} /> {editingBooking ? 'Update Booking' : 'Place Fabric Booking'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SUB-MODAL 1: COLLAR & CUFF BROWSE POPUP */}
      {showCcPopup && (
        <div className="modal-overlay" style={{ zIndex: 1200 }}>
          <div className="modal-content" style={{ maxWidth: '800px', width: '90%' }}>
            <div className="modal-header">
              <h3>Collar & Cuff Specifications Popup Manager</h3>
              <XCircle className="modal-close" onClick={() => setShowCcPopup(false)} />
            </div>

            {/* Checkbox copy directives */}
            <div style={{ display: 'flex', gap: '20px', background: '#f8fafc', padding: '12px', border: '1px solid #cbd5e1', borderRadius: '4px', marginBottom: '15px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', fontWeight: 'bold', cursor: 'pointer' }}>
                <input type="checkbox" checked={ccCopyAll} onChange={e => setCcCopyAll(e.target.checked)} /> Copy All
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', fontWeight: 'bold', cursor: 'pointer' }}>
                <input type="checkbox" checked={ccColorWise} onChange={e => setCcColorWise(e.target.checked)} /> Color Wise
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', fontWeight: 'bold', cursor: 'pointer' }}>
                <input type="checkbox" checked={ccSizeWise} onChange={e => setCcSizeWise(e.target.checked)} /> Size Wise
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', fontWeight: 'bold', cursor: 'pointer' }}>
                <input type="checkbox" checked={ccPoWise} onChange={e => setCcPoWise(e.target.checked)} /> PO Wise
              </label>
            </div>

            <div className="grid-3">
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>PO Number</label>
                <input type="text" className="form-control" value={ccPo} onChange={e => setCcPo(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>Garments Color</label>
                <input type="text" className="form-control" value={ccColor} onChange={e => setCcColor(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>Garments Size</label>
                <input type="text" className="form-control" value={ccGmtSize} onChange={e => setCcGmtSize(e.target.value)} />
              </div>
            </div>
            <div className="grid-3" style={{ marginBottom: '15px' }}>
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>Item Size</label>
                <input type="text" className="form-control" value={ccItemSize} onChange={e => setCcItemSize(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>Garments Qty (Pcs)</label>
                <input type="number" className="form-control" value={ccGmtQty} onChange={e => setCcGmtQty(parseInt(e.target.value) || 0)} />
              </div>
              <div className="form-group">
                <label className="form-label" style={{ fontSize: '0.8rem' }}>Excess %</label>
                <input type="number" className="form-control" value={ccExcess} onChange={e => setCcExcess(parseInt(e.target.value) || 0)} />
              </div>
            </div>

            <button type="button" className="btn btn-secondary btn-sm" style={{ marginBottom: '15px' }} onClick={handleAddCcLine}>
              + Add Collar/Cuff Line
            </button>

            <div className="table-wrapper" style={{ maxHeight: '180px' }}>
              <table className="data-table" style={{ fontSize: '0.75rem' }}>
                <thead>
                  <tr>
                    <th>PO Number</th>
                    <th>Garments Color</th>
                    <th>Garments Size</th>
                    <th>Item Size</th>
                    <th>Garments Qty</th>
                    <th>Excess %</th>
                    <th>Total Qty</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {ccList.map((cc, i) => (
                    <tr key={i}>
                      <td>{cc.po_no}</td>
                      <td>{cc.color}</td>
                      <td>{cc.gmt_size}</td>
                      <td>{cc.item_size}</td>
                      <td>{cc.gmt_qty} pcs</td>
                      <td>{cc.excess}%</td>
                      <td><strong>{cc.total_qty} pcs</strong></td>
                      <td>
                        <button type="button" className="btn btn-danger btn-sm" style={{ padding: '2px 6px' }} onClick={() => setCcList(ccList.filter((_, idx) => idx !== i))}>
                          <Trash2 size={12} />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {ccList.length === 0 && (
                    <tr>
                      <td colSpan={8} style={{ textAlign: 'center', color: '#94a3b8' }}>No collar & cuff specs configured yet.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="mt-20 text-right" style={{ marginTop: '15px' }}>
              <button type="button" className="btn btn-secondary mr-10" style={{ marginRight: '10px' }} onClick={() => setShowCcPopup(false)}>Cancel</button>
              <button type="button" className="btn btn-primary" onClick={handleApplyCcRules}>Apply & Close</button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-MODAL 2: TERMS & CONDITIONS BROWSE POPUP */}
      {showTermsPopup && (
        <div className="modal-overlay" style={{ zIndex: 1200 }}>
          <div className="modal-content" style={{ maxWidth: '700px', width: '90%' }}>
            <div className="modal-header">
              <h3>Terms & Conditions Browse Template Portal</h3>
              <XCircle className="modal-close" onClick={() => setShowTermsPopup(false)} />
            </div>

            {/* Template Selection list */}
            <div className="table-wrapper" style={{ maxHeight: '250px', marginBottom: '15px' }}>
              <table className="data-table" style={{ fontSize: '0.75rem' }}>
                <thead>
                  <tr>
                    <th style={{ width: '8%', textAlign: 'center' }}>✓</th>
                    <th style={{ width: '8%' }}>SI</th>
                    <th>Terms & Condition</th>
                    <th style={{ width: '12%', textAlign: 'center' }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {termsTemplates.map((t, idx) => {
                    const isChecked = selectedTerms.includes(t.text);
                    return (
                      <tr key={t.id}>
                        <td style={{ textAlign: 'center' }}>
                          <input type="checkbox" checked={isChecked} onChange={() => handleToggleTerm(t.text)} style={{ cursor: 'pointer' }} />
                        </td>
                        <td>{String(idx + 1).padStart(2, '0')}</td>
                        <td>{t.text}</td>
                        <td style={{ textAlign: 'center' }}>
                          <button type="button" className="btn btn-danger btn-sm" style={{ padding: '2px 6px' }} onClick={() => {
                            setTermsTemplates(termsTemplates.filter(x => x.id !== t.id));
                            setSelectedTerms(selectedTerms.filter(x => x !== t.text));
                          }}>
                            <Trash2 size={12} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Add new term line */}
            <div style={{ background: '#f8fafc', padding: '12px', border: '1px solid #cbd5e1', borderRadius: '4px', display: 'flex', gap: '10px', alignItems: 'center' }}>
              <input 
                type="text" 
                className="form-control" 
                placeholder="Enter custom terms & conditions direct text..." 
                value={newTermText} 
                onChange={e => setNewTermText(e.target.value)} 
              />
              <button type="button" className="btn btn-success btn-sm" style={{ background: '#10b981', borderColor: '#10b981' }} onClick={handleAddTermTemplate}>
                Add Template Line
              </button>
            </div>

            <div className="mt-20 text-right" style={{ marginTop: '15px' }}>
              <button type="button" className="btn btn-primary" onClick={() => setShowTermsPopup(false)}>
                Submit & Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
