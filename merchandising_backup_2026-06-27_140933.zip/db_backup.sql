--
-- PostgreSQL database dump
--

\restrict S6zVfxPg3bJK0T0StQ7wAf3QGg2vPGQY2OzmvByRwVuYC897IW4AqteQJtp9DBH

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: budget_commission_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_commission_costs (
    id integer NOT NULL,
    budget_id integer,
    particulars text,
    comm_base text,
    rate double precision,
    amount double precision,
    status text
);


ALTER TABLE public.budget_commission_costs OWNER TO postgres;

--
-- Name: budget_commission_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_commission_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_commission_costs_id_seq OWNER TO postgres;

--
-- Name: budget_commission_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_commission_costs_id_seq OWNED BY public.budget_commission_costs.id;


--
-- Name: budget_comml_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_comml_costs (
    id integer NOT NULL,
    budget_id integer,
    commercial_type text,
    rate_pct double precision,
    amount double precision,
    status text
);


ALTER TABLE public.budget_comml_costs OWNER TO postgres;

--
-- Name: budget_comml_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_comml_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_comml_costs_id_seq OWNER TO postgres;

--
-- Name: budget_comml_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_comml_costs_id_seq OWNED BY public.budget_comml_costs.id;


--
-- Name: budget_emb_consumption; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_emb_consumption (
    id integer NOT NULL,
    budget_emb_cost_id integer,
    po_no text,
    color text,
    gmt_sizes text,
    po_qty integer,
    country text,
    cons double precision,
    process_loss_pct integer,
    rate double precision,
    amount double precision,
    total_qty double precision,
    total_amount double precision,
    pcs integer
);


ALTER TABLE public.budget_emb_consumption OWNER TO postgres;

--
-- Name: budget_emb_consumption_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_emb_consumption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_emb_consumption_id_seq OWNER TO postgres;

--
-- Name: budget_emb_consumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_emb_consumption_id_seq OWNED BY public.budget_emb_consumption.id;


--
-- Name: budget_emb_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_emb_costs (
    id integer NOT NULL,
    budget_id integer,
    emb_type text,
    emb_name text,
    gmt_item text,
    description text,
    body_part text,
    cons_unit_gmt double precision,
    rate double precision,
    amount double precision,
    total_qty double precision,
    total_amount double precision,
    supplier text,
    image_url text
);


ALTER TABLE public.budget_emb_costs OWNER TO postgres;

--
-- Name: budget_emb_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_emb_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_emb_costs_id_seq OWNER TO postgres;

--
-- Name: budget_emb_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_emb_costs_id_seq OWNED BY public.budget_emb_costs.id;


--
-- Name: budget_fabric_consumption; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_fabric_consumption (
    id integer NOT NULL,
    budget_fabric_cost_id integer,
    po_no text,
    color text,
    gmt_sizes text,
    po_qty integer,
    dia_width integer,
    dia_fin_type text,
    finish_cons double precision,
    process_loss_pct integer,
    grey_cons double precision,
    rate double precision,
    amount double precision,
    pcs integer,
    total_finish_qty double precision,
    total_qty double precision,
    sample_qty integer,
    total_amount double precision,
    remarks text
);


ALTER TABLE public.budget_fabric_consumption OWNER TO postgres;

--
-- Name: budget_fabric_consumption_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_fabric_consumption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_fabric_consumption_id_seq OWNER TO postgres;

--
-- Name: budget_fabric_consumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_fabric_consumption_id_seq OWNED BY public.budget_fabric_consumption.id;


--
-- Name: budget_fabric_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_fabric_costs (
    id integer NOT NULL,
    budget_id integer,
    gmt_item text,
    body_part text,
    body_part_type text,
    color_range text,
    color_nature text,
    composition text,
    fabric_type text,
    fabric_nature text,
    code text,
    fabric_source text,
    n_supplier text,
    gsm_oz integer,
    dia_type text,
    color_size_sensitive text,
    color text,
    cons_basis text,
    uom text,
    grey_cons double precision,
    rate double precision,
    amount double precision,
    total_qty double precision,
    total_amount double precision
);


ALTER TABLE public.budget_fabric_costs OWNER TO postgres;

--
-- Name: budget_fabric_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_fabric_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_fabric_costs_id_seq OWNER TO postgres;

--
-- Name: budget_fabric_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_fabric_costs_id_seq OWNED BY public.budget_fabric_costs.id;


--
-- Name: budget_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_items (
    id integer NOT NULL,
    budget_id integer,
    item_type text,
    budget_qty double precision,
    budget_rate double precision,
    budget_amount double precision,
    actual_qty double precision DEFAULT 0,
    actual_amount double precision DEFAULT 0
);


ALTER TABLE public.budget_items OWNER TO postgres;

--
-- Name: budget_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_items_id_seq OWNER TO postgres;

--
-- Name: budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_items_id_seq OWNED BY public.budget_items.id;


--
-- Name: budget_other_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_other_costs (
    id integer NOT NULL,
    budget_id integer,
    cost_details text,
    amount double precision
);


ALTER TABLE public.budget_other_costs OWNER TO postgres;

--
-- Name: budget_other_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_other_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_other_costs_id_seq OWNER TO postgres;

--
-- Name: budget_other_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_other_costs_id_seq OWNED BY public.budget_other_costs.id;


--
-- Name: budget_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_templates (
    id integer NOT NULL,
    template_name text,
    item_type text,
    template_data text
);


ALTER TABLE public.budget_templates OWNER TO postgres;

--
-- Name: budget_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_templates_id_seq OWNER TO postgres;

--
-- Name: budget_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_templates_id_seq OWNED BY public.budget_templates.id;


--
-- Name: budget_trims_consumption; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_trims_consumption (
    id integer NOT NULL,
    budget_trims_cost_id integer,
    po_no text,
    color text,
    gmt_sizes text,
    po_qty integer,
    country text,
    finish_cons double precision,
    process_loss_pct integer,
    grey_cons double precision,
    rate double precision,
    amount double precision,
    pcs integer,
    total_finish_qty double precision,
    total_qty double precision,
    total_amount double precision
);


ALTER TABLE public.budget_trims_consumption OWNER TO postgres;

--
-- Name: budget_trims_consumption_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_trims_consumption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_trims_consumption_id_seq OWNER TO postgres;

--
-- Name: budget_trims_consumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_trims_consumption_id_seq OWNED BY public.budget_trims_consumption.id;


--
-- Name: budget_trims_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_trims_costs (
    id integer NOT NULL,
    budget_id integer,
    gmt_item text,
    item_name text,
    item_description text,
    cons_uom text,
    cons_unit_gmt double precision,
    rate double precision,
    amount double precision,
    total_qty double precision,
    total_amount double precision
);


ALTER TABLE public.budget_trims_costs OWNER TO postgres;

--
-- Name: budget_trims_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_trims_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_trims_costs_id_seq OWNER TO postgres;

--
-- Name: budget_trims_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_trims_costs_id_seq OWNED BY public.budget_trims_costs.id;


--
-- Name: budget_wash_consumption; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_wash_consumption (
    id integer NOT NULL,
    budget_wash_cost_id integer,
    po_no text,
    color text,
    gmt_sizes text,
    po_qty integer,
    country text,
    cons double precision,
    process_loss_pct integer,
    rate double precision,
    amount double precision,
    total_qty double precision,
    total_amount double precision,
    pcs integer
);


ALTER TABLE public.budget_wash_consumption OWNER TO postgres;

--
-- Name: budget_wash_consumption_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_wash_consumption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_wash_consumption_id_seq OWNER TO postgres;

--
-- Name: budget_wash_consumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_wash_consumption_id_seq OWNED BY public.budget_wash_consumption.id;


--
-- Name: budget_wash_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_wash_costs (
    id integer NOT NULL,
    budget_id integer,
    wash_type text,
    wash_name text,
    gmt_item text,
    description text,
    body_part text,
    cons_unit_gmt double precision,
    rate double precision,
    amount double precision,
    total_qty double precision,
    total_amount double precision,
    supplier text,
    image_url text
);


ALTER TABLE public.budget_wash_costs OWNER TO postgres;

--
-- Name: budget_wash_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_wash_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_wash_costs_id_seq OWNER TO postgres;

--
-- Name: budget_wash_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_wash_costs_id_seq OWNED BY public.budget_wash_costs.id;


--
-- Name: budget_yarn_costing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_yarn_costing (
    id integer NOT NULL,
    budget_fabric_cost_id integer,
    yarn_composition text,
    yarn_count text,
    yarn_type text,
    percentage integer,
    color text,
    cons_qty double precision,
    process_loss_pct integer,
    n_supplier text,
    rate double precision,
    amount double precision
);


ALTER TABLE public.budget_yarn_costing OWNER TO postgres;

--
-- Name: budget_yarn_costing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_yarn_costing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_yarn_costing_id_seq OWNER TO postgres;

--
-- Name: budget_yarn_costing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_yarn_costing_id_seq OWNED BY public.budget_yarn_costing.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budgets (
    id integer NOT NULL,
    order_id integer,
    budget_reference text,
    total_fabric_budget double precision,
    total_trims_budget double precision,
    total_cm_budget double precision,
    total_emb_budget double precision,
    total_wash_budget double precision,
    total_other_budget double precision,
    total_commercial_budget double precision,
    total_commission_budget double precision,
    total_budget_amount double precision,
    actual_spend double precision DEFAULT 0,
    status text DEFAULT 'Draft'::text,
    buyer text,
    season text,
    uom text,
    smv double precision,
    incoterm text,
    mc_line integer,
    prod_line_hour integer,
    country text,
    currency text,
    ship_mode text,
    remarks text,
    budget_minute text,
    cutting_smv double precision,
    sewing_smv double precision,
    finishing_smv double precision,
    sewing_efficiency double precision,
    cutting_efficiency double precision,
    finishing_efficiency double precision,
    buying_agent text,
    incoterm_place text,
    costing_date text,
    copy_from text,
    file_no text,
    internal_ref text,
    budget_label text,
    total_lab_test_budget double precision,
    total_inspection_budget double precision,
    total_sample_budget double precision,
    total_freight_budget double precision,
    total_courier_budget double precision,
    total_certif_budget double precision,
    total_common_oh_budget double precision,
    total_deffd_lc_budget double precision,
    total_design_budget double precision,
    total_studio_budget double precision,
    total_opert_exp_budget double precision,
    total_income_tax_budget double precision,
    company text,
    unit text,
    feedback_from_approval text,
    approve_by text,
    user_remarks text,
    quotation_id text,
    style_no text,
    style_desc text,
    department text
);


ALTER TABLE public.budgets OWNER TO postgres;

--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budgets_id_seq OWNER TO postgres;

--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budgets_id_seq OWNED BY public.budgets.id;


--
-- Name: buyers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buyers (
    id integer NOT NULL,
    name text NOT NULL,
    code text,
    brand text,
    buying_agent text,
    team_leader text,
    season text,
    created_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.buyers OWNER TO postgres;

--
-- Name: buyers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.buyers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.buyers_id_seq OWNER TO postgres;

--
-- Name: buyers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.buyers_id_seq OWNED BY public.buyers.id;


--
-- Name: fabric_booking_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fabric_booking_items (
    id integer NOT NULL,
    booking_id integer,
    po_id integer,
    po_no text,
    color text,
    size text,
    item_size text,
    garments_qty integer,
    excess_pct integer,
    total_qty double precision,
    rate double precision,
    amount double precision,
    buyer text,
    style_no text,
    garments_item text,
    body_parts text,
    fabric_color text,
    yarn_type text,
    embellishment_type text,
    embellishment_name text,
    fabric_type text,
    fabric_composition text,
    gsm integer,
    fabric_dia text,
    lab_dip text,
    garments_quantity integer,
    total_fabric_quantity double precision,
    uom text,
    budget_quantity double precision,
    work_order_quantity double precision
);


ALTER TABLE public.fabric_booking_items OWNER TO postgres;

--
-- Name: fabric_booking_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fabric_booking_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fabric_booking_items_id_seq OWNER TO postgres;

--
-- Name: fabric_booking_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fabric_booking_items_id_seq OWNED BY public.fabric_booking_items.id;


--
-- Name: fabric_bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fabric_bookings (
    id integer NOT NULL,
    booking_reference text,
    budget_id integer,
    basis text,
    main_booking_id integer,
    booking_date text,
    supplier_name text,
    delivery_date text,
    inhouse_date text,
    pay_mode text,
    source text,
    currency text,
    attention text,
    remarks text,
    status text DEFAULT 'Pending'::text,
    collar_cuff_info text,
    terms_conditions text,
    company text,
    unit text,
    booking_by text
);


ALTER TABLE public.fabric_bookings OWNER TO postgres;

--
-- Name: fabric_bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fabric_bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fabric_bookings_id_seq OWNER TO postgres;

--
-- Name: fabric_bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fabric_bookings_id_seq OWNED BY public.fabric_bookings.id;


--
-- Name: inquiry_fabrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inquiry_fabrics (
    id integer NOT NULL,
    inquiry_id text,
    composition text,
    fabric_type text,
    gsm integer,
    dia integer,
    dia_type text,
    uom text,
    rate double precision,
    required_qty double precision
);


ALTER TABLE public.inquiry_fabrics OWNER TO postgres;

--
-- Name: inquiry_fabrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inquiry_fabrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inquiry_fabrics_id_seq OWNER TO postgres;

--
-- Name: inquiry_fabrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inquiry_fabrics_id_seq OWNED BY public.inquiry_fabrics.id;


--
-- Name: inquiry_yarns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inquiry_yarns (
    id integer NOT NULL,
    inquiry_id text,
    composition text,
    yarn_composition text,
    yarn_count text,
    yarn_type text,
    certification text
);


ALTER TABLE public.inquiry_yarns OWNER TO postgres;

--
-- Name: inquiry_yarns_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inquiry_yarns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inquiry_yarns_id_seq OWNER TO postgres;

--
-- Name: inquiry_yarns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inquiry_yarns_id_seq OWNED BY public.inquiry_yarns.id;


--
-- Name: items_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items_master (
    id integer NOT NULL,
    item_name text NOT NULL,
    item_group text,
    category text,
    uom text,
    smv double precision,
    created_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.items_master OWNER TO postgres;

--
-- Name: items_master_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.items_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.items_master_id_seq OWNER TO postgres;

--
-- Name: items_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.items_master_id_seq OWNED BY public.items_master.id;


--
-- Name: order_po_breakdown; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_po_breakdown (
    id integer NOT NULL,
    po_id integer,
    color text,
    size text,
    set_qty integer,
    pcs_qty integer,
    rate double precision,
    ex_cut_pct integer,
    plan_cut_qty integer,
    article_no text,
    amount double precision,
    garments_item text
);


ALTER TABLE public.order_po_breakdown OWNER TO postgres;

--
-- Name: order_po_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_po_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_po_breakdown_id_seq OWNER TO postgres;

--
-- Name: order_po_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_po_breakdown_id_seq OWNED BY public.order_po_breakdown.id;


--
-- Name: order_pos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_pos (
    id integer NOT NULL,
    order_id integer,
    po_no text NOT NULL,
    status text,
    received_date text,
    ex_factory_date text,
    ship_date text,
    week_no integer,
    lead_time integer,
    po_qty integer,
    fob_price double precision,
    carton_info text,
    comm_file_no text,
    packing_ratio text,
    delay_for text,
    po_status text,
    remarks text,
    delivery_country text,
    code text,
    area text,
    pcs_per_pack integer,
    fob_in_dzn double precision,
    internal_ref_no text,
    print_qty integer,
    embroidery_qty integer,
    area_code text,
    cutoff_date text,
    cutoff_val text,
    division text,
    country_ship_date text,
    pack_type text,
    port_of_discharge text,
    product_type text,
    req_hanger text,
    matrix_type text
);


ALTER TABLE public.order_pos OWNER TO postgres;

--
-- Name: order_pos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_pos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_pos_id_seq OWNER TO postgres;

--
-- Name: order_pos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_pos_id_seq OWNED BY public.order_pos.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    style_no text NOT NULL,
    inquiry_id text,
    buyer text,
    style_desc text,
    order_status text,
    category text,
    season text,
    team_leader text,
    dealing_merchant text,
    factory_merchant text,
    currency text,
    uom text,
    smv double precision,
    repeat_no text,
    model_code integer,
    garment_dept text,
    embellishment_type text,
    embellishment_name text,
    ship_mode text,
    quality_label text,
    garment_weight double precision,
    avg_weight double precision,
    image_url text,
    status text DEFAULT 'Draft'::text,
    yarn_type text,
    yarn_comp text,
    yarn_cert text,
    embellishment_notes text,
    special_instruction text,
    terms text
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: price_quotations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_quotations (
    id text NOT NULL,
    inquiry_id text,
    style_no text,
    status text DEFAULT 'Draft'::text,
    desired_margin double precision,
    commercial_pct double precision,
    commission_pct double precision,
    total_cost double precision,
    fob_price_doz double precision,
    fob_price_pc double precision,
    cm_value double precision,
    cmc_pct double precision,
    approved_by text,
    approve_date text,
    comments text,
    size_group text,
    mc_line integer,
    prod_line_hour integer,
    sewing_efficiency double precision,
    cutting_efficiency double precision,
    finishing_efficiency double precision,
    qc_efficiency double precision,
    prep_efficiency double precision,
    yarn_cert text,
    size_grading double precision,
    exchange_rate double precision,
    pcs_per_carton integer,
    cbm_per_carton double precision,
    country text,
    buying_agent text,
    buying_house_merchant text,
    currency text,
    color_range text,
    sustainable_material text,
    garments_cert text,
    confirm_date text,
    quotation_date text,
    order_placement_date text,
    embellishment_note text,
    incoterm_place text
);


ALTER TABLE public.price_quotations OWNER TO postgres;

--
-- Name: quotation_emb_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotation_emb_costs (
    id integer NOT NULL,
    quotation_id text,
    emb_type text,
    emb_name text,
    item_name text,
    description text,
    body_part text,
    cons_unit double precision,
    process_loss_pct double precision,
    total_qty double precision,
    rate double precision,
    amount double precision,
    supplier text
);


ALTER TABLE public.quotation_emb_costs OWNER TO postgres;

--
-- Name: quotation_emb_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotation_emb_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_emb_costs_id_seq OWNER TO postgres;

--
-- Name: quotation_emb_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotation_emb_costs_id_seq OWNED BY public.quotation_emb_costs.id;


--
-- Name: quotation_fabric_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotation_fabric_costs (
    id integer NOT NULL,
    quotation_id text,
    item_name text,
    body_part text,
    part_type text,
    color_range text,
    color_nature text,
    composition text,
    fabric_type text,
    source text,
    supplier text,
    gsm integer,
    dia_type text,
    cons_basis text,
    uom text,
    grey_cons double precision,
    rate double precision,
    amount double precision,
    total_qty double precision,
    total_amount double precision,
    process_loss_pct double precision
);


ALTER TABLE public.quotation_fabric_costs OWNER TO postgres;

--
-- Name: quotation_fabric_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotation_fabric_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_fabric_costs_id_seq OWNER TO postgres;

--
-- Name: quotation_fabric_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotation_fabric_costs_id_seq OWNED BY public.quotation_fabric_costs.id;


--
-- Name: quotation_inquiries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotation_inquiries (
    id text NOT NULL,
    buyer_id integer,
    style_no text NOT NULL,
    style_desc text,
    item_group text,
    brand text,
    season text,
    team_leader text,
    dealing_merchant text,
    inquiry_date text,
    sub_date text,
    ship_date text,
    offer_qty integer,
    uom text,
    costing_per text,
    department text,
    sample_req text,
    remarks text,
    image_url text,
    status text DEFAULT 'Draft'::text,
    garments_item text,
    approved_by text,
    approve_date text,
    company text,
    quoted_by text
);


ALTER TABLE public.quotation_inquiries OWNER TO postgres;

--
-- Name: quotation_smv_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotation_smv_items (
    id integer NOT NULL,
    quotation_id text,
    item_name text,
    set_ratio integer,
    cutting_smv double precision,
    sewing_smv double precision,
    finishing_smv double precision
);


ALTER TABLE public.quotation_smv_items OWNER TO postgres;

--
-- Name: quotation_smv_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotation_smv_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_smv_items_id_seq OWNER TO postgres;

--
-- Name: quotation_smv_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotation_smv_items_id_seq OWNED BY public.quotation_smv_items.id;


--
-- Name: quotation_trims_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotation_trims_costs (
    id integer NOT NULL,
    quotation_id text,
    item_name text,
    item_desc text,
    cons_uom text,
    cons_unit double precision,
    extra_pct double precision,
    total_cons double precision,
    rate double precision,
    amount double precision,
    supplier text
);


ALTER TABLE public.quotation_trims_costs OWNER TO postgres;

--
-- Name: quotation_trims_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotation_trims_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_trims_costs_id_seq OWNER TO postgres;

--
-- Name: quotation_trims_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotation_trims_costs_id_seq OWNED BY public.quotation_trims_costs.id;


--
-- Name: quotation_wash_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotation_wash_costs (
    id integer NOT NULL,
    quotation_id text,
    wash_type text,
    wash_name text,
    item_name text,
    description text,
    body_part text,
    cons_unit double precision,
    process_loss_pct double precision,
    total_qty double precision,
    rate double precision,
    amount double precision,
    supplier text
);


ALTER TABLE public.quotation_wash_costs OWNER TO postgres;

--
-- Name: quotation_wash_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotation_wash_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_wash_costs_id_seq OWNER TO postgres;

--
-- Name: quotation_wash_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotation_wash_costs_id_seq OWNED BY public.quotation_wash_costs.id;


--
-- Name: quotation_yarn_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotation_yarn_costs (
    id integer NOT NULL,
    quotation_id text,
    yarn_composition text,
    yarn_count text,
    yarn_type text,
    percentage integer,
    color text,
    cons_qty double precision,
    process_loss_pct double precision,
    supplier text,
    rate double precision,
    amount double precision
);


ALTER TABLE public.quotation_yarn_costs OWNER TO postgres;

--
-- Name: quotation_yarn_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotation_yarn_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_yarn_costs_id_seq OWNER TO postgres;

--
-- Name: quotation_yarn_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotation_yarn_costs_id_seq OWNED BY public.quotation_yarn_costs.id;


--
-- Name: sales_targets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_targets (
    id integer NOT NULL,
    buyer_id integer,
    team_leader text,
    season text,
    year integer,
    month text,
    target_qty double precision,
    target_value double precision,
    confirm_qty double precision DEFAULT 0,
    confirm_value double precision DEFAULT 0,
    status text DEFAULT 'Draft'::text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    brand text,
    buying_agent text,
    buying_agent_merchant text,
    target_basic_qty double precision,
    target_basic_val double precision,
    target_casual_qty double precision,
    target_casual_val double precision,
    target_fashion_qty double precision,
    target_fashion_val double precision
);


ALTER TABLE public.sales_targets OWNER TO postgres;

--
-- Name: sales_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_targets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_targets_id_seq OWNER TO postgres;

--
-- Name: sales_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_targets_id_seq OWNED BY public.sales_targets.id;


--
-- Name: trims_booking_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trims_booking_items (
    id integer NOT NULL,
    booking_id integer,
    po_id integer,
    garments_color text,
    item_color text,
    item_name text,
    item_desc text,
    required_qty double precision,
    prev_booked_qty double precision DEFAULT 0,
    work_order_qty double precision,
    excess_pct integer,
    final_wo_qty double precision,
    rate double precision,
    amount double precision
);


ALTER TABLE public.trims_booking_items OWNER TO postgres;

--
-- Name: trims_booking_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trims_booking_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trims_booking_items_id_seq OWNER TO postgres;

--
-- Name: trims_booking_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trims_booking_items_id_seq OWNED BY public.trims_booking_items.id;


--
-- Name: trims_bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trims_bookings (
    id integer NOT NULL,
    booking_reference text,
    budget_id integer,
    basis text,
    main_booking_id integer,
    booking_date text,
    source text,
    supplier_name text,
    delivery_date text,
    inhouse_date text,
    pay_mode text,
    currency text,
    attention text,
    remarks text,
    status text DEFAULT 'Pending'::text,
    booking_label text,
    terms_conditions text
);


ALTER TABLE public.trims_bookings OWNER TO postgres;

--
-- Name: trims_bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trims_bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trims_bookings_id_seq OWNER TO postgres;

--
-- Name: trims_bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trims_bookings_id_seq OWNED BY public.trims_bookings.id;


--
-- Name: budget_commission_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_commission_costs ALTER COLUMN id SET DEFAULT nextval('public.budget_commission_costs_id_seq'::regclass);


--
-- Name: budget_comml_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_comml_costs ALTER COLUMN id SET DEFAULT nextval('public.budget_comml_costs_id_seq'::regclass);


--
-- Name: budget_emb_consumption id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_emb_consumption ALTER COLUMN id SET DEFAULT nextval('public.budget_emb_consumption_id_seq'::regclass);


--
-- Name: budget_emb_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_emb_costs ALTER COLUMN id SET DEFAULT nextval('public.budget_emb_costs_id_seq'::regclass);


--
-- Name: budget_fabric_consumption id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_fabric_consumption ALTER COLUMN id SET DEFAULT nextval('public.budget_fabric_consumption_id_seq'::regclass);


--
-- Name: budget_fabric_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_fabric_costs ALTER COLUMN id SET DEFAULT nextval('public.budget_fabric_costs_id_seq'::regclass);


--
-- Name: budget_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_items ALTER COLUMN id SET DEFAULT nextval('public.budget_items_id_seq'::regclass);


--
-- Name: budget_other_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_other_costs ALTER COLUMN id SET DEFAULT nextval('public.budget_other_costs_id_seq'::regclass);


--
-- Name: budget_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_templates ALTER COLUMN id SET DEFAULT nextval('public.budget_templates_id_seq'::regclass);


--
-- Name: budget_trims_consumption id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_trims_consumption ALTER COLUMN id SET DEFAULT nextval('public.budget_trims_consumption_id_seq'::regclass);


--
-- Name: budget_trims_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_trims_costs ALTER COLUMN id SET DEFAULT nextval('public.budget_trims_costs_id_seq'::regclass);


--
-- Name: budget_wash_consumption id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_wash_consumption ALTER COLUMN id SET DEFAULT nextval('public.budget_wash_consumption_id_seq'::regclass);


--
-- Name: budget_wash_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_wash_costs ALTER COLUMN id SET DEFAULT nextval('public.budget_wash_costs_id_seq'::regclass);


--
-- Name: budget_yarn_costing id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_yarn_costing ALTER COLUMN id SET DEFAULT nextval('public.budget_yarn_costing_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets ALTER COLUMN id SET DEFAULT nextval('public.budgets_id_seq'::regclass);


--
-- Name: buyers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyers ALTER COLUMN id SET DEFAULT nextval('public.buyers_id_seq'::regclass);


--
-- Name: fabric_booking_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fabric_booking_items ALTER COLUMN id SET DEFAULT nextval('public.fabric_booking_items_id_seq'::regclass);


--
-- Name: fabric_bookings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fabric_bookings ALTER COLUMN id SET DEFAULT nextval('public.fabric_bookings_id_seq'::regclass);


--
-- Name: inquiry_fabrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inquiry_fabrics ALTER COLUMN id SET DEFAULT nextval('public.inquiry_fabrics_id_seq'::regclass);


--
-- Name: inquiry_yarns id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inquiry_yarns ALTER COLUMN id SET DEFAULT nextval('public.inquiry_yarns_id_seq'::regclass);


--
-- Name: items_master id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items_master ALTER COLUMN id SET DEFAULT nextval('public.items_master_id_seq'::regclass);


--
-- Name: order_po_breakdown id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_po_breakdown ALTER COLUMN id SET DEFAULT nextval('public.order_po_breakdown_id_seq'::regclass);


--
-- Name: order_pos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_pos ALTER COLUMN id SET DEFAULT nextval('public.order_pos_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: quotation_emb_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_emb_costs ALTER COLUMN id SET DEFAULT nextval('public.quotation_emb_costs_id_seq'::regclass);


--
-- Name: quotation_fabric_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_fabric_costs ALTER COLUMN id SET DEFAULT nextval('public.quotation_fabric_costs_id_seq'::regclass);


--
-- Name: quotation_smv_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_smv_items ALTER COLUMN id SET DEFAULT nextval('public.quotation_smv_items_id_seq'::regclass);


--
-- Name: quotation_trims_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_trims_costs ALTER COLUMN id SET DEFAULT nextval('public.quotation_trims_costs_id_seq'::regclass);


--
-- Name: quotation_wash_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_wash_costs ALTER COLUMN id SET DEFAULT nextval('public.quotation_wash_costs_id_seq'::regclass);


--
-- Name: quotation_yarn_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_yarn_costs ALTER COLUMN id SET DEFAULT nextval('public.quotation_yarn_costs_id_seq'::regclass);


--
-- Name: sales_targets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_targets ALTER COLUMN id SET DEFAULT nextval('public.sales_targets_id_seq'::regclass);


--
-- Name: trims_booking_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trims_booking_items ALTER COLUMN id SET DEFAULT nextval('public.trims_booking_items_id_seq'::regclass);


--
-- Name: trims_bookings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trims_bookings ALTER COLUMN id SET DEFAULT nextval('public.trims_bookings_id_seq'::regclass);


--
-- Data for Name: budget_commission_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_commission_costs (id, budget_id, particulars, comm_base, rate, amount, status) FROM stdin;
\.


--
-- Data for Name: budget_comml_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_comml_costs (id, budget_id, commercial_type, rate_pct, amount, status) FROM stdin;
\.


--
-- Data for Name: budget_emb_consumption; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_emb_consumption (id, budget_emb_cost_id, po_no, color, gmt_sizes, po_qty, country, cons, process_loss_pct, rate, amount, total_qty, total_amount, pcs) FROM stdin;
1	1	PO-45577mu6	Conventional	M	12000	Bangladesh	12	0	0.44	5.28	144000	63360	1
\.


--
-- Data for Name: budget_emb_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_emb_costs (id, budget_id, emb_type, emb_name, gmt_item, description, body_part, cons_unit_gmt, rate, amount, total_qty, total_amount, supplier, image_url) FROM stdin;
1	1	Print	Printing/Digital print	Polo Shirt	Front chest print	Body Part	12	0.44	5.28	144000	63360	Aman	
\.


--
-- Data for Name: budget_fabric_consumption; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_fabric_consumption (id, budget_fabric_cost_id, po_no, color, gmt_sizes, po_qty, dia_width, dia_fin_type, finish_cons, process_loss_pct, grey_cons, rate, amount, pcs, total_finish_qty, total_qty, sample_qty, total_amount, remarks) FROM stdin;
1	1	PO-45577mu6	Conventional	M	12000	0	Open	2	0	2	0.22	0.44	1	24000	24000	1200	5280	Main body
2	2	45577mu6	blue	M	12000	0	Open	2	2	2	0.22	5544	1	25200	25200	20	5544	Main body
\.


--
-- Data for Name: budget_fabric_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_fabric_costs (id, budget_id, gmt_item, body_part, body_part_type, color_range, color_nature, composition, fabric_type, fabric_nature, code, fabric_source, n_supplier, gsm_oz, dia_type, color_size_sensitive, color, cons_basis, uom, grey_cons, rate, amount, total_qty, total_amount) FROM stdin;
1	1	Polo Shirt	Body Fabric	Shell Fabric	Solid	Conventional	100% Cotton Jersey	Jersey	Knit	101	Production	Toma	180	Open Width	As per Garments Color	Conventional	Marker	Kg	2	0.22	0.44	25200	5544
2	18	Full polo	Body	Shell Fabric	White Color	Solid	100%Cotton Jersey/Knit Fabric	Knit Fabric	Knit	101	Production	Montrims LTD.	220	Open Width	As per Garments Color	blue	Marker	Kg	2	0.22	0.44	25200	5544
\.


--
-- Data for Name: budget_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_items (id, budget_id, item_type, budget_qty, budget_rate, budget_amount, actual_qty, actual_amount) FROM stdin;
\.


--
-- Data for Name: budget_other_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_other_costs (id, budget_id, cost_details, amount) FROM stdin;
\.


--
-- Data for Name: budget_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_templates (id, template_name, item_type, template_data) FROM stdin;
\.


--
-- Data for Name: budget_trims_consumption; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_trims_consumption (id, budget_trims_cost_id, po_no, color, gmt_sizes, po_qty, country, finish_cons, process_loss_pct, grey_cons, rate, amount, pcs, total_finish_qty, total_qty, total_amount) FROM stdin;
1	1	PO-45577mu6	Conventional	M	12000	Bangladesh	12.6	5	13.23	0.55	7.2765	1	151200	158760	87318
\.


--
-- Data for Name: budget_trims_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_trims_costs (id, budget_id, gmt_item, item_name, item_description, cons_uom, cons_unit_gmt, rate, amount, total_qty, total_amount) FROM stdin;
1	1	Polo Shirt	Sewing Thread	Standard polyester thread	Cone	12.6	0.55	6.93	12600	97318
\.


--
-- Data for Name: budget_wash_consumption; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_wash_consumption (id, budget_wash_cost_id, po_no, color, gmt_sizes, po_qty, country, cons, process_loss_pct, rate, amount, total_qty, total_amount, pcs) FROM stdin;
1	1	PO-45577mu6	Conventional	M	12000	Bangladesh	122	0	0.22	26.84	1464000	222090	1
\.


--
-- Data for Name: budget_wash_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_wash_costs (id, budget_id, wash_type, wash_name, gmt_item, description, body_part, cons_unit_gmt, rate, amount, total_qty, total_amount, supplier, image_url) FROM stdin;
1	1	Wet Process	Gmts Dyeing/PIGMENT DYEING	Polo Shirt	Pigment wash	Body Part	122	0.22	26.84	1464000	222090	Aman	
\.


--
-- Data for Name: budget_yarn_costing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_yarn_costing (id, budget_fabric_cost_id, yarn_composition, yarn_count, yarn_type, percentage, color, cons_qty, process_loss_pct, n_supplier, rate, amount) FROM stdin;
1	1	100% Kashmir Yarn	30S	Combed	100	Solid	25200	0	Toma	0.22	5544
2	2	100% Kashmir Yarn	30S	Combed	100	Solid	25200	0	Montrims LTD.	0.22	5544
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budgets (id, order_id, budget_reference, total_fabric_budget, total_trims_budget, total_cm_budget, total_emb_budget, total_wash_budget, total_other_budget, total_commercial_budget, total_commission_budget, total_budget_amount, actual_spend, status, buyer, season, uom, smv, incoterm, mc_line, prod_line_hour, country, currency, ship_mode, remarks, budget_minute, cutting_smv, sewing_smv, finishing_smv, sewing_efficiency, cutting_efficiency, finishing_efficiency, buying_agent, incoterm_place, costing_date, copy_from, file_no, internal_ref, budget_label, total_lab_test_budget, total_inspection_budget, total_sample_budget, total_freight_budget, total_courier_budget, total_certif_budget, total_common_oh_budget, total_deffd_lc_budget, total_design_budget, total_studio_budget, total_opert_exp_budget, total_income_tax_budget, company, unit, feedback_from_approval, approve_by, user_remarks, quotation_id, style_no, style_desc, department) FROM stdin;
1	\N	BG-ZR-polo-001	8064	97318	89990	63360	222090	0	0	0	480822	0	Approved	Zara	Summer 2026	Pcs	14	FOB	12	150	Bangladesh	USD	Sea	Seeded simulation record 1	12000	1.5	10.5	2	65	75	80	Zara Agent	Chittagong Port	19th May 2026		FN-8891	IR-7721	Style Label	0	0	0	0	0	0	0	0	0	0	0	0	Demo Factory Ltd.	Demo Unit	Looks perfectly within margins.	Super Admin	Verified	QTN-001	test-style	Mock style description	Mens
18	\N	DFL-BS-26-003264	8064	97318	89990	63360	222090	0	0	0	480822	0	Approved	NewYorker	winter	Pcs	14	FOB	12	150	Bangladesh	USD	Sea	Mockup simulation record	12000	1.5	10.5	2	65	75	80	Zara Agent	Chittagong Port	10th May 2026		FN-8891	IR-7721	Style Label	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	Demo Factory Ltd.	Demo Unit	\N	\N	\N	QTN-002	test	Mockup style description	Mens
\.


--
-- Data for Name: buyers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.buyers (id, name, code, brand, buying_agent, team_leader, season, created_at) FROM stdin;
1	Zara	ZR	Zara Kids	Inditex Agent	John Doe	Summer 2026	2026-06-21 14:47:32.887836+06
2	H&M	HM	HM Basic	HM Agent	Jane Smith	Autumn 2026	2026-06-21 14:47:32.892371+06
3	Uniqlo	UQ	LifeWear	Fast Retailing	Ken Tanaka	Winter 2026	2026-06-21 14:47:32.896481+06
4	NewYorker	NYK	NewYorker Brand	NYK Agent	Demo User	winter	2026-06-27 13:32:31.334957+06
\.


--
-- Data for Name: fabric_booking_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fabric_booking_items (id, booking_id, po_id, po_no, color, size, item_size, garments_qty, excess_pct, total_qty, rate, amount, buyer, style_no, garments_item, body_parts, fabric_color, yarn_type, embellishment_type, embellishment_name, fabric_type, fabric_composition, gsm, fabric_dia, lab_dip, garments_quantity, total_fabric_quantity, uom, budget_quantity, work_order_quantity) FROM stdin;
4	1	1	45577mu6	blue	M	M	\N	2	25200	0.22	5544	NewYorker	test	Full polo	Body	blue	100% Kashmir Yarn 30S	N/A	N/A	Knit Fabric	100%Cotton Jersey/Knit Fabric	220	Open Width	LD-991	12000	25200	Kg	25200	25200
5	1	\N	PO-custom	Red	M	M	\N	0	1000	5.5	5500	NewYorker	test	Polo Shirt	Body Fabric	Red	N/A	N/A	N/A	Jersey	100% Cotton	180	Open Width	LS-865	12000	1000	Kg	1000	1000
\.


--
-- Data for Name: fabric_bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fabric_bookings (id, booking_reference, budget_id, basis, main_booking_id, booking_date, supplier_name, delivery_date, inhouse_date, pay_mode, source, currency, attention, remarks, status, collar_cuff_info, terms_conditions, company, unit, booking_by) FROM stdin;
1	DFL-FB-26-000450	18	Main	\N	2026-05-10	Montrims LTD.	2026-05-28	2026-05-18	Credit	Non-Epz/Local	USD	Mr. Attention	Remarks For User	Approved	[]	Yarn Type-\n* Yarn Certificate-\n* GSM Tolerance -3 % & + 3. If GSM is more the +3, then extra fabrics must be arranged with FOC basis.\n* Shrinkage: +-5%\n* Dimensional Stability: +-3%\n* CF To Rub (Wet)-\n* CF To Rub (Dry)-\n* Pilling Resistance-	Demo Factory Ltd.	Demo Unit	Merchandiser Supervisor
\.


--
-- Data for Name: inquiry_fabrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inquiry_fabrics (id, inquiry_id, composition, fabric_type, gsm, dia, dia_type, uom, rate, required_qty) FROM stdin;
\.


--
-- Data for Name: inquiry_yarns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inquiry_yarns (id, inquiry_id, composition, yarn_composition, yarn_count, yarn_type, certification) FROM stdin;
\.


--
-- Data for Name: items_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items_master (id, item_name, item_group, category, uom, smv, created_at) FROM stdin;
1	Knit Basic T-Shirt	Basic	Jersey	Pcs	8.5	2026-06-21 14:47:32.89765+06
2	Knit Polo Shirt	Casual Basic	Jersey	Pcs	14	2026-06-21 14:47:32.900928+06
3	Girls Swimming Costume	Fashion	Lingerie	Pcs	16.5	2026-06-21 14:47:32.901743+06
\.


--
-- Data for Name: order_po_breakdown; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_po_breakdown (id, po_id, color, size, set_qty, pcs_qty, rate, ex_cut_pct, plan_cut_qty, article_no, amount, garments_item) FROM stdin;
\.


--
-- Data for Name: order_pos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_pos (id, order_id, po_no, status, received_date, ex_factory_date, ship_date, week_no, lead_time, po_qty, fob_price, carton_info, comm_file_no, packing_ratio, delay_for, po_status, remarks, delivery_country, code, area, pcs_per_pack, fob_in_dzn, internal_ref_no, print_qty, embroidery_qty, area_code, cutoff_date, cutoff_val, division, country_ship_date, pack_type, port_of_discharge, product_type, req_hanger, matrix_type) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, style_no, inquiry_id, buyer, style_desc, order_status, category, season, team_leader, dealing_merchant, factory_merchant, currency, uom, smv, repeat_no, model_code, garment_dept, embellishment_type, embellishment_name, ship_mode, quality_label, garment_weight, avg_weight, image_url, status, yarn_type, yarn_comp, yarn_cert, embellishment_notes, special_instruction, terms) FROM stdin;
\.


--
-- Data for Name: price_quotations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_quotations (id, inquiry_id, style_no, status, desired_margin, commercial_pct, commission_pct, total_cost, fob_price_doz, fob_price_pc, cm_value, cmc_pct, approved_by, approve_date, comments, size_group, mc_line, prod_line_hour, sewing_efficiency, cutting_efficiency, finishing_efficiency, qc_efficiency, prep_efficiency, yarn_cert, size_grading, exchange_rate, pcs_per_carton, cbm_per_carton, country, buying_agent, buying_house_merchant, currency, color_range, sustainable_material, garments_cert, confirm_date, quotation_date, order_placement_date, embellishment_note, incoterm_place) FROM stdin;
PQ-001-2026-06-21	HM-001-2026-06-21-IN	M	Approved	5	5	0	9.851242603550295	15.632886951105574	1.3027405792587978	3.661242603550296	60.4039866765477	Supervisor	2026-06-21	Calculated from bulletin SMV: 16.5	4-8 Years	12	150	65	80	85	90	90	GOTS	2	1	24	0.08	Bangladesh	Zara Agent	Inditex Merchandiser	USD	Solid Multi	BCI	OEKOTEX		2026-06-21		Placement Print	Bangladesh
\.


--
-- Data for Name: quotation_emb_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotation_emb_costs (id, quotation_id, emb_type, emb_name, item_name, description, body_part, cons_unit, process_loss_pct, total_qty, rate, amount, supplier) FROM stdin;
\.


--
-- Data for Name: quotation_fabric_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotation_fabric_costs (id, quotation_id, item_name, body_part, part_type, color_range, color_nature, composition, fabric_type, source, supplier, gsm, dia_type, cons_basis, uom, grey_cons, rate, amount, total_qty, total_amount, process_loss_pct) FROM stdin;
\.


--
-- Data for Name: quotation_inquiries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotation_inquiries (id, buyer_id, style_no, style_desc, item_group, brand, season, team_leader, dealing_merchant, inquiry_date, sub_date, ship_date, offer_qty, uom, costing_per, department, sample_req, remarks, image_url, status, garments_item, approved_by, approve_date, company, quoted_by) FROM stdin;
HM-001-2026-06-21-IN	2	M	hgfjhc	Basic					2026-06-21			0	Pcs	1 Dzn	Kids	No			Approved	\N	Supervisor	2026-06-21	\N	\N
HM-002-2026-Jun-27-IN	2	Style-2002	gjvkolkokg	Casual Basic	H&M	Autumn 2026	John Doe	Alice Johnson	2026-06-27	2026-06-23		0	Pcs	1 Dzn	Kids	No			Approved		Supervisor	2026-06-27	Metamorphosis Apparels	Super admin
\.


--
-- Data for Name: quotation_smv_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotation_smv_items (id, quotation_id, item_name, set_ratio, cutting_smv, sewing_smv, finishing_smv) FROM stdin;
\.


--
-- Data for Name: quotation_trims_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotation_trims_costs (id, quotation_id, item_name, item_desc, cons_uom, cons_unit, extra_pct, total_cons, rate, amount, supplier) FROM stdin;
\.


--
-- Data for Name: quotation_wash_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotation_wash_costs (id, quotation_id, wash_type, wash_name, item_name, description, body_part, cons_unit, process_loss_pct, total_qty, rate, amount, supplier) FROM stdin;
\.


--
-- Data for Name: quotation_yarn_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotation_yarn_costs (id, quotation_id, yarn_composition, yarn_count, yarn_type, percentage, color, cons_qty, process_loss_pct, supplier, rate, amount) FROM stdin;
\.


--
-- Data for Name: sales_targets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_targets (id, buyer_id, team_leader, season, year, month, target_qty, target_value, confirm_qty, confirm_value, status, created_at, brand, buying_agent, buying_agent_merchant, target_basic_qty, target_basic_val, target_casual_qty, target_casual_val, target_fashion_qty, target_fashion_val) FROM stdin;
\.


--
-- Data for Name: trims_booking_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trims_booking_items (id, booking_id, po_id, garments_color, item_color, item_name, item_desc, required_qty, prev_booked_qty, work_order_qty, excess_pct, final_wo_qty, rate, amount) FROM stdin;
\.


--
-- Data for Name: trims_bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trims_bookings (id, booking_reference, budget_id, basis, main_booking_id, booking_date, source, supplier_name, delivery_date, inhouse_date, pay_mode, currency, attention, remarks, status, booking_label, terms_conditions) FROM stdin;
\.


--
-- Name: budget_commission_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_commission_costs_id_seq', 1, false);


--
-- Name: budget_comml_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_comml_costs_id_seq', 1, false);


--
-- Name: budget_emb_consumption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_emb_consumption_id_seq', 1, true);


--
-- Name: budget_emb_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_emb_costs_id_seq', 1, true);


--
-- Name: budget_fabric_consumption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_fabric_consumption_id_seq', 2, true);


--
-- Name: budget_fabric_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_fabric_costs_id_seq', 2, true);


--
-- Name: budget_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_items_id_seq', 1, false);


--
-- Name: budget_other_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_other_costs_id_seq', 1, false);


--
-- Name: budget_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_templates_id_seq', 1, false);


--
-- Name: budget_trims_consumption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_trims_consumption_id_seq', 1, true);


--
-- Name: budget_trims_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_trims_costs_id_seq', 1, true);


--
-- Name: budget_wash_consumption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_wash_consumption_id_seq', 1, true);


--
-- Name: budget_wash_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_wash_costs_id_seq', 1, true);


--
-- Name: budget_yarn_costing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_yarn_costing_id_seq', 2, true);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budgets_id_seq', 18, true);


--
-- Name: buyers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.buyers_id_seq', 4, true);


--
-- Name: fabric_booking_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fabric_booking_items_id_seq', 5, true);


--
-- Name: fabric_bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fabric_bookings_id_seq', 1, true);


--
-- Name: inquiry_fabrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inquiry_fabrics_id_seq', 1, false);


--
-- Name: inquiry_yarns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inquiry_yarns_id_seq', 1, false);


--
-- Name: items_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.items_master_id_seq', 3, true);


--
-- Name: order_po_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_po_breakdown_id_seq', 1, false);


--
-- Name: order_pos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_pos_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: quotation_emb_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotation_emb_costs_id_seq', 1, true);


--
-- Name: quotation_fabric_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotation_fabric_costs_id_seq', 1, false);


--
-- Name: quotation_smv_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotation_smv_items_id_seq', 1, true);


--
-- Name: quotation_trims_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotation_trims_costs_id_seq', 2, true);


--
-- Name: quotation_wash_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotation_wash_costs_id_seq', 1, true);


--
-- Name: quotation_yarn_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotation_yarn_costs_id_seq', 1, false);


--
-- Name: sales_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_targets_id_seq', 1, false);


--
-- Name: trims_booking_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trims_booking_items_id_seq', 1, false);


--
-- Name: trims_bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trims_bookings_id_seq', 1, false);


--
-- Name: budget_commission_costs budget_commission_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_commission_costs
    ADD CONSTRAINT budget_commission_costs_pkey PRIMARY KEY (id);


--
-- Name: budget_comml_costs budget_comml_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_comml_costs
    ADD CONSTRAINT budget_comml_costs_pkey PRIMARY KEY (id);


--
-- Name: budget_emb_consumption budget_emb_consumption_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_emb_consumption
    ADD CONSTRAINT budget_emb_consumption_pkey PRIMARY KEY (id);


--
-- Name: budget_emb_costs budget_emb_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_emb_costs
    ADD CONSTRAINT budget_emb_costs_pkey PRIMARY KEY (id);


--
-- Name: budget_fabric_consumption budget_fabric_consumption_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_fabric_consumption
    ADD CONSTRAINT budget_fabric_consumption_pkey PRIMARY KEY (id);


--
-- Name: budget_fabric_costs budget_fabric_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_fabric_costs
    ADD CONSTRAINT budget_fabric_costs_pkey PRIMARY KEY (id);


--
-- Name: budget_items budget_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_items
    ADD CONSTRAINT budget_items_pkey PRIMARY KEY (id);


--
-- Name: budget_other_costs budget_other_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_other_costs
    ADD CONSTRAINT budget_other_costs_pkey PRIMARY KEY (id);


--
-- Name: budget_templates budget_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_templates
    ADD CONSTRAINT budget_templates_pkey PRIMARY KEY (id);


--
-- Name: budget_trims_consumption budget_trims_consumption_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_trims_consumption
    ADD CONSTRAINT budget_trims_consumption_pkey PRIMARY KEY (id);


--
-- Name: budget_trims_costs budget_trims_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_trims_costs
    ADD CONSTRAINT budget_trims_costs_pkey PRIMARY KEY (id);


--
-- Name: budget_wash_consumption budget_wash_consumption_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_wash_consumption
    ADD CONSTRAINT budget_wash_consumption_pkey PRIMARY KEY (id);


--
-- Name: budget_wash_costs budget_wash_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_wash_costs
    ADD CONSTRAINT budget_wash_costs_pkey PRIMARY KEY (id);


--
-- Name: budget_yarn_costing budget_yarn_costing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_yarn_costing
    ADD CONSTRAINT budget_yarn_costing_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_budget_reference_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_budget_reference_key UNIQUE (budget_reference);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: buyers buyers_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyers
    ADD CONSTRAINT buyers_code_key UNIQUE (code);


--
-- Name: buyers buyers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyers
    ADD CONSTRAINT buyers_pkey PRIMARY KEY (id);


--
-- Name: fabric_booking_items fabric_booking_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fabric_booking_items
    ADD CONSTRAINT fabric_booking_items_pkey PRIMARY KEY (id);


--
-- Name: fabric_bookings fabric_bookings_booking_reference_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fabric_bookings
    ADD CONSTRAINT fabric_bookings_booking_reference_key UNIQUE (booking_reference);


--
-- Name: fabric_bookings fabric_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fabric_bookings
    ADD CONSTRAINT fabric_bookings_pkey PRIMARY KEY (id);


--
-- Name: inquiry_fabrics inquiry_fabrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inquiry_fabrics
    ADD CONSTRAINT inquiry_fabrics_pkey PRIMARY KEY (id);


--
-- Name: inquiry_yarns inquiry_yarns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inquiry_yarns
    ADD CONSTRAINT inquiry_yarns_pkey PRIMARY KEY (id);


--
-- Name: items_master items_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items_master
    ADD CONSTRAINT items_master_pkey PRIMARY KEY (id);


--
-- Name: order_po_breakdown order_po_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_po_breakdown
    ADD CONSTRAINT order_po_breakdown_pkey PRIMARY KEY (id);


--
-- Name: order_pos order_pos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_pos
    ADD CONSTRAINT order_pos_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: price_quotations price_quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_quotations
    ADD CONSTRAINT price_quotations_pkey PRIMARY KEY (id);


--
-- Name: quotation_emb_costs quotation_emb_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_emb_costs
    ADD CONSTRAINT quotation_emb_costs_pkey PRIMARY KEY (id);


--
-- Name: quotation_fabric_costs quotation_fabric_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_fabric_costs
    ADD CONSTRAINT quotation_fabric_costs_pkey PRIMARY KEY (id);


--
-- Name: quotation_inquiries quotation_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_inquiries
    ADD CONSTRAINT quotation_inquiries_pkey PRIMARY KEY (id);


--
-- Name: quotation_smv_items quotation_smv_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_smv_items
    ADD CONSTRAINT quotation_smv_items_pkey PRIMARY KEY (id);


--
-- Name: quotation_trims_costs quotation_trims_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_trims_costs
    ADD CONSTRAINT quotation_trims_costs_pkey PRIMARY KEY (id);


--
-- Name: quotation_wash_costs quotation_wash_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_wash_costs
    ADD CONSTRAINT quotation_wash_costs_pkey PRIMARY KEY (id);


--
-- Name: quotation_yarn_costs quotation_yarn_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_yarn_costs
    ADD CONSTRAINT quotation_yarn_costs_pkey PRIMARY KEY (id);


--
-- Name: sales_targets sales_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_targets
    ADD CONSTRAINT sales_targets_pkey PRIMARY KEY (id);


--
-- Name: trims_booking_items trims_booking_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trims_booking_items
    ADD CONSTRAINT trims_booking_items_pkey PRIMARY KEY (id);


--
-- Name: trims_bookings trims_bookings_booking_reference_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trims_bookings
    ADD CONSTRAINT trims_bookings_booking_reference_key UNIQUE (booking_reference);


--
-- Name: trims_bookings trims_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trims_bookings
    ADD CONSTRAINT trims_bookings_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict S6zVfxPg3bJK0T0StQ7wAf3QGg2vPGQY2OzmvByRwVuYC897IW4AqteQJtp9DBH

